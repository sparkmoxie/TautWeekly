"use strict";

const state = {
  csrfToken: "",
  status: null,
  config: null,
  editor: null,
  backups: [],
  backupMaximum: 10,
  verification: { last: null, smtp: null },
  verificationRunning: false,
  smtpVerificationRunning: false,
  cacheVerificationRunning: false,
  cache: null,
  discovery: null,
  discoveryError: "",
  discoveryRunning: false,
  setupWorkflow: null,
  setupWorkflowRunning: false,
  previews: [],
  selectedPreviewID: "",
  operation: null,
  history: [],
  historyMaximum: 20,
  operationStarting: false,
  operationStartingType: "",
  operationCancelling: false,
  scheduleOperation: null,
  schedulePendingAction: "",
  scheduleStarting: false,
  startup: null,
  startupDraft: null,
  startupSaving: false,
  startupError: "",
  authAccess: null,
  tailscale: null,
  tailscaleSaving: false,
  tailscaleVerifying: false,
  tailscaleRequestedOperation: "",
  tailscaleError: "",
  tailscaleSetupURL: "",
  about: null,
  diagnostics: { events: [], maximumEntries: 20, retentionPolicy: "count-only-fifo" },
  capabilities: null,
  updates: null,
  updateChecking: false,
  updateInstalling: false,
  setup: null,
  runtimeMode: "windows",
};
const byId = (id) => document.getElementById(id);
const titleCase = (value) => String(value || "unknown").replaceAll("-", " ").replace(/\b\w/g, (letter) => letter.toUpperCase());
const guidedConfigFields = new Set(["IncludedLibraryIds", "ExcludedUserIds", "UserEmailOverrides", "UserBccAddresses"]);
const noTitleGifChoice = Object.freeze({ id: "none", label: "None", file: "" });
const titleGifChoices = Object.freeze([
  { id: "celebrate", label: "Celebrate", file: "celebrate.gif" },
  { id: "construction", label: "Construction", file: "construction.gif" },
  { id: "rocket", label: "Rocket", file: "rocket.gif" },
  { id: "tickets", label: "Tickets", file: "tickets.gif" },
  { id: "warning", label: "Warning", file: "warning.gif" },
  { id: "alert", label: "Alert", file: "alert.gif" },
]);
const activeSecretReveals = new Map();
let pendingSecretReveal = null;
let sessionRecoveryPromise = null;
let applicationRefreshPromise = null;
let authenticationEpoch = 0;
let updateInstallPollTimer;
let updateCheckAvailabilityTimer;
let deliveryStatusPollTimer;
let deliveryStatusPollInFlight = false;
let updateInstallExpectedVersion = "";
let updateInstallSawDisconnect = false;
let updateInstallPollDeadline = 0;
let lastRoutedURL = "";

function materializeMaterialIcon(svg) {
  const use = svg?.querySelector("use");
  const href = use?.getAttribute("href") || "";
  const symbol = href.startsWith("#") ? byId(href.slice(1)) : null;
  if (!symbol) return svg;
  const viewBox = symbol.getAttribute("viewBox");
  if (viewBox) svg.setAttribute("viewBox", viewBox);
  svg.replaceChildren(...Array.from(symbol.children, (child) => child.cloneNode(true)));
  return svg;
}

function materializeMaterialIcons(root = document) {
  root.querySelectorAll("svg.ui-icon").forEach(materializeMaterialIcon);
}

function maskedInputLabel(input) {
  const label = input.labels?.[0];
  const strongLabel = label?.querySelector(":scope > strong")?.textContent?.trim();
  if (strongLabel) return strongLabel;
  const directLabel = Array.from(label?.childNodes || []).find((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
  if (directLabel) return directLabel.textContent.trim();
  return input.getAttribute("aria-label") || input.name || "value";
}

function updateMaskedInputToggle(input, button) {
  const visible = input.type === "text";
  const label = maskedInputLabel(input);
  button.classList.toggle("visible", visible);
  button.setAttribute("aria-pressed", String(visible));
  button.setAttribute("aria-label", `${visible ? "Hide" : "Show"} ${label}`);
  button.title = `${visible ? "Hide" : "Show"} ${label}`;
}

function initializeMaskedInputToggles(root = document) {
  root.querySelectorAll('input[type="password"]').forEach((input) => {
    if (input.closest(".secret-input-shell") || input.closest(".masked-input-shell")) return;
    const shell = document.createElement("span");
    shell.className = "masked-input-shell";
    input.before(shell);
    shell.append(input);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "secret-toggle-button";
    button.setAttribute("aria-controls", input.id);
    button.append(createMaterialIcon("visibility"));
    button.addEventListener("click", () => {
      input.type = input.type === "password" ? "text" : "password";
      updateMaskedInputToggle(input, button);
      input.focus({ preventScroll: true });
    });
    shell.append(button);
    updateMaskedInputToggle(input, button);
  });
}

function concealMaskedInputs(root = document) {
  root.querySelectorAll(".masked-input-shell>input").forEach((input) => {
    input.type = "password";
    const button = input.nextElementSibling;
    if (button?.classList.contains("secret-toggle-button")) updateMaskedInputToggle(input, button);
  });
}

async function performRequest(path, options = {}) {
  const method = options.method || "GET";
  const headers = new Headers(options.headers || {});
  if (options.body && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
  if (method !== "GET" && method !== "HEAD" && state.csrfToken) headers.set("X-CSRF-Token", state.csrfToken);
  const response = await fetch(path, { ...options, method, headers, credentials: "same-origin" });
  const contentType = response.headers.get("Content-Type") || "";
  const payload = contentType.includes("application/json") ? await response.json() : null;
  if (!response.ok) {
    const code = payload?.error?.code || "request-failed";
    const error = new Error(sanitizedRequestErrorMessage(code, payload?.error?.message, response.status));
    error.status = response.status;
    error.code = code;
    error.fields = payload?.error?.fields || {};
    throw error;
  }
  return payload;
}

function sanitizedRequestErrorMessage(code, fallback, status) {
  const fixed = {
    "invalid-origin": "The browser sent a malformed origin. Open the Manager from its exact configured address and try again.",
    "origin-host-mismatch": "The browser origin does not match the Host received by this Manager. Reopen the exact loopback recovery URL or independently verified Funnel address, then retry. No configuration was saved.",
    "origin-scheme-mismatch": "The browser origin uses the wrong HTTP or HTTPS scheme. Reopen the exact configured Manager URL and try again.",
    "remote-http": "Remote Manager changes require HTTPS. Use the independently verified Funnel address and try again.",
  };
  if (fixed[code]) return `${fixed[code]} (${code})`;
  return fallback || `Request failed (${status}).`;
}

async function renewTrustedLocalSession() {
  const session = await performRequest("/api/v1/auth/session");
  state.csrfToken = session.csrfToken || "";
  return session;
}

async function reloadAfterTrustedLocalRestart() {
  try {
    const setup = await performRequest("/api/v1/setup");
    if (!setup?.authenticationRequired) {
      window.location.reload();
      return true;
    }
  } catch (_) {
    // Preserve the original authentication error when setup cannot be read.
  }
  return false;
}

async function request(path, options = {}, allowSessionRecovery = true) {
  try {
    return await performRequest(path, options);
  } catch (error) {
    const authBootstrapEndpoint = ["/api/v1/auth/session", "/api/v1/auth/login", "/api/v1/auth/pair", "/api/v1/auth/logout"].includes(path);
    if (error.status !== 401 || !allowSessionRecovery || authBootstrapEndpoint) throw error;
    if (!sessionRecoveryPromise) {
      sessionRecoveryPromise = renewTrustedLocalSession().finally(() => {
        sessionRecoveryPromise = null;
      });
    }
    try {
      await sessionRecoveryPromise;
      return await request(path, options, false);
    } catch (recoveryError) {
      if (recoveryError.status === 401 && await reloadAfterTrustedLocalRestart()) {
        const restoring = new Error("Manager restarted; restoring the trusted-local session.");
        restoring.code = "session-restoring";
        restoring.status = 0;
        throw restoring;
      }
      state.csrfToken = "";
      showAuthentication();
      throw recoveryError;
    }
  }
}

function pairingTokenFromFragment() {
  const params = new URLSearchParams(window.location.hash.slice(1));
  const token = params.get("pair") || "";
  if (token) history.replaceState(null, "", window.location.pathname + window.location.search);
  return token;
}

async function initialize() {
  const setup = await request("/api/v1/setup");
  state.setup = setup;
  state.runtimeMode = setup.runtimeMode || "windows";
  renderAuthenticationBoundary();
  try {
    const session = await request("/api/v1/auth/session");
    state.csrfToken = session.csrfToken;
    await enterApplication();
    return;
  } catch (error) {
    if (error.status !== 401) setAuthMessage(error.message);
  }
  byId("auth-shell").hidden = false;
  if (setup.pairingRequired) {
    setText("auth-title", "Set up TautWeekly");
    byId("pair-form").hidden = false;
    const token = pairingTokenFromFragment();
    byId("pair-token").value = token;
    (token ? byId("pair-password") : byId("pair-token")).focus();
  } else {
    byId("login-form").hidden = false;
    byId("login-password").focus();
  }
}

async function enterApplication(preferredView = "") {
  byId("auth-shell").hidden = true;
  byId("app-shell").hidden = false;
  const localStatusLoaded = await loadAll();
  const route = preferredView ? { view: preferredView, section: "" } : window.TautWeeklyUpdateUI.routeFromHash(window.location.hash);
  lastRoutedURL = window.location.href;
  selectView(route.view, { section: route.section, updateHistory: false });
  if (localStatusLoaded) checkForUpdatesInBackground();
}

async function loadAll() {
  const loadAuthenticationEpoch = authenticationEpoch;
  setGlobalStatus("Refreshing local status…");
  try {
    const [status, config, editor, configurationStatus, backups, verification, discovery, previews, operation, history, scheduleOperation, startup, authAccess, about, diagnostics, capabilities, updates] = await Promise.all([
      request("/api/v1/status"),
      request("/api/v1/config"),
      request("/api/v1/config/editor"),
      request("/api/v1/config/status"),
      request("/api/v1/config/backups"),
      request("/api/v1/checks/integrations"),
      request("/api/v1/discovery/tautulli"),
      request("/api/v1/previews"),
      request("/api/v1/operations/current"),
      request("/api/v1/history"),
      request("/api/v1/schedule/operation"),
      request("/api/v1/startup"),
      request("/api/v1/auth/access"),
      request("/api/v1/about"),
      request("/api/v1/diagnostics"),
      request("/api/v1/capabilities"),
      request("/api/v1/updates"),
    ]);
    if (loadAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return false;
    state.status = status;
    state.config = config;
    state.editor = editor;
    state.setupWorkflow = configurationStatus?.available ? configurationStatus : null;
    state.cache = configurationStatus?.cache || null;
    state.backupMaximum = Number(backups.maximumEntries) || 10;
    state.backups = (backups.backups || []).slice(0, state.backupMaximum);
    state.verification = verification || { last: null, smtp: null };
    state.discovery = discovery.last || null;
    state.previews = previews.previews || [];
    state.operation = operation.current || null;
    state.historyMaximum = Number(history.maximumEntries) || 20;
    state.history = (history.operations || []).slice(0, state.historyMaximum);
    state.scheduleOperation = scheduleOperation.current || null;
    state.startup = startup;
    state.startupDraft = null;
    state.startupError = "";
    state.authAccess = authAccess;
    state.about = about;
    const diagnosticMaximum = Number(diagnostics.maximumEntries) || 20;
    state.diagnostics = { ...diagnostics, maximumEntries: diagnosticMaximum, events: (diagnostics.events || []).slice(0, diagnosticMaximum) };
    state.capabilities = capabilities;
    state.updates = updates;
    state.runtimeMode = capabilities.runtimeMode || state.runtimeMode;
    renderCapabilities();
    renderStatus();
    renderFirstTimeSetup();
    renderConfigEditor();
    renderSetupWorkflow();
    renderBackups();
    renderVerification();
    renderPreviews();
    reconcileOperationUserSelections();
    renderOperations();
    renderSchedule();
    renderStartupSettings();
    renderAccessSettings();
    renderTailscaleSettings();
    renderUpdates();
    renderAbout();
    manageOperationPolling();
    manageSchedulePolling();
    manageDeliveryStatusPolling();
    setGlobalStatus("Local status refreshed.", true);
    void loadTailscaleAccess();
    void recoverPendingCacheWarm();
    return true;
  } catch (error) {
    if (loadAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return false;
    if (error.status === 401) {
      showAuthentication();
      return false;
    }
    setGlobalStatus(error.message, true);
    return false;
  }
}

function updateCheckIsAvailable(update = state.updates || {}) {
  const cooldown = window.TautWeeklyUpdateUI.updateCheckCooldown(update);
  return !state.updateChecking && !update.checkInProgress && !cooldown.active;
}

async function refreshApplicationStatus() {
  if (applicationRefreshPromise) return applicationRefreshPromise;
  const refreshAuthenticationEpoch = authenticationEpoch;
  const refreshButton = byId("refresh-button");
  refreshButton.disabled = true;
  const refreshWork = (async () => {
    await loadAll();
    if (refreshAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    const refreshes = [];
    if (state.editor?.state === "ready") {
      refreshes.push(runTautulliDiscovery({
        requireConfirmation: false,
        announceGlobalStatus: false,
        recoverPendingPreviews: false,
      }));
    }
    if (updateCheckIsAvailable()) refreshes.push(checkForUpdates());
    await Promise.allSettled(refreshes);
  })();
  applicationRefreshPromise = refreshWork;
  try {
    return await refreshWork;
  } finally {
    if (applicationRefreshPromise === refreshWork) applicationRefreshPromise = null;
    if (refreshAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) refreshButton.disabled = false;
  }
}

function runtimeMode() {
  return state.capabilities?.runtimeMode || state.runtimeMode;
}

function isNAS() {
  return runtimeMode() === "nas";
}

function isLinuxService() {
  return runtimeMode() === "linux";
}

function isMacDocker() {
  return runtimeMode() === "mac";
}

function isServiceRuntime() {
  return isNAS() || isLinuxService() || isMacDocker();
}

function embeddedRuntimeLabel() {
  return isLinuxService() ? "Linux service" : "container";
}

function configFieldIsHidden(field) {
  return field.type === "asset-id" || guidedConfigFields.has(field.name) || (isServiceRuntime() && field.name === "ScheduledTaskName");
}

function packageKind() {
  return state.capabilities?.packageKind || state.setup?.packageKind || "";
}

function packageName() {
  return state.capabilities?.packageLabel || state.setup?.packageLabel || "Manager";
}

function packageAccessGuidance(kind) {
  const guide = "https://sparkmoxie.github.io/TautWeekly/";
  const containerGuide = "nas-docker/manager.html#first-access";
  const hostDefault = "With the default host mapping, open Manager through an SSH tunnel to the host's loopback port.";
  const desktopDefault = "With the default port mapping, open Manager on the Mac running Docker Desktop.";
  const directCommands = (prefix, mode) => {
    const manager = `${prefix}/opt/tautweekly/bin/run-as-user.sh /opt/tautweekly/bin/tautweekly-manager`;
    return {
      bootstrap: `${manager} access-bootstrap --data-dir /data/manager`,
      recovery: `Run ${manager} access-recover --data-dir /data/manager --tautweekly-root /opt/tautweekly --listen 0.0.0.0:8080 --runtime-mode ${mode} --confirm, then restart the container and retrieve a new token.`,
    };
  };
  const wrapperCommands = (command, location) => ({
    location: `${location}, run`,
    bootstrap: `${command} manager-bootstrap`,
    recovery: `${location}, run ${command} manager-reset-access, then retrieve a new token.`,
  });
  switch (kind) {
    case "windows-installer":
    case "windows-portable":
      return {
        guide: `${guide}windows/#password`,
        access: "Open Manager on the Windows computer running TautWeekly. For public access, use a verified Funnel address when enabled.",
        recovery: kind === "windows-portable"
          ? "Run 18-RESET-MANAGER-ACCESS.bat from the extracted Windows folder."
          : "Use the Reset TautWeekly Manager Access shortcut or run Reset-TautWeekly-Access.cmd in the installed folder.",
        pairing: "Use the one-time token from the Manager launch message, then create an administrator password.",
      };
    case "linux-native":
      return { guide: `${guide}linux/#install`, access: "With the default Linux listener, open Manager on the host or forward its loopback port over SSH.", ...wrapperCommands("sudo tautweekly", "On the Linux host") };
    case "freebsd-podman":
      return { guide: `${guide}freebsd/#install`, access: hostDefault, ...wrapperCommands("sudo tautweekly", "On the FreeBSD host") };
    case "mac-docker":
      return { guide: `${guide}mac/#install`, access: desktopDefault, ...wrapperCommands("./tautweekly.sh", "From the extracted Mac archive") };
    case "nas-docker":
      return { guide: guide + containerGuide, access: hostDefault, ...wrapperCommands("./tautweekly.sh", "From the extracted NAS archive on the host") };
    case "container-desktop":
    case "mac-docker-registry":
      return { guide: `${guide}mac/#install`, access: desktopDefault, location: "From the Mac's Compose project directory, run", ...directCommands("docker compose exec -T tautweekly ", "mac") };
    case "container-compose":
      return { guide: guide + containerGuide, access: hostDefault, location: "From the host's Compose project directory, run", ...directCommands("docker compose exec -T tautweekly ", "nas") };
    case "unraid":
    case "qnap-container-station":
      return { guide: guide + containerGuide, access: hostDefault, location: `In the ${kind === "unraid" ? "Unraid" : "Container Station"} container Console, run`, ...directCommands("", "nas") };
    case "docker-compatible":
      return {
        guide: guide + containerGuide,
        access: "Use the Manager address configured in the tool that deployed this container.",
        location: "Open a container console with your deployment tool and run",
        bootstrap: directCommands("", "nas").bootstrap,
        recovery: "Follow the container console recovery steps for your deployment, then restart and retrieve a new token.",
      };
    default:
      return { guide, access: "Use the address configured for this installation.", pairing: "Get the one-time token using the steps for your installation method, then create an administrator password.", recovery: "Follow the password recovery steps for your installation method." };
  }
}

function renderAuthenticationBoundary() {
  const guidance = packageAccessGuidance(packageKind());
  setText("auth-runtime-eyebrow", packageName());
  setText("auth-runtime-copy", guidance.access);
  setText("auth-pairing-copy", guidance.pairing || `${guidance.location} ${guidance.bootstrap}. Enter the one-time token to create your administrator password.`);
  setText("auth-recovery-copy", `Forgot the password? ${guidance.recovery}`);
  byId("auth-setup-guide").href = guidance.guide;
}

function renderCapabilities() {
  renderAuthenticationBoundary();
  const guidance = packageAccessGuidance(packageKind());
  const linux = isLinuxService();
  const service = isServiceRuntime();
  setText("mode-pill-label", packageName());
  setText("schedule-nav-copy", "Scheduler status");
  setText("configuration-platform-label", packageName());
  setText("config-nav-copy", "Connections and newsletter");
  setText("upcoming-run-label", service ? "Upcoming scheduler run" : "Upcoming task run");
  setText("schedule-state-label", service ? "Scheduler state" : "Task state");
  setText("schedule-lifecycle-copy", service
    ? "Disabling future starts never cancels a newsletter delivery that is already running."
    : "Disabling or removing a schedule never cancels a newsletter process that is already running.");
  setText("settings-platform-copy", packageName());
  setText("about-access-copy", guidance.access);
  setText("diagnostics-package-label", packageName());
  setText("about-secret-copy", service
    ? "Secrets stay hidden during normal reads. Revealing returns only the selected credential, requires administrator password re-authentication, and automatically clears from the page."
    : "Secrets stay hidden during normal reads. Revealing returns only the selected credential, uses password re-authentication when the optional lock is enabled, and automatically clears from the page.");
  setText("about-delivery-copy", "The scheduler reports when a run starts. The newsletter reports what the mail server accepted. Check the recipient’s inbox to confirm delivery.");
  setText("access-settings-eyebrow", service ? "Required Manager authentication" : "Optional Manager lock");
  setText("access-settings-heading", service ? "Administrator password" : "Browser access");
  setText("access-recovery-copy", `${guidance.recovery} Recovery preserves newsletter configuration, schedules, and history.`);
  byId("access-recovery-guide").href = guidance.guide;
  setText("foundation-schedule-copy", "Set when the weekly newsletter goes out. You can disable future runs without interrupting a delivery in progress.");
  document.querySelectorAll("[data-windows-schedule-only]").forEach((element) => { element.hidden = service; });
  if (service) {
    setText("schedule-page-eyebrow", "Weekly delivery");
    setText("schedule-page-copy", "Review the delivery time and enable or disable future runs.");
    setText("schedule-boundary-eyebrow", "Schedule settings");
    setText("schedule-boundary-heading", "Change the weekly delivery time in Config");
    setText("schedule-boundary-copy", "Enabling or disabling the schedule saves the setting and creates a private configuration backup.");
    setText("schedule-overview-heading", "Scheduler status");
    setText("schedule-enable-copy", "Allow the embedded scheduler to begin a future newsletter run in the configured weekly window.");
    setText("schedule-disable-copy", "Prevent future scheduler starts while preserving configuration, history, output, and any delivery already running.");
    byId("schedule-actions").setAttribute("aria-label", linux ? "Linux service schedule actions" : "Container schedule actions");
  } else {
    setText("schedule-page-eyebrow", "Weekly delivery");
    setText("schedule-page-copy", "Review the delivery time and manage the TautWeekly task in Windows Task Scheduler.");
    setText("schedule-boundary-eyebrow", "Windows approval");
    setText("schedule-boundary-heading", "Approve changes in Windows");
    setText("schedule-boundary-copy", "Windows asks for administrator approval. The Manager checks that the task belongs to this installation before changing it.");
    setText("schedule-overview-heading", "Task Scheduler status");
    setText("schedule-enable-copy", "Allow an installed, verified task to begin future scheduled newsletter runs.");
    setText("schedule-disable-copy", "Prevent future task starts while preserving configuration, history, output, and the task definition.");
    byId("schedule-actions").setAttribute("aria-label", "Windows schedule actions");
  }
}

function renderFirstTimeSetup() {
  const prompt = byId("first-time-setup");
  const firstRun = state.editor?.state === "unconfigured";
  prompt.hidden = !firstRun;
  if (firstRun) {
    setChip("first-time-setup-chip", "Not run", "pending");
    setText("first-time-setup-copy", state.runtimeMode === "windows"
      ? "Add Tautulli, Plex, and email settings first. Optional public Funnel access stays off until you create a unique Manager password in Settings."
      : "Add Tautulli, Plex, and email settings, then let the Manager validate the non-sending setup checks.");
  }
}

function setupWorkflowPresentation(workflow = state.setupWorkflow) {
  if (!workflow?.available) {
    return {
      label: state.editor?.state === "unconfigured" ? "Not configured" : "Not run",
      tone: "neutral",
      summary: state.editor?.state === "unconfigured"
        ? "Complete the guided configuration before setup checks can run."
        : "No setup checks recorded for this configuration.",
    };
  }
  const cacheDisabled = state.cache?.enabled === false && workflow.steps?.cache?.state === "skipped";
  const applicableStepNames = cacheDisabled ? setupWorkflowSteps.filter((name) => name !== "cache") : setupWorkflowSteps;
  const steps = applicableStepNames.map((name) => workflow.steps?.[name]).filter(Boolean);
  const states = steps.map((step) => step.state);
  const active = state.setupWorkflowRunning || states.includes("running");
  if (active) return { label: "Running", tone: "pending", summary: "Setup checks are running. Results appear as each check finishes." };
  if (states.includes("failed")) {
    const retainedChoices = state.setupWorkflow?.steps?.choices?.state === "failed" &&
      state.discovery?.configRevision === state.editor?.revision;
    return {
      label: "Needs review",
      tone: "bad",
      summary: retainedChoices
        ? "Tautulli refresh failed. The Manager is showing the last saved library and user choices."
        : "One or more saved setup checks need review before live delivery.",
    };
  }
  if (states.every((stepState) => stepState === "not-run")) return { label: "Not run", tone: "neutral", summary: "Save your configuration to run setup checks." };
  if (states.includes("waiting")) return { label: "Waiting", tone: "waiting", summary: "One or more setup checks are waiting for a prerequisite." };
  if (states.some((stepState) => ["warning", "skipped"].includes(stepState))) return { label: "Completed with notes", tone: states.includes("warning") ? "warning" : "neutral", summary: "The saved configuration was checked; review the noted result before live delivery." };
  if (states.length === applicableStepNames.length && states.every((stepState) => stepState === "passed")) {
    return {
      label: "Passed",
      tone: "good",
      summary: cacheDisabled
        ? "All enabled checks passed. The deleted-item cache is off."
        : "All setup checks passed.",
    };
  }
  return { label: "Incomplete", tone: "neutral", summary: "Some setup checks have not completed for the saved configuration." };
}

function renderDashboardConfigStatus() {
  const presentation = setupWorkflowPresentation();
  setChip("configuration-status-chip", presentation.label, presentation.tone);
  setText("configuration-status-copy", presentation.summary);
  for (const name of setupWorkflowSteps) {
    const displayState = name === "cache" && state.cache?.enabled === false
      ? "Disabled"
      : titleCase(state.setupWorkflow?.steps?.[name]?.state || "not-run");
    setSwappingText(`configuration-status-${name}`, displayState);
  }
}

const funnelIntegrationStates = new Set([
  "active", "inactive", "starting", "stopping", "manager-password-required", "approval-required", "ready",
  "authorization-required", "tailscale-required", "sign-in-required", "not-running", "funnel-unsupported",
  "migration-required", "needs-attention", "unavailable", "unsupported",
]);

function funnelIntegrationPresentation(remote) {
  if (remote === null || remote === undefined) {
    return { label: "Not checked", detail: "Loading retained status", tone: "neutral", outcome: "" };
  }
  const validShape = typeof remote === "object" && remote !== null &&
    typeof remote.supported === "boolean" && typeof remote.installed === "boolean" &&
    typeof remote.enabled === "boolean" && typeof remote.active === "boolean" &&
    typeof remote.state === "string" && funnelIntegrationStates.has(remote.state) &&
    (remote.cleanupRequired === undefined || typeof remote.cleanupRequired === "boolean") &&
    (remote.passwordRequired === undefined || typeof remote.passwordRequired === "boolean");
  if (!validShape) return { label: "Failed", detail: "Blocked · retained status invalid", tone: "bad", outcome: "failed" };

  const cleanupRequired = remote.cleanupRequired === true;
  const passwordRequired = remote.passwordRequired === true;
  if (!remote.supported) {
    if (remote.enabled || remote.active || cleanupRequired || remote.state !== "unsupported") {
      return { label: "Failed", detail: "Blocked · retained status invalid", tone: "bad", outcome: "failed" };
    }
    return { label: "Not applicable", detail: "Unsupported on this surface", tone: "neutral", outcome: "" };
  }
  if (remote.active) {
    if (remote.enabled && !passwordRequired && remote.state === "active") {
      return { label: "Passed", detail: "Active", tone: "good", outcome: "passed" };
    }
    return { label: "Failed", detail: "Blocked · retained status invalid", tone: "bad", outcome: "failed" };
  }
  if (remote.enabled) {
    if (remote.state === "starting" && !passwordRequired) {
      return { label: "Attention", detail: "Publication pending", tone: "publication-pending", outcome: "warning" };
    }
    if (remote.state === "stopping") {
      return { label: "Attention", detail: "Cleanup pending", tone: "publication-pending", outcome: "warning" };
    }
    return { label: "Failed", detail: passwordRequired ? "Blocked · password lock required" : "Blocked · verification failed", tone: "bad", outcome: "failed" };
  }
  if (cleanupRequired || ["migration-required", "needs-attention", "unavailable"].includes(remote.state)) {
    return { label: "Failed", detail: "Blocked · cleanup or verification required", tone: "bad", outcome: "failed" };
  }
  if (["inactive", "ready", "approval-required", "manager-password-required"].includes(remote.state)) {
    return { label: "Passed", detail: passwordRequired ? "Off · password required before enable" : "Off", tone: "good", outcome: "passed" };
  }
  if (["tailscale-required", "authorization-required", "sign-in-required", "not-running", "funnel-unsupported"].includes(remote.state)) {
    const details = {
      "tailscale-required": "Not configured",
      "authorization-required": "Not configured · host approval required",
      "sign-in-required": "Not configured · sign-in required",
      "not-running": "Not configured · Tailscale stopped",
      "funnel-unsupported": "Not configured · client update required",
    };
    return { label: "Not configured", detail: details[remote.state], tone: "neutral", outcome: "" };
  }
  return { label: "Failed", detail: "Blocked · retained status invalid", tone: "bad", outcome: "failed" };
}

function tailscaleStatusBadgePresentation(remote) {
  if (!remote || typeof remote !== "object") {
    return { active: false, label: "Checking retained status", settingsAvailable: false };
  }
  const settingsAvailable = remote.supported === true;
  const active = settingsAvailable && remote.enabled === true &&
    ((remote.state === "active" && remote.active === true) || remote.state === "starting");
  let label = "Unavailable";
  if (!settingsAvailable) label = remote.state === "unsupported" ? "Unsupported" : "Unavailable";
  else if (remote.state === "inactive") label = "Off";
  else label = tailscaleStatePresentation(remote).label;
  return { active, label, settingsAvailable };
}

function renderTailscaleStatusButton(remote = state.tailscale) {
  const button = byId("tailscale-status-button");
  if (!button) return;
  const presentation = !remote && state.tailscaleError
    ? { active: false, label: "Unavailable", settingsAvailable: false }
    : tailscaleStatusBadgePresentation(remote);
  const tooltip = `Tailscale Funnel: ${presentation.label}`;
  button.classList.toggle("active", presentation.active);
  button.classList.toggle("off", !presentation.active);
  button.setAttribute("aria-disabled", String(!presentation.settingsAvailable));
  button.setAttribute("aria-label", tooltip);
  button.dataset.tooltip = tooltip;
}

function renderIntegrationStatus() {
  const last = state.verification?.last || null;
  const smtp = state.verification?.smtp || null;
  const steps = new Map((last?.steps || []).map((step) => [step.service, step]));
  const retainedLANState = retainedSetupCheckState("lan");
  const retainedSMTPState = retainedSetupCheckState("smtp");
  const tautulliState = steps.get("tautulli")?.state || retainedLANState || "not checked";
  const plexState = steps.get("plex")?.state || retainedLANState || "not checked";
  const smtpState = smtp?.state || retainedSMTPState || "not checked";
  setText("tautulli-state", titleCase(tautulliState));
  setText("plex-state", titleCase(plexState));
  setText("smtp-state", titleCase(smtpState));

  const funnel = funnelIntegrationPresentation(state.tailscale);
  setText("funnel-state", funnel.label);
  setText("funnel-detail", funnel.detail);
  const funnelValue = byId("funnel-integration-value");
    funnelValue.className = "integration-value neutral";
  funnelValue.setAttribute("aria-label", `Tailscale Funnel status: ${funnel.label}; ${funnel.detail}`);
  const funnelLink = byId("funnel-settings-link");
  const settingsAvailable = state.tailscale?.supported === true;
  funnelLink.setAttribute("aria-disabled", String(!settingsAvailable));
  funnelLink.dataset.tooltip = settingsAvailable
    ? `Open Settings > Tailscale Funnel · ${funnel.detail}`
    : `Tailscale Funnel settings unavailable · ${funnel.detail}`;
  funnelLink.setAttribute("aria-label", !settingsAvailable
    ? `Tailscale Funnel: ${funnel.label}; Settings unavailable on this surface`
    : "Tailscale Funnel. Open Settings, Tailscale Funnel.");
  renderTailscaleStatusButton();

  const baseOutcomes = [last?.overall || retainedLANState, smtp?.overall || retainedSMTPState].filter(Boolean);
  const outcomes = [...baseOutcomes, funnel.outcome].filter(Boolean);
  let overall = "not-run";
  if (outcomes.includes("failed")) overall = "failed";
  else if (outcomes.includes("warning")) overall = "warning";
  else if (baseOutcomes.length === 2 && outcomes.every((outcome) => outcome === "passed")) overall = "passed";
  else if (outcomes.length) overall = "partial";
  const verificationActive = state.verificationRunning || state.smtpVerificationRunning;
  const overallTone = verificationActive ? "pending" : overall === "passed" ? "good" : overall === "failed" ? "bad" : overall === "warning" ? "warning" : "neutral";
  const overallLabel = verificationActive ? "Running" : overall === "not-run" ? "Not run" : overall === "warning" ? "Attention" : titleCase(overall);
  setChip("integration-chip", overallLabel, overallTone);
  setText("integration-copy", state.discoveryError && outcomes.length
    ? "The Tautulli choices refresh failed. These connection checks have separate results in Verify."
    : outcomes.length
      ? "Latest connection checks for your saved configuration."
      : "Save your configuration or open Verify to check connections.");
  return { overallLabel, overallTone, funnel };
}

function retainedSetupCheckState(name) {
  const checkState = state.setupWorkflow?.steps?.[name]?.state || "";
  return ["passed", "warning", "failed"].includes(checkState) ? checkState : "";
}

function renderStatus() {
  const snapshot = state.status;
  if (!snapshot) return;
  const overall = snapshot.overall;
  const healthy = overall === "healthy";
  const blocked = overall === "blocked";
  renderDashboardGreeting(snapshot.observedAtUtc);
  setText("observed-time", formatDate(snapshot.observedAtUtc));
  setText("overall-label", titleCase(overall));
  setText("overall-heading", overallHeading(overall));
  setText("overall-copy", overallCopy(overall));
  byId("overall-orb").className = `status-orb ${healthy ? "good" : blocked ? "bad" : ""}`;
  setText("manager-state", titleCase(snapshot.runtime.manager));
  setText("preview-state", titleCase(snapshot.runtime.preview));
  setText("scheduler-state", titleCase(snapshot.runtime.scheduler));
  setChip("runtime-chip", snapshot.runtime.manager === "healthy" ? "Healthy" : "Degraded", snapshot.runtime.manager === "healthy" ? "good" : "bad");
  setText("runtime-copy", `${titleCase(snapshot.readiness.configuration)} configuration · ${titleCase(snapshot.readiness.privateData)} private state.`);
  setText("schedule-installed", yesNo(snapshot.schedule.installed));
  setText("schedule-enabled", yesNo(snapshot.schedule.enabled));
  setText("schedule-ownership", titleCase(snapshot.schedule.ownership));
  renderDashboardScheduleSummary();
  const scheduleOwned = !snapshot.schedule.installed || snapshot.schedule.owned;
  const embeddedSchedule = snapshot.schedule.provider?.startsWith("embedded-");
  const scheduleProbeFailed = ["probe-failed", "heartbeat-stale", "starting"].includes(snapshot.schedule.state);
  const scheduleHealthy = snapshot.schedule.installed && snapshot.schedule.enabled && scheduleOwned;
  setChip("schedule-chip", scheduleProbeFailed ? "Status unavailable" : !scheduleOwned ? "Ownership warning" : scheduleHealthy ? "Active" : snapshot.schedule.installed ? "Disabled" : "Not installed", scheduleProbeFailed || !scheduleOwned ? "bad" : scheduleHealthy ? "good" : "neutral");
  const scheduleCopy = embeddedSchedule
    ? scheduleProbeFailed ? "The embedded scheduler heartbeat is unavailable or stale." : "Read from the package-managed scheduler heartbeat and persistent configuration."
    : scheduleProbeFailed ? "Windows Task Scheduler status could not be verified." : !scheduleOwned ? "A same-named task exists but does not match this installation." : snapshot.schedule.supported ? "Read from Windows Task Scheduler." : "Schedule management is unavailable on this platform.";
  setText("schedule-copy", snapshot.schedule.probeObservedAtUtc ? `${scheduleCopy} Observed ${formatDate(snapshot.schedule.probeObservedAtUtc)}.` : scheduleCopy);
  const deliveryRunning = productionDeliveryIsRunning(snapshot);
  const deliveryAttemptUTC = productionDeliveryStartedAt(snapshot);
  setText("last-attempt", formatDate(deliveryAttemptUTC));
  setSwappingText("last-result", deliveryRunning ? "Running" : titleCase(snapshot.delivery.result));
  setText("last-success", formatDate(snapshot.delivery.lastSuccessUtc));
  setText("timeline-last-attempt", formatDate(deliveryAttemptUTC));
  const rendererEvidence = snapshot.delivery.evidence === "renderer-result";
  setText("last-accepted-count", deliveryRunning ? "In progress" : rendererEvidence ? String(snapshot.delivery.smtpAcceptedCount || 0) : "Not recorded");
  const deliveryFailureCopy = rendererEvidence && snapshot.delivery.errorCategory && snapshot.delivery.errorCategory !== "no-eligible-recipients"
    ? `${rendererFailureCopy(snapshot.delivery.errorCategory, "")}${smtpFailureEvidenceCopy(snapshot.delivery.smtpFailure)}`
    : "";
  setText("delivery-copy", rendererEvidence
    ? deliveryFailureCopy || "Application evidence records SMTP acceptance, not inbox delivery."
    : "Task execution is not presented as SMTP acceptance or inbox delivery.");
  setText("timeline-last-copy", rendererEvidence
    ? `${snapshot.delivery.smtpAcceptedCount || 0} accepted by SMTP · ${snapshot.delivery.skippedCount || 0} skipped · ${snapshot.delivery.failedCount || 0} failed.${householdCopyReport(snapshot.delivery)}`
    : "No sanitized renderer result has been recorded.");
  if (deliveryRunning) {
    setText("delivery-copy", "A production delivery is running. SMTP acceptance will appear automatically when the run finishes.");
    setText("timeline-last-copy", "Production delivery is in progress. Sanitized result evidence will appear automatically when the run finishes.");
  }
  if (rendererEvidence && !deliveryRunning) {
    const deliveryPrefix = snapshot.delivery.errorCategory === "no-eligible-recipients"
      ? "No eligible production recipients; no message was accepted by SMTP."
      : byId("timeline-last-copy").textContent;
    setText("timeline-last-copy", `${deliveryPrefix}${skipReasonCopy(snapshot.delivery.skipReasonCounts)}${snapshot.delivery.errorCategory && snapshot.delivery.errorCategory !== "no-eligible-recipients" ? ` ${rendererFailureCopy(snapshot.delivery.errorCategory, "")}${smtpFailureEvidenceCopy(snapshot.delivery.smtpFailure)}` : ""}`);
  }
  const deliveryTone = deliveryRunning ? "pending" : snapshot.delivery.result === "smtp-accepted" ? "good" : snapshot.delivery.result === "failed" ? "bad" : "neutral";
  setChip("delivery-chip", deliveryRunning ? "Running" : snapshot.delivery.result === "not-recorded" ? "No history" : titleCase(snapshot.delivery.result), deliveryTone);
  byId("delivery-status-icon").classList.toggle("delivery-icon-running", deliveryRunning);
  renderIntegrationStatus();
  renderDashboardConfigStatus();
  const upcoming = scheduleHasUpcomingRun(snapshot);
  setText("next-run", scheduleNextRunText(snapshot, upcoming));
  setText("next-run-utc", upcoming && snapshot.schedule.nextRunUtc
    ? `${formatDate(snapshot.schedule.nextRunUtc, "UTC")} UTC`
    : embeddedSchedule ? "The scheduler has no upcoming run to show." : "Task Scheduler has no upcoming run to show.");
  setText("preview-count", snapshot.previewSummary);
  setTimelineCardState("timeline-upcoming-card", "timeline-ready", upcoming);
  setTimelineCardState("timeline-last-attempt-card", "timeline-success", rendererEvidence && !deliveryRunning && snapshot.delivery.result === "smtp-accepted");
  setTimelineCardState("timeline-previews-card", "timeline-ready", state.previews.length > 0);
  setText("sidebar-platform", packageName());
}

function productionDeliveryOperationIsActive() {
  return state.operation?.type === "send-all" && operationIsActive(state.operation);
}

function productionDeliveryIsRunning(snapshot = state.status) {
  return Boolean(snapshot?.delivery?.running || productionDeliveryOperationIsActive());
}

function productionDeliveryStartedAt(snapshot = state.status) {
  return productionDeliveryOperationIsActive()
    ? state.operation?.startedAtUtc || snapshot?.delivery?.lastAttemptUtc
    : snapshot?.delivery?.lastAttemptUtc;
}

function renderDashboardScheduleSummary() {
  const snapshot = state.status;
  if (!snapshot) return;
  const schedule = snapshot.schedule;
  setText("schedule-next-run", scheduleNextRunText(snapshot));
  const ready = schedule.supported && schedule.installed && schedule.enabled && schedule.owned && state.editor?.state === "ready" && (schedule.provider?.startsWith("embedded-") ? schedule.state === "running" : schedule.state === "ready");
  const discovery = state.discovery;
  const count = discovery?.primaryRecipientCount;
  const known = discovery?.configRevision === state.editor?.revision && Number.isInteger(count) && count >= 0 && !Number.isNaN(Date.parse(discovery?.completedAtUtc));
  const disabled = schedule.state === "running" && schedule.provider?.startsWith("embedded-") && !schedule.enabled;
  setText("schedule-state", ready ? `Ready — ${known ? `${count} recipient${count === 1 ? "" : "s"} (last lookup)` : "recipients unknown"}` : disabled ? "Disabled" : titleCase(schedule.state));
  setText("schedule-recipient-evidence", ready ? known
    ? `Primary recipients as of ${formatDate(discovery.completedAtUtc)}. Household BCC copies are separate. ${state.discoveryError ? "Latest refresh failed. " : ""}Delivery rechecks the live roster; use Refresh to update this count.`
    : "Refresh to check eligible primary recipients. Delivery rechecks the live roster; household BCC copies are separate."
    : "");
}

function scheduleNextRunText(snapshot, upcoming = scheduleHasUpcomingRun(snapshot)) {
  const schedule = snapshot.schedule;
  if (upcoming) return `${formatDate(schedule.nextRunUtc || schedule.nextRunLocal)} (your time)`;
  const disabled = schedule.state === "running" && schedule.provider?.startsWith("embedded-") && !schedule.enabled;
  const unscheduled = schedule.supported && (disabled || ["not-installed", "notinstalled", "disabled"].includes(schedule.state));
  return unscheduled ? "Not scheduled" : "Unavailable";
}

function scheduleHasUpcomingRun(snapshot) {
  const schedule = snapshot?.schedule;
  if (!schedule?.supported || !schedule.installed || !schedule.enabled || !schedule.owned) return false;
  const embedded = schedule.provider?.startsWith("embedded-");
  if (embedded ? schedule.state !== "running" : schedule.state !== "ready") return false;
  const next = new Date(schedule.nextRunUtc || schedule.nextRunLocal || "");
  const observed = new Date(snapshot.observedAtUtc || Date.now());
  return next.getTime() > Math.max(observed.getTime(), Date.now());
}

function setTimelineCardState(id, className, active) {
  byId(id).classList.toggle(className, Boolean(active));
}

function renderDashboardGreeting(observedAtUtc) {
  const observed = new Date(observedAtUtc || Date.now());
  const validObserved = !Number.isNaN(observed.getTime());
  const hour = validObserved ? observed.getHours() : new Date().getHours();
  const minute = validObserved ? observed.getMinutes() : new Date().getMinutes();
  const minuteOfDay = hour * 60 + minute;
  let greeting = "Good evening";
  if (minuteOfDay >= 360 && minuteOfDay <= 720) greeting = "Good morning";
  else if (minuteOfDay >= 721 && minuteOfDay <= 1080) greeting = "Good afternoon";
  const name = discoveredAdministratorName();
  setText("dashboard-greeting", name ? `${greeting}, ${name}.` : `${greeting}.`);
}

function discoveredAdministratorName() {
  const suggestedID = suggestedSelectablePreviewUserID();
  if (!suggestedID) return "";
  const user = discoveredNewsletterUsers().find((candidate) => String(candidate.id) === suggestedID);
  const name = String(user?.name || "").trim();
  return name && !/^User \d+$/i.test(name) ? name : "";
}

function renderSchedule() {
  const snapshot = state.status;
  const editor = state.editor;
  const operation = state.scheduleOperation;
  if (!snapshot || !editor) return;
  const schedule = snapshot.schedule;
  const embeddedSchedule = schedule.provider?.startsWith("embedded-");
  const allowedActions = new Set(state.capabilities?.scheduleActions || []);
  const ready = editor.state === "ready";
  const owned = !schedule.installed || schedule.owned;
  const probeFailed = ["probe-failed", "heartbeat-stale", "starting"].includes(schedule.state);
  const scheduleActive = scheduleOperationIsActive(operation);
  const managerActive = state.operationStarting || operationIsActive(state.operation);
  const blocked = state.scheduleStarting || scheduleActive || managerActive || !ready || !schedule.supported || !owned || probeFailed;

  let chipText = "Not installed";
  let chipTone = "neutral";
  if (!schedule.supported) chipText = "Unsupported";
  else if (probeFailed) { chipText = "Status unavailable"; chipTone = "bad"; }
  else if (!owned) { chipText = "Ownership warning"; chipTone = "bad"; }
  else if (state.scheduleStarting) { chipText = "Starting"; chipTone = "pending"; }
  else if (scheduleActive) { chipText = "Changing"; chipTone = "pending"; }
  else if (schedule.installed && schedule.enabled) { chipText = "Active"; chipTone = "good"; }
  else if (schedule.installed) chipText = "Disabled";
  setChip("schedule-view-chip", chipText, chipTone);

  const day = configEditorValue("ScheduleDay") || "Friday";
  const time = formatScheduleTime(configEditorValue("ScheduleTime") || "09:30");
  setText("schedule-configured-window", ready ? `${day} at ${time} ${embeddedSchedule ? `in the configured ${embeddedRuntimeLabel()} timezone` : "local Windows time"}` : "Complete configuration first");
  setText("schedule-view-installed", yesNo(schedule.installed));
  setText("schedule-view-enabled", yesNo(schedule.enabled));
  setText("schedule-view-ownership", titleCase(schedule.ownership));
  setText("schedule-view-state", titleCase(schedule.state));
  setText("schedule-view-next-run", scheduleNextRunText(snapshot));
  const observed = embeddedSchedule ? snapshot.observedAtUtc : schedule.probeObservedAtUtc;
  setText("schedule-observed", observed ? `Checked ${formatDate(observed)}` : "No scheduler check recorded");

  const warning = byId("schedule-warning");
  warning.className = "schedule-warning";
  if (!schedule.supported) warning.textContent = "Schedule changes are unavailable on this platform.";
  else if (probeFailed) {
    warning.textContent = embeddedSchedule
      ? `Scheduler status is missing or stale. Restart the ${isLinuxService() ? "systemd service" : "container"} and check its timezone before enabling delivery.`
      : "Task Scheduler status could not be verified. The Manager will not request a schedule mutation until the local probe succeeds.";
    warning.classList.add("bad");
  }
  else if (!ready) warning.textContent = "Complete and save configuration before requesting a schedule change.";
  else if (!owned) {
    warning.textContent = "Safety stop: a same-named task exists but its action, working directory, or SYSTEM principal does not match this TautWeekly installation. The Manager will not modify it.";
    warning.classList.add("bad");
  } else if (managerActive) warning.textContent = "Wait for the current preview, test, manual send, or cache refresh before changing the schedule.";
  else if (scheduleActive) warning.textContent = embeddedSchedule ? "A schedule change is in progress." : "A schedule change is in progress. Check for a Windows approval prompt.";
  else warning.textContent = "See Dashboard for the latest delivery result and SMTP acceptance.";

  const installLabel = schedule.installed ? "Refresh" : "Install";
  setSwappingText("schedule-install-heading", installLabel);
  setSwappingText("schedule-install-button-label", installLabel);
  setText("schedule-install-copy", schedule.installed
    ? "Safely refresh the verified SYSTEM task after configuration changes."
    : "Create the verified SYSTEM task from the configured day and local time.");

  for (const button of document.querySelectorAll("[data-schedule-action]")) {
    const action = button.dataset.scheduleAction;
    button.closest("article").hidden = !allowedActions.has(action);
    let available = action === "install";
    if (action === "enable") available = schedule.installed && !schedule.enabled;
    if (action === "disable") available = schedule.installed && schedule.enabled;
    if (action === "remove") available = schedule.installed;
    button.disabled = blocked || !allowedActions.has(action) || !available;
  }

  const confirmation = byId("schedule-confirmation");
  const pending = state.schedulePendingAction;
  confirmation.hidden = !pending;
  if (pending) {
    const copy = scheduleActionCopy(pending, day, time, schedule.installed);
    setText("schedule-confirmation-heading", copy.heading);
    setText("schedule-confirmation-copy", copy.copy);
    setText("schedule-confirm-label", copy.label);
    setText("schedule-confirm-help", copy.help);
    const confirmed = byId("schedule-confirm").checked;
    byId("schedule-confirm-run").disabled = blocked || !confirmed;
    setSwappingButtonText("schedule-confirm-run", state.scheduleStarting ? "Applying schedule change..." : embeddedSchedule ? "Apply schedule change" : "Request administrator approval");
  }
  renderScheduleOperation(operation);
}

function renderScheduleOperation(operation) {
  if (!operation) {
    setText("schedule-current-heading", "No schedule change recorded");
    setText("schedule-current-copy", isServiceRuntime() ? "No embedded scheduler change has been started by this Manager." : "No UAC request has been started by this Manager.");
    setText("schedule-current-time", "Not recorded");
    setChip("schedule-current-chip", "Idle", "neutral");
    return;
  }
  const action = titleCase(operation.action);
  let heading = `${action} schedule ${titleCase(operation.state)}`;
  let copy = "The fixed helper is waiting to report a sanitized result.";
  if (operation.state === "queued") {
    heading = `${action} schedule queued`;
    copy = isServiceRuntime() ? "The revision-checked configuration change is waiting to start." : "Windows may be preparing the UAC approval prompt.";
  } else if (operation.state === "running") {
    heading = `${action} schedule in progress`;
    copy = isServiceRuntime() ? "The Manager is applying one package-defined schedule setting." : "Approve the Windows UAC prompt if it is visible. This operation cannot be changed from browser input.";
  } else if (operation.state === "succeeded") {
    heading = `${action} schedule completed`;
    copy = isServiceRuntime() ? "The Manager saved and verified the embedded scheduler state." : "The helper completed and the Manager observed the expected Task Scheduler state.";
  } else if (operation.state === "failed") {
    heading = `${action} schedule was not completed`;
    copy = scheduleFailureCopy(operation.errorCategory, operation.supportCode);
  }
  setText("schedule-current-heading", heading);
  setText("schedule-current-copy", copy);
  const time = operation.finishedAtUtc ? `Finished ${formatDate(operation.finishedAtUtc)}` : `Started ${formatDate(operation.startedAtUtc)}`;
  setText("schedule-current-time", time);
  setChip("schedule-current-chip", titleCase(operation.state), operation.state === "succeeded" ? "good" : operation.state === "failed" ? "bad" : scheduleOperationIsActive(operation) ? "pending" : "neutral");
}

function configEditorValue(name) {
  return state.editor?.fields?.find((field) => field.name === name)?.value;
}

function scheduleOperationIsActive(operation) {
  return Boolean(operation && ["queued", "running"].includes(operation.state));
}

function scheduleActionCopy(action, day, time, scheduleInstalled = false) {
  if (isServiceRuntime() && action === "enable") return { heading: "Enable future scheduled delivery", copy: `Allow the embedded scheduler to start on ${day} at ${time} in the configured ${embeddedRuntimeLabel()} timezone.`, label: `Enable this ${embeddedRuntimeLabel()} schedule`, help: "This updates persistent configuration and does not send a newsletter immediately." };
  if (isServiceRuntime() && action === "disable") return { heading: "Disable future scheduled starts", copy: "Prevent future embedded-scheduler starts while preserving the package and its data.", label: `Disable this ${embeddedRuntimeLabel()} schedule`, help: "A newsletter delivery already running will not be cancelled." };
  switch (action) {
  case "install": return scheduleInstalled
    ? { heading: "Refresh the weekly task", copy: `Update the verified SYSTEM task for ${day} at ${time} local Windows time.`, label: "Refresh this owned TautWeekly schedule", help: "Windows will request administrator approval. An unrelated same-named task will be left untouched." }
    : { heading: "Install the weekly task", copy: `Create the verified SYSTEM task for ${day} at ${time} local Windows time.`, label: "Install this TautWeekly schedule", help: "Windows will request administrator approval. An unrelated same-named task will be left untouched." };
  case "enable": return { heading: "Enable future scheduled delivery", copy: "Allow the installed and ownership-verified task to start on its configured weekly window.", label: "Enable this verified schedule", help: "This does not send a newsletter immediately." };
  case "disable": return { heading: "Disable future scheduled starts", copy: "Keep the verified task definition but prevent it from starting future newsletter runs.", label: "Disable this verified schedule", help: "A newsletter process already running will not be cancelled." };
  case "remove": return { heading: "Remove the verified schedule", copy: "Delete only the ownership-verified Windows task while preserving configuration, state, history, previews, and logs.", label: "Remove this verified schedule", help: "This cannot be undone from operation history, but it can be installed again later." };
  default: return { heading: "Confirm schedule change", copy: "Review the requested change.", label: "Confirm this schedule change", help: "Windows will request administrator approval." };
  }
}

function scheduleFailureCopy(category, supportCode) {
  const suffix = supportCode ? ` Support code: ${supportCode}.` : "";
  switch (category) {
  case "elevation-declined": return "Windows administrator approval was declined or closed." + suffix;
  case "configuration-changed": return (isServiceRuntime() ? "Configuration changed before the schedule update could be applied." : "Configuration changed while Windows approval was pending. Refresh and review before retrying.") + suffix;
  case "task-not-found": return "The expected verified task was not found. Refresh local status before retrying." + suffix;
  case "task-ownership-mismatch": return "The same-named task did not match this installation and was left untouched." + suffix;
  case "schedule-invalid": return "The saved day or time could not be interpreted safely." + suffix;
  case "renderer-missing": return "The packaged newsletter renderer is unavailable, so the schedule was not enabled." + suffix;
  case "postcondition-failed": return (isServiceRuntime() ? "The requested embedded scheduler state could not be verified." : "The helper returned, but the expected Task Scheduler state could not be verified.") + suffix;
  case "schedule-configuration-read-failed": return "Windows approval succeeded, but the helper could not validate the saved schedule configuration." + suffix;
  case "task-definition-failed": return "Windows approval succeeded, but Task Scheduler rejected the requested schedule definition." + suffix;
  case "task-mutation-failed": return "Windows approval succeeded, but Task Scheduler could not apply the requested change." + suffix;
  case "task-verification-failed": return "Task Scheduler accepted the request, but the helper could not verify the resulting owned task state." + suffix;
  case "task-read-access-failed": return "Task Scheduler accepted the request, but Windows could not grant this signed-in user read-only status access to the task." + suffix;
  case "container-schedule-update-failed": return "The persistent embedded scheduler setting could not be updated. Existing configuration remains available for recovery." + suffix;
  case "container-schedule-verification-failed": return "The Manager saved a scheduler change but could not verify the resulting persistent state. Review configuration and backups before retrying." + suffix;
  case "manager-restarted": return (isServiceRuntime() ? "The Manager restarted while a schedule change was active, so the final result is unknown. Refresh the embedded scheduler status." : "The Manager restarted while elevation was pending, so the final result is unknown. Refresh Task Scheduler status.") + suffix;
  default: return "The schedule helper did not complete successfully. No raw PowerShell output was retained." + suffix;
  }
}

function rendererFailureCopy(category, supportCode) {
  const suffix = supportCode ? ` Support code: ${supportCode}.` : "";
  switch (category) {
  case "operation-busy": return "Another newsletter, update, or scheduled-delivery operation owns the package renderer. Wait for it to finish, then retry." + suffix;
  case "configuration-invalid": return "The renderer could not load the saved configuration snapshot. Review Config, then retry." + suffix;
  case "user-excluded": return "The selected user is excluded by the saved recipient policy. Include and save that user before retrying." + suffix;
  case "tautulli-unavailable": return "The renderer could not complete the required Tautulli data stage. Run Verify, then retry." + suffix;
  case "plex-unavailable": return "Direct Plex verification could not be completed. Review the sanitized evidence under Verify, then retry." + suffix;
  case "asset-unavailable": return "The renderer could not prepare a required local media asset. Review private data-directory access and free space, then retry." + suffix;
  case "render-failed": return "Newsletter HTML construction failed before the operation completed. Review Config and Verify, then retry." + suffix;
  case "output-failed": return "Newsletter HTML was built, but the private preview files could not be written. Review private data-directory access and free space, then retry." + suffix;
  case "smtp-failed": return "The renderer failed during SMTP handoff. Review Verify and the controlled TestEmail workflow before retrying." + suffix;
  case "smtp-auth-failed": return "SMTP authentication was rejected, so the batch stopped after one attempt. Stop retries, confirm the provider account and credentials, then retry only after the provider permits access." + suffix;
  case "smtp-rate-limited": return "The SMTP provider returned a temporary service or rate-limit response, so the batch stopped before another recipient attempt. Stop retries and follow the provider's recovery guidance before trying again." + suffix;
  case "smtp-recipient-rejected": return "The SMTP provider returned an address/mailbox-specific permanent rejection for one recipient; later attempts remained individually isolated and spaced." + suffix;
  case "smtp-provider-rejected": return "The SMTP provider rejected a batch-wide protocol stage, so delivery stopped before another recipient attempt. Review the provider account or SMTP policy before retrying." + suffix;
  case "smtp-transport-failed": return "The SMTP connection ended before message acceptance could begin, so the batch stopped before another recipient attempt. Verify the provider endpoint, then retry cautiously." + suffix;
  case "smtp-acceptance-unknown": return "The SMTP connection closed after message submission but before the server confirmed acceptance. The batch stopped without retrying to avoid a duplicate." + suffix;
  case "user-roster-refresh-failed": return "Tautulli could not confirm a fresh Plex user roster, so production delivery stopped before SMTP. Confirm Tautulli can reach Plex, then retry." + suffix;
  case "platform-unsupported": return "This package does not expose the requested renderer operation." + suffix;
  case "manager-restarted": return "The Manager restarted before it could reconcile the renderer result. Refresh status, then retry." + suffix;
  default: return "The package renderer did not complete successfully. Raw process output was not retained." + suffix;
  }
}

function smtpFailureEvidenceCopy(evidence) {
  if (!evidence || !evidence.stage) return "";
  const stage = titleCase(String(evidence.stage).replaceAll("-", " "));
  const response = Number(evidence.responseCode);
  return ` SMTP stage ${stage}${response > 0 ? ` · response ${response}` : ""}.`;
}

function renderConfig() {
  const config = state.config;
  const grid = byId("config-grid");
  grid.replaceChildren();
  setChip("config-chip", titleCase(config.state), config.valid ? "good" : config.exists ? "bad" : "neutral");
  if (!config.fields.length) {
    const empty = document.createElement("div");
    empty.className = "config-empty";
    empty.textContent = config.exists ? "The configuration could not be displayed safely." : "No private config.json exists yet. Complete guided setup to create it.";
    grid.append(empty);
    return;
  }
  for (const field of config.fields) {
    if (isServiceRuntime() && field.name === "ScheduledTaskName") continue;
    const card = document.createElement("article");
    card.className = `config-field${field.secret ? " secret" : ""}`;
    const label = document.createElement("small");
    label.textContent = `${field.name} · ${field.type}`;
    const value = document.createElement("strong");
    value.textContent = field.secret ? (field.secret.configured ? "Configured · value withheld" : "Not configured") : displayValue(field.value);
    card.append(label, value);
    grid.append(card);
  }
}

function renderConfigEditor() {
  const editor = state.editor;
  const form = byId("config-form");
  const blocked = byId("config-blocked");
  const sections = byId("config-sections");
  clearConfigErrors();
  clearAllRevealedSecrets();
  clearHouseholdPrimary();
  sections.replaceChildren();
  setChip("config-chip", titleCase(editor.state), editor.state === "ready" ? "good" : editor.valid ? "neutral" : "bad");
  form.hidden = !editor.valid;
  blocked.hidden = editor.valid;
  if (!editor.valid) {
    renderDirectPlexNotice();
    renderDiscovery();
    return;
  }

  const fieldsByGroup = new Map(editor.groups.map((group) => [group, []]));
  for (const field of editor.fields) {
    if (configFieldIsHidden(field)) continue;
    if (!fieldsByGroup.has(field.group)) fieldsByGroup.set(field.group, []);
    fieldsByGroup.get(field.group).push(field);
  }
  for (const [group, fields] of fieldsByGroup) {
    if (!fields.length) continue;
    const section = document.createElement("section");
    section.className = "config-section";
    if (group === "Custom text card") section.classList.add("config-section-custom-text-card");
    const heading = document.createElement("div");
    heading.className = "config-section-heading";
    const title = document.createElement("h2");
    title.textContent = group;
    const count = document.createElement("small");
    count.textContent = `${fields.length} ${fields.length === 1 ? "setting" : "settings"}`;
    heading.append(title, count);
    const grid = document.createElement("div");
    grid.className = "config-editor-grid";
    for (const field of fields) grid.append(createConfigControl(field));
    section.append(heading, grid);
    sections.append(section);
  }
  for (const field of editor.fields.filter(configFieldIsHidden)) {
    if (byId(`config-${field.name}`)) continue;
    const input = document.createElement("input");
    input.type = "hidden";
    input.id = `config-${field.name}`;
    input.name = field.name;
    input.value = ["user-email-map", "user-bcc-map"].includes(field.type)
      ? JSON.stringify(field.value && typeof field.value === "object" && !Array.isArray(field.value) ? field.value : {})
      : Array.isArray(field.value) ? field.value.join(", ") : field.value ?? "";
    sections.append(input);
  }
  byId("config-save-copy").textContent = editor.exists
    ? "The Manager backs up your saved configuration and reruns the checks affected by your changes."
    : "The Manager checks your settings, loads Tautulli choices, and generates local previews without sending email.";
  if (Object.keys(editor.issues || {}).length) {
    showConfigErrors("Complete the required setup fields before saving.", editor.issues, false);
  }
  renderDirectPlexNotice();
  renderDiscovery();
  byId("config-CustomTextCardEnabled")?.addEventListener("change", updateConfigSaveAvailability);
  byId("config-CustomTextCardBody")?.addEventListener("input", updateConfigSaveAvailability);
  updateConfigSaveAvailability();
}

function renderDirectPlexNotice() {
  const notice = byId("direct-plex-notice");
  const status = state.editor?.directPlex;
  const visible = Boolean(state.editor?.exists && status && (!status.urlConfigured || (!status.tokenConfigured && !status.runtimeTokenAvailable)));
  notice.hidden = !visible;
  if (!visible) return;
  setText("direct-plex-notice-heading", status.legacyFieldsMissing ? "Add optional Plex settings to an older configuration" : "Complete optional direct Plex access");
  const copy = [];
  if (!status.urlConfigured) {
    copy.push(state.editor.fields?.find((field) => field.name === "PlexServerUrl")?.help || "Enter the Plex URL that TautWeekly can reach.");
  }
  if (!status.tokenConfigured && status.runtimeTokenAvailable) copy.push("TautWeekly can use the Plex token already available to it.");
  else if (!status.tokenConfigured) copy.push("Add a Plex administrator token to connect.");
  setText("direct-plex-notice-copy", copy.join(" "));
}

function reviewDirectPlexFields() {
  const input = byId("config-PlexServerUrl") || byId("config-PlexToken");
  input?.scrollIntoView({ behavior: "smooth", block: "center" });
  setTimeout(() => input?.focus({ preventScroll: true }), 250);
}

function renderDiscovery() {
  renderDashboardScheduleSummary();
  if (state.discovery && state.discovery.configRevision !== state.editor?.revision) state.discovery = null;
  const confirm = byId("discovery-confirm");
  const button = byId("discovery-run-button");
  const ready = state.editor?.state === "ready";
  const networkBusy = state.discoveryRunning || state.verificationRunning || state.smtpVerificationRunning;
  button.disabled = networkBusy || !ready || !confirm.checked;
  setSwappingButtonText("discovery-run-button", state.discoveryRunning ? "Loading choices..." : "Refresh Tautulli choices");
  if (!state.discovery) {
    byId("discovery-results").hidden = true;
    byId("discovery-message").textContent = state.discoveryError || (ready
      ? "The first valid save or a saved Tautulli connection change loads these choices automatically. Confirm above to repeat the saved service lookup now."
      : "Save a complete configuration before loading choices.");
    renderManagedUserDeliveryAddresses();
    renderUserComboboxes();
    return;
  }
  byId("discovery-results").hidden = false;
  byId("discovery-message").textContent = state.discoveryError || (state.discovery.retained
    ? `Cached choices from ${formatDate(state.discovery.completedAtUtc)} are retained locally for this saved configuration.`
    : `Fresh choices loaded ${formatDate(state.discovery.completedAtUtc)} and retained locally for this saved configuration.`);
  renderDiscoveredLibraries();
  renderDiscoveredUsers();
  renderManagedUserDeliveryAddresses();
  renderUserComboboxes();
}

function discoveryFailureMessage(message) {
  const retained = state.discovery?.configRevision === state.editor?.revision ? state.discovery : null;
  if (!retained) return message;
  return `Live refresh failed. Cached choices from ${formatDate(retained.completedAtUtc)} remain visible and usable. ${message}`;
}

function currentListField(name) {
  const input = byId(`config-${name}`);
  if (!input) return [];
  return input.value.split(/[\n,]/).map((value) => value.trim()).filter(Boolean);
}

function setListField(name, values) {
  const input = byId(`config-${name}`);
  if (input) input.value = [...new Set(values)].join(", ");
}

function savedListField(name) {
  const field = (state.editor?.fields || []).find((candidate) => candidate.name === name);
  return Array.isArray(field?.value) ? field.value.map((value) => String(value).trim()).filter(Boolean) : [];
}

let householdLookupEpoch = 0;
function clearHouseholdPrimary() {
  householdLookupEpoch += 1;
  document.querySelectorAll("[data-household-primary]").forEach((node) => { node.textContent = "Primary address hidden"; });
}
function currentHouseholdCopies() {
  try {
    const parsed = JSON.parse(byId("config-UserBccAddresses")?.value || "{}");
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return Object.fromEntries(Object.entries(parsed).map(([id, addresses]) => [id, Array.isArray(addresses) ? addresses.map((address) => String(address ?? "")) : []]));
  } catch (_) { return {}; }
}
function storeHouseholdCopies(assignments) {
  const input = byId("config-UserBccAddresses");
  if (input) input.value = JSON.stringify(assignments);
  updateConfigSaveAvailability();
}
function renderHouseholdCopies() {
  const container = byId("household-copy-list");
  if (!container) return;
  clearHouseholdPrimary();
  container.replaceChildren();
  const saved = state.editor?.fields?.find((field) => field.name === "UserBccAddresses")?.value || {};
  const savedCount = Object.values(saved).filter((addresses) => Array.isArray(addresses) && addresses.length).length;
  setText("household-copy-count", `${savedCount} saved assignment${savedCount === 1 ? "" : "s"}`);
  const users = discoveredNewsletterUsers();
  const select = byId("household-user-select");
  const search = byId("household-user-search");
  const updateChoices = () => {
    const previous = select.value;
    select.replaceChildren(new Option("Choose a source user", ""));
    for (const user of users.filter((user) => user.name.toLowerCase().includes(search.value.toLowerCase()))) {
      select.add(new Option(user.name, String(user.id)));
    }
    select.value = previous;
  };
  search.oninput = updateChoices;
  updateChoices();
  byId("household-add-user").onclick = () => {
    if (!validPreviewUserID(select.value)) return;
    const assignments = currentHouseholdCopies();
    if (!assignments[select.value]) assignments[select.value] = [];
    storeHouseholdCopies(assignments);
    renderHouseholdCopies();
  };
  for (const [id, addresses] of Object.entries(currentHouseholdCopies())) {
    const user = users.find((candidate) => String(candidate.id) === id);
    const row = document.createElement("section"); row.className = "household-copy-row";
    const title = document.createElement("h4"); title.textContent = user?.name || `Unavailable user ${id}`;
    const status = document.createElement("p");
    status.textContent = !user ? "Unavailable: assignment retained until the user returns." : user.archived || user.deleted ? `${titleCase(user.eligibility)}: assignment retained; no copies will be sent.` : userExcludedBySavedPolicy(user) ? "Excluded: no copies will be sent." : user.eligibility === "skipped" ? "Inactive: no copies will be sent." : user.needsDeliveryAddress && !savedUserEmailOverrides()[id] ? "No primary address: add a fallback delivery address first." : "Copies follow this user's production newsletter and Manual Welcome.";
    const primary = document.createElement("p"); primary.dataset.householdPrimary = ""; primary.textContent = "Primary address hidden";
    const view = document.createElement("button"); view.type = "button"; view.className = "button button-secondary"; view.textContent = "View primary address";
    view.disabled = !user;
    view.onclick = async () => {
      const epoch = authenticationEpoch, lookup = householdLookupEpoch, revision = state.editor?.revision;
      view.disabled = true;
      try {
        const result = await request("/api/v1/config/household-primary", { method: "POST", body: JSON.stringify({ expectedRevision: revision, userId: id }) });
        if (epoch !== authenticationEpoch || lookup !== householdLookupEpoch || revision !== state.editor?.revision || byId("view-configuration").hidden || !primary.isConnected) return;
        primary.textContent = result.source === "missing" ? "No primary address" : `${result.address} (${result.source})`;
      } catch (_) {
        if (epoch === authenticationEpoch && lookup === householdLookupEpoch && primary.isConnected) primary.textContent = "Address lookup unavailable. Refresh saved configuration and try again.";
      } finally { if (primary.isConnected) view.disabled = !user; }
    };
    const remove = document.createElement("button"); remove.type = "button"; remove.className = "button button-secondary"; remove.textContent = "Remove assignment";
    remove.onclick = () => { const current = currentHouseholdCopies(); delete current[id]; storeHouseholdCopies(current); renderHouseholdCopies(); };
    row.append(title, status, view, primary);
    for (const [index, address] of addresses.entries()) {
      const line = document.createElement("div"); line.className = "household-address-row";
      const label = document.createElement("label"); label.htmlFor = `household-${id}-${index}`; label.textContent = `Copy address ${index + 1}`;
      const input = document.createElement("input"); input.id = label.htmlFor; input.type = "email"; input.required = true; input.maxLength = 254; input.autocomplete = "off"; input.value = address;
      input.oninput = () => { const current = currentHouseholdCopies(); current[id][index] = input.value; storeHouseholdCopies(current); input.setAttribute("aria-invalid", String(!input.validity.valid)); };
      const drop = document.createElement("button"); drop.type = "button"; drop.className = "button button-secondary"; drop.textContent = `Remove copy ${index + 1}`;
      drop.onclick = () => { const current = currentHouseholdCopies(); current[id].splice(index, 1); storeHouseholdCopies(current); renderHouseholdCopies(); };
      line.append(label, input, drop); row.append(line);
    }
    const add = document.createElement("button"); add.type = "button"; add.className = "button button-secondary"; add.textContent = "Add copy address"; add.disabled = addresses.length >= 20;
    add.onclick = () => { const current = currentHouseholdCopies(); current[id].push(""); storeHouseholdCopies(current); renderHouseholdCopies(); byId(`household-${id}-${current[id].length - 1}`)?.focus(); };
    row.append(add, remove); container.append(row);
  }
}
function householdCopyReport(result) {
  const accepted = result?.bccAcceptedCount || 0, rejected = result?.bccRejectedCount || 0;
  return accepted || rejected ? ` Household copies: ${accepted} accepted, ${rejected} rejected.` : "";
}

function currentUserEmailOverrides() {
  const input = byId("config-UserEmailOverrides");
  if (!input || !input.value) return {};
  try {
    const parsed = JSON.parse(input.value);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
    return Object.fromEntries(Object.entries(parsed).map(([id, address]) => [String(id), String(address ?? "")]));
  } catch (_) {
    return {};
  }
}

function setUserEmailOverride(userID, address) {
  if (!validPreviewUserID(userID)) return;
  const input = byId("config-UserEmailOverrides");
  if (!input) return;
  const assignments = currentUserEmailOverrides();
  if (address === "") delete assignments[userID];
  else assignments[userID] = address;
  input.value = JSON.stringify(assignments);
}

function managedUserAddressState(input, status) {
  const assigned = input.value.trim() !== "";
  const valid = !assigned || input.validity.valid;
  status.textContent = assigned && valid ? "Assigned" : assigned ? "Check address" : "Address needed";
  status.className = `state-chip ${assigned && valid ? "good" : assigned ? "bad" : "warning"}`;
  input.setAttribute("aria-invalid", String(!valid));
}

function discoveredNewsletterUsers() {
  return (state.discovery?.users || []).filter((user) => validPreviewUserID(String(user.id)));
}

function savedUserEmailOverrides() {
  const field = (state.editor?.fields || []).find((candidate) => candidate.name === "UserEmailOverrides");
  const value = field?.value;
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return Object.fromEntries(Object.entries(value).map(([id, address]) => [String(id), String(address ?? "").trim()]));
}

function userExcludedBySavedPolicy(user) {
  const userID = String(user?.id || "");
  if (new Set(savedListField("ExcludedUserIds")).has(userID) || user?.legacyRuleExcluded === true) return true;
  if (user?.needsDeliveryAddress !== true) return false;
  const effectiveAddress = String(savedUserEmailOverrides()[userID] || "").toLowerCase();
  return effectiveAddress !== "" && new Set(savedListField("ExcludedEmails").map((address) => address.toLowerCase())).has(effectiveAddress);
}

function selectableNewsletterUsers() {
  return discoveredNewsletterUsers().filter((user) => !user.archived && !user.deleted && user.eligibility !== "archived" && user.eligibility !== "deleted" && user.eligibility !== "skipped" && !userExcludedBySavedPolicy(user));
}

function validOperationUserID(value) {
  return validPreviewUserID(value) && selectableNewsletterUsers().some((user) => String(user.id) === value);
}

function suggestedSelectablePreviewUserID() {
  const users = selectableNewsletterUsers();
  const owners = users.filter((user) => user.role === "owner");
  if (owners.length === 1) return String(owners[0].id);
  const administrators = users.filter((user) => user.role === "administrator");
  return owners.length === 0 && administrators.length === 1 ? String(administrators[0].id) : "";
}

function reconcileOperationUserSelections() {
  for (const [inputID, confirmationID] of [
    ["preview-user-id", "preview-confirm"],
    ["test-send-user-id", "test-send-confirm"],
    ["manual-send-user-id", "manual-send-confirm"],
  ]) {
    const input = byId(inputID);
    if (!input?.value.trim() || validOperationUserID(input.value.trim())) continue;
    input.value = "";
    const confirmation = byId(confirmationID);
    if (confirmation) confirmation.checked = false;
  }
}

function renderManagedUserDeliveryAddresses() {
  renderHouseholdCopies();
  const card = byId("managed-user-delivery-addresses");
  const container = byId("managed-user-delivery-list");
  const assignments = currentUserEmailOverrides();
  const discovered = discoveredNewsletterUsers();
  const users = [...discovered.filter((user) => user.needsDeliveryAddress === true || Object.hasOwn(assignments, user.id)),
    ...Object.keys(assignments).filter((id) => !discovered.some((user) => user.id === id)).map((id) => ({ id, name: `User ${id}`, eligibility: "unavailable" }))]
    .sort((left, right) => left.name.localeCompare(right.name, undefined, { sensitivity: "base" }));
  card.hidden = !state.discovery || users.length === 0;
  container.replaceChildren();
  if (card.hidden) {
    setText("managed-user-delivery-count", "");
    return;
  }
  const assignedCount = users.filter((user) => String(assignments[user.id] || "").trim() !== "").length;
  setText("managed-user-delivery-count", `${assignedCount} assigned · ${users.length - assignedCount} needed`);
  for (const user of users) {
    const row = document.createElement("div");
    row.className = "managed-user-delivery-row";
    row.setAttribute("role", "listitem");
    const identity = document.createElement("div");
    const label = document.createElement("label");
    const inputID = `managed-user-address-${user.id}`;
    label.htmlFor = inputID;
    label.textContent = user.name;
    const detail = document.createElement("small");
    detail.textContent = `Tautulli user ${user.id}${user.archived || user.deleted || user.eligibility === "unavailable" ? ` · ${titleCase(user.eligibility)} · saved assignment retained` : ""}`;
    identity.append(label, detail);
    const input = document.createElement("input");
    input.id = inputID;
    input.type = "email";
    input.maxLength = 254;
    input.autocomplete = "off";
    input.spellcheck = false;
    input.placeholder = "name@example.com";
    input.value = String(assignments[user.id] || "");
    const status = document.createElement("span");
    status.id = `${inputID}-status`;
    input.setAttribute("aria-describedby", status.id);
    managedUserAddressState(input, status);
    input.addEventListener("input", () => {
      setUserEmailOverride(user.id, input.value);
      managedUserAddressState(input, status);
      const current = currentUserEmailOverrides();
      const count = users.filter((candidate) => String(current[candidate.id] || "").trim() !== "").length;
      setText("managed-user-delivery-count", `${count} assigned · ${users.length - count} needed`);
      updateConfigSaveAvailability();
    });
    row.append(identity, input, status);
    container.append(row);
  }
}

function renderDiscoveredLibraries() {
  const container = byId("discovery-libraries");
  container.replaceChildren();
  const configured = new Set(currentListField("IncludedLibraryIds"));
  const discovered = state.discovery?.libraries || [];
  const libraries = [...discovered, ...[...configured].filter((id) => !discovered.some((item) => item.id === id)).map((id) => ({ id, name: `Library ${id}`, mediaType: "unknown", availability: "unavailable" }))];
  const active = libraries.filter((item) => !item.availability || item.availability === "active");
  setText("discovery-library-count", `${active.length} active${libraries.length > active.length ? ` · ${libraries.length - active.length} unavailable` : ""}`);
  const selected = configured.size ? configured : new Set(active.map((item) => item.id));
  for (const item of libraries) {
    const label = document.createElement("label");
    label.className = "choice-row";
    const input = document.createElement("input");
    input.type = "checkbox";
    input.checked = selected.has(item.id);
    input.disabled = Boolean(item.availability && item.availability !== "active" && !configured.has(item.id));
    input.dataset.choiceId = item.id;
    const copy = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = item.name;
    const detail = document.createElement("small");
    detail.textContent = `${titleCase(item.mediaType)} · section ${item.id}${item.itemCount ? ` · ${item.itemCount} items` : ""}${item.availability && item.availability !== "active" ? ` · ${titleCase(item.availability)}${configured.has(item.id) ? " · saved selection retained" : ""}` : ""}`;
    copy.append(name, detail);
    input.addEventListener("change", () => {
      const unknown = currentListField("IncludedLibraryIds").filter((id) => !libraries.some((library) => library.id === id));
      const known = [...container.querySelectorAll("input:checked")].map((choice) => choice.dataset.choiceId);
      const next = [...unknown, ...known];
      if (next.length === 0) {
        input.checked = true;
        setText("discovery-message", "Keep at least one library selected. Select an active replacement before removing the last saved selection.");
        return;
      }
      setListField("IncludedLibraryIds", next);
    });
    label.append(input, copy);
    container.append(label);
  }
}

function renderDiscoveredUsers() {
  const container = byId("discovery-users");
  container.replaceChildren();
  const users = discoveredNewsletterUsers();
  const configured = new Set(currentListField("ExcludedUserIds"));
  renderDiscoveryUserCount(users);
  const orderedUsers = [...users].sort((left, right) => {
    const leftExcluded = configured.has(left.id) || left.legacyRuleExcluded === true;
    const rightExcluded = configured.has(right.id) || right.legacyRuleExcluded === true;
    if (leftExcluded !== rightExcluded) return leftExcluded ? -1 : 1;
    return left.name.localeCompare(right.name, undefined, { sensitivity: "base" });
  });
  for (const item of orderedUsers) {
    const label = document.createElement("label");
    label.className = "choice-row";
    const input = document.createElement("input");
    input.type = "checkbox";
    const configuredByID = configured.has(item.id);
    const legacyRuleExcluded = item.legacyRuleExcluded === true;
    input.checked = configuredByID || legacyRuleExcluded;
    input.disabled = legacyRuleExcluded;
    input.dataset.choiceId = item.id;
    input.dataset.configuredId = String(configuredByID);
    label.classList.toggle("legacy-exclusion", legacyRuleExcluded);
    const copy = document.createElement("span");
    const name = document.createElement("strong");
    name.textContent = item.name;
    const detail = document.createElement("small");
    detail.textContent = `User ${item.id} · ${titleCase(item.eligibility)}${item.role ? ` · ${titleCase(item.role)}` : ""}${legacyRuleExcluded ? " · Excluded by existing config" : ""}`;
    copy.append(name, detail);
    input.addEventListener("change", () => {
      const unknown = currentListField("ExcludedUserIds").filter((id) => !users.some((user) => user.id === id));
      const known = [...container.querySelectorAll("input:checked")]
        .filter((choice) => !choice.disabled || choice.dataset.configuredId === "true")
        .map((choice) => choice.dataset.choiceId);
      setListField("ExcludedUserIds", [...unknown, ...known]);
      renderDiscoveryUserCount(users);
    });
    label.append(input, copy);
    container.append(label);
  }
}

function renderDiscoveryUserCount(users = discoveredNewsletterUsers()) {
  const current = new Set(currentListField("ExcludedUserIds"));
  const saved = new Set(savedListField("ExcludedUserIds"));
  const changed = users.some((item) => current.has(item.id) !== saved.has(item.id));
  const effective = users.filter((item) => current.has(item.id) || item.legacyRuleExcluded === true).length;
  const count = byId("discovery-user-count");
  count.replaceChildren(document.createTextNode(`${users.length} found`));
  if (effective === 0) return;
  count.append(document.createTextNode(" ● "));
  const status = document.createElement("span");
  status.className = changed ? "discovery-selected-count" : "discovery-excluded-count";
  status.textContent = `${effective} excluded${changed ? " (unsaved)" : ""}`;
  count.append(status);
}

function renderUserDatalist() {
  const list = byId("tautulli-user-choices");
  list.replaceChildren();
  for (const item of selectableNewsletterUsers()) {
    const option = document.createElement("option");
    option.value = item.id;
    option.label = `${item.name} · ${titleCase(item.eligibility)}${item.role ? ` · ${titleCase(item.role)}` : ""}`;
    list.append(option);
  }
}

function renderUserComboboxes() {
  document.querySelectorAll("[data-user-combobox]").forEach((container) => renderUserComboboxOptions(container));
}

function renderUserComboboxOptions(container) {
  const input = container.querySelector("input");
  const list = container.querySelector(".user-combobox-options");
  const query = container.dataset.filter === "true" ? input.value.trim().toLowerCase() : "";
  const users = selectableNewsletterUsers().filter((item) => !query || item.id.includes(query) || item.name.toLowerCase().includes(query));
  list.replaceChildren();
  if (!users.length) {
    const empty = document.createElement("p");
    empty.className = "user-combobox-empty";
    empty.textContent = state.discovery ? "No matching active Tautulli user. Restore archived accounts in Tautulli and refresh choices, or save exclusion changes." : "Load Tautulli choices from Config to browse users.";
    list.append(empty);
    return;
  }
  for (const item of users) {
    const option = document.createElement("button");
    option.type = "button";
    option.className = "user-combobox-option";
    option.setAttribute("role", "option");
    option.setAttribute("aria-selected", String(input.value === item.id));
    option.tabIndex = -1;
    const name = document.createElement("strong");
    name.textContent = item.name;
    const detail = document.createElement("small");
    detail.textContent = `User ${item.id} - ${titleCase(item.eligibility)}${item.role ? ` - ${titleCase(item.role)}` : ""}`;
    option.append(name, detail);
    option.addEventListener("click", () => selectUserComboboxOption(container, item.id));
    option.addEventListener("keydown", (event) => navigateUserComboboxOptions(event, container, option));
    list.append(option);
  }
}

function setUserComboboxOpen(container, open) {
  const input = container.querySelector("input");
  const toggle = container.querySelector(".user-combobox-toggle");
  const list = container.querySelector(".user-combobox-options");
  if (open) renderUserComboboxOptions(container);
  list.hidden = !open;
  container.classList.toggle("open", open);
  input.setAttribute("aria-expanded", String(open));
  toggle.setAttribute("aria-expanded", String(open));
}

function selectUserComboboxOption(container, id) {
  const input = container.querySelector("input");
  input.value = id;
  container.dataset.filter = "false";
  input.dispatchEvent(new Event("input", { bubbles: true }));
  setUserComboboxOpen(container, false);
  input.focus();
}

function navigateUserComboboxOptions(event, container, option) {
  const options = [...container.querySelectorAll(".user-combobox-option")];
  const index = options.indexOf(option);
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    option.click();
  } else if (event.key === "ArrowDown" || event.key === "ArrowUp") {
    event.preventDefault();
    const offset = event.key === "ArrowDown" ? 1 : -1;
    options[(index + offset + options.length) % options.length]?.focus();
  } else if (event.key === "Escape") {
    event.preventDefault();
    setUserComboboxOpen(container, false);
    container.querySelector("input").focus();
  }
}

function initializeUserCombobox(container) {
  const input = container.querySelector("input");
  const toggle = container.querySelector(".user-combobox-toggle");
  input.addEventListener("click", () => {
    if (!container.classList.contains("open")) {
      container.dataset.filter = "false";
      setUserComboboxOpen(container, true);
    }
  });
  input.addEventListener("input", () => {
    container.dataset.filter = "true";
    setUserComboboxOpen(container, true);
  });
  input.addEventListener("keydown", (event) => {
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setUserComboboxOpen(container, true);
      container.querySelector(".user-combobox-option")?.focus();
    } else if (event.key === "Escape") {
      setUserComboboxOpen(container, false);
    }
  });
  toggle.addEventListener("click", () => {
    const open = !container.classList.contains("open");
    container.dataset.filter = "false";
    setUserComboboxOpen(container, open);
    if (open) input.focus();
  });
}

async function runTautulliDiscovery(options = {}) {
  const requireConfirmation = options.requireConfirmation !== false;
  const announceGlobalStatus = options.announceGlobalStatus !== false;
  const recoverPendingPreviews = options.recoverPendingPreviews !== false;
  const discoveryAuthenticationEpoch = authenticationEpoch;
  if (state.discoveryRunning || state.verificationRunning || state.smtpVerificationRunning || state.editor?.state !== "ready" || (requireConfirmation && !byId("discovery-confirm").checked)) return false;
  let refreshed = false;
  state.discoveryError = "";
  state.discoveryRunning = true;
  renderDiscovery();
  renderVerification();
  if (announceGlobalStatus) setGlobalStatus("Loading private Tautulli choices...");
  try {
    const discovery = await request("/api/v1/discovery/tautulli", {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision, confirmRealNetwork: true }),
    });
    if (discoveryAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return false;
    state.discovery = discovery;
    reconcileOperationUserSelections();
    refreshed = true;
    state.discoveryError = "";
    if (state.status) renderDashboardGreeting(state.status.observedAtUtc);
    byId("discovery-confirm").checked = false;
    if (announceGlobalStatus) setGlobalStatus("Tautulli choices loaded and retained locally.", true);
  } catch (error) {
    if (discoveryAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return false;
    state.discoveryError = discoveryFailureMessage(error.message);
    if (announceGlobalStatus) setGlobalStatus(state.discoveryError, true);
  } finally {
    if (discoveryAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) {
      try {
        await refreshConfigurationStatus();
      } catch (_) {
        // The manual result remains visible even if the durable summary cannot be refreshed.
      }
      if (discoveryAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) {
        state.discoveryRunning = false;
        renderDiscovery();
        renderVerification();
        if (refreshed && recoverPendingPreviews) await recoverPendingPreviewsFromChoices(discoveryAuthenticationEpoch);
      }
    }
  }
  return refreshed;
}

function createConfigControl(field) {
  const control = document.createElement("div");
  control.className = `config-control config-control-${field.type}`;
  control.dataset.configField = field.name;
  const heading = document.createElement("span");
  heading.className = "config-control-heading";
  const label = document.createElement("strong");
  label.textContent = field.label;
  label.id = `config-label-${field.name}`;
  const key = document.createElement("small");
  key.textContent = field.required ? `${field.name} · required` : field.name;
  heading.append(label, key);
  control.append(heading);

  const id = `config-${field.name}`;
  let input;
  if (field.type === "boolean") {
    input = document.createElement("input");
    input.type = "checkbox";
    input.checked = Boolean(field.value);
    const toggle = document.createElement("label");
    toggle.className = "config-toggle";
    toggle.htmlFor = id;
    toggle.append(input, document.createElement("span"));
    const stateLabel = document.createElement("em");
    stateLabel.textContent = input.checked ? "Enabled" : "Disabled";
    input.addEventListener("change", () => { stateLabel.textContent = input.checked ? "Enabled" : "Disabled"; });
    toggle.append(stateLabel);
    control.append(toggle);
  } else if (field.type === "select") {
    input = document.createElement("select");
    for (const optionValue of field.options || []) {
      const option = document.createElement("option");
      option.value = optionValue;
      option.textContent = optionValue;
      option.selected = String(field.value) === optionValue;
      input.append(option);
    }
    control.append(input);
  } else if (field.type === "textarea") {
    input = document.createElement("textarea");
    input.rows = 6;
    input.value = field.value ?? "";
    if (field.max !== undefined) input.maxLength = Number(field.max);
    control.append(input);
  } else if (field.type === "range") {
    input = document.createElement("input");
    input.type = "range";
    input.min = String(field.min ?? 0);
    input.max = String(field.max ?? 100);
    input.step = "1";
    input.value = field.value ?? "0";
    const shell = document.createElement("span");
    shell.className = "config-range";
    const output = document.createElement("output");
    output.value = `${input.value}%`;
    output.textContent = output.value;
    input.addEventListener("input", () => {
      output.value = `${input.value}%`;
      output.textContent = output.value;
    });
    shell.append(input, output);
    control.append(shell);
  } else if (field.type === "color") {
    input = document.createElement("input");
    input.type = "color";
    input.value = field.value || "#72aef7";
    const shell = document.createElement("span");
    shell.className = "config-color";
    const output = document.createElement("output");
    output.value = input.value.toUpperCase();
    output.textContent = output.value;
    input.addEventListener("input", () => {
      output.value = input.value.toUpperCase();
      output.textContent = output.value;
    });
    shell.append(input, output);
    control.append(shell);
  } else {
    input = document.createElement("input");
    input.type = configInputType(field.type);
    input.placeholder = field.type === "secret" && field.secret?.configured
      ? "Stored value will be preserved"
      : field.type === "secret" && field.secret?.availableFromRuntime
        ? "Runtime value available · paste only to store a copy"
        : field.placeholder || "";
    if (field.type === "integer") {
      if (field.min !== undefined) input.min = String(field.min);
      if (field.max !== undefined) input.max = String(field.max);
      input.step = "1";
      input.value = field.value ?? "";
    } else if (field.type === "string-list" || field.type === "email-list") {
      input.value = Array.isArray(field.value) ? field.value.join(", ") : "";
    } else if (field.type !== "secret") {
      if (field.max !== undefined) input.maxLength = Number(field.max);
      input.value = field.value ?? "";
    }
    if (field.type === "secret") {
      input.autocomplete = "new-password";
      const shell = document.createElement("span");
      shell.className = "secret-input-shell";
      const toggle = document.createElement("button");
      toggle.type = "button";
      toggle.className = "secret-toggle-button";
      toggle.disabled = !field.secret?.configured;
      toggle.append(createMaterialIcon("visibility"));
      shell.append(input, toggle);
      control.append(shell);
      input.addEventListener("input", () => {
        const active = activeSecretReveals.get(field.name);
        if (active && input.value !== active.value) forgetSecretReveal(field.name, false);
        if (!input.value && !field.secret?.configured) input.type = "password";
        toggle.disabled = !input.value && !field.secret?.configured;
        updateSecretToggle(field, input, toggle);
      });
      toggle.addEventListener("click", () => toggleSecretVisibility(field, input, toggle));
      updateSecretToggle(field, input, toggle);
    } else {
      control.append(input);
    }
  }
  input.id = id;
  input.name = field.name;
  input.setAttribute("aria-labelledby", label.id);
  if (field.name === "CustomTextCardTitle") attachTitleGifPicker(control, input);

  if (field.type === "secret") {
    const secretLine = document.createElement("span");
    secretLine.className = "secret-state";
    const stateText = document.createElement("span");
    stateText.textContent = field.secret?.configured
      ? "Configured - hidden by default"
      : field.secret?.availableFromRuntime
        ? "Available from this runtime - not copied"
        : "Not configured";
    stateText.id = `config-secret-state-${field.name}`;
    secretLine.append(stateText);
    if (field.secret?.configured) {
      const clearLabel = document.createElement("label");
      clearLabel.className = "secret-clear";
      const clear = document.createElement("input");
      clear.type = "checkbox";
      clear.id = `config-clear-${field.name}`;
      clearLabel.append(clear, " Clear stored value");
      secretLine.append(clearLabel);
      input.addEventListener("input", () => { if (input.value) clear.checked = false; });
      clear.addEventListener("change", () => {
        if (clear.checked) {
          forgetSecretReveal(field.name, true);
          input.value = "";
          input.type = "password";
          const toggle = control.querySelector(".secret-toggle-button");
          if (toggle) updateSecretToggle(field, input, toggle);
        }
      });
    }
    control.append(secretLine);
  }
  if (field.help) {
    const help = document.createElement("span");
    help.className = "config-help";
    help.textContent = field.help;
    control.append(help);
  }
  const error = document.createElement("span");
  error.className = "config-field-error";
  error.id = `config-error-${field.name}`;
  control.append(error);
  return control;
}

function attachTitleGifPicker(control, titleInput) {
  const configured = String(configEditorValue("CustomTextCardTitleGif") || "none");
  const selectedID = titleGifChoices.some((choice) => choice.id === configured) ? configured : "none";
  const assetInput = document.createElement("input");
  assetInput.type = "hidden";
  assetInput.id = "config-CustomTextCardTitleGif";
  assetInput.name = "CustomTextCardTitleGif";
  assetInput.value = selectedID;

  const shell = document.createElement("div");
  shell.className = "title-gif-field";
  titleInput.replaceWith(shell);
  shell.append(titleInput);

  const trigger = document.createElement("button");
  trigger.type = "button";
  trigger.className = "title-gif-trigger";
  trigger.dataset.materialSymbol = "add_reaction";
  trigger.dataset.fill = "0";
  trigger.dataset.weight = "400";
  trigger.dataset.grade = "0";
  trigger.dataset.opticalSize = "24";
  trigger.setAttribute("aria-haspopup", "listbox");
  trigger.setAttribute("aria-expanded", "false");
  trigger.setAttribute("aria-controls", "custom-title-gif-picker");
  const reactionIcon = createMaterialIcon("add-reaction");
  trigger.append(reactionIcon);

  const picker = document.createElement("div");
  picker.className = "title-gif-picker";
  picker.id = "custom-title-gif-picker";
  picker.dataset.titleGifPicker = "";
  picker.setAttribute("role", "listbox");
  picker.setAttribute("aria-label", "Optional title GIF");
  picker.hidden = true;

  const heading = document.createElement("div");
  heading.className = "title-gif-picker-heading";
  const headingText = document.createElement("strong");
  headingText.textContent = "Title GIF";
  const headingHint = document.createElement("small");
  headingHint.textContent = "18 x 18 px · select again to remove";
  heading.append(headingText, headingHint);
  picker.append(heading);

  const grid = document.createElement("div");
  grid.className = "title-gif-options";
  const optionButtons = [];
  const selectChoice = (choice, focus = false) => {
    assetInput.value = choice.id;
    trigger.classList.toggle("selected", choice.id !== "none");
    trigger.setAttribute("aria-label", choice.id === "none" ? "Choose an optional title GIF; none selected" : `Change optional title GIF; ${choice.label} selected`);
    trigger.replaceChildren();
    if (choice.file) {
      const selectedImage = document.createElement("img");
      selectedImage.className = "title-gif-trigger-image";
      selectedImage.src = `/media/${choice.file}`;
      selectedImage.alt = "";
      selectedImage.width = 24;
      selectedImage.height = 24;
      trigger.append(selectedImage);
    } else {
      trigger.append(reactionIcon);
    }
    let selectedButton = null;
    for (const button of optionButtons) {
      const selected = button.dataset.titleGifId === choice.id;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-selected", String(selected));
      button.setAttribute("aria-label", selected ? `${button.dataset.titleGifLabel} selected; activate again to remove` : button.dataset.titleGifLabel);
      button.tabIndex = selected ? 0 : -1;
      if (selected) selectedButton = button;
      if (selected && focus) button.focus();
    }
    if (!selectedButton && optionButtons[0]) optionButtons[0].tabIndex = 0;
  };
  const closePicker = (restoreFocus = false) => {
    picker.hidden = true;
    shell.classList.remove("open");
    trigger.setAttribute("aria-expanded", "false");
    if (restoreFocus) trigger.focus();
  };
  const openPicker = () => {
    document.querySelectorAll("[data-title-gif-picker]").forEach((element) => {
      if (element !== picker) element.hidden = true;
    });
    picker.hidden = false;
    shell.classList.add("open");
    trigger.setAttribute("aria-expanded", "true");
    (optionButtons.find((button) => button.getAttribute("aria-selected") === "true") || optionButtons[0])?.focus();
  };

  for (const choice of titleGifChoices) {
    const option = document.createElement("button");
    option.type = "button";
    option.className = "title-gif-option";
    option.dataset.titleGifId = choice.id;
    option.dataset.titleGifLabel = choice.label;
    option.setAttribute("role", "option");
    const thumbnail = document.createElement("span");
    thumbnail.className = "title-gif-thumbnail";
    const image = document.createElement("img");
    image.src = `/media/${choice.file}`;
    image.alt = "";
    image.width = 42;
    image.height = 42;
    thumbnail.append(image);
    const optionLabel = document.createElement("span");
    optionLabel.textContent = choice.label;
    option.append(thumbnail, optionLabel);
    option.addEventListener("click", () => {
      selectChoice(assetInput.value === choice.id ? noTitleGifChoice : choice);
      closePicker(true);
    });
    option.addEventListener("keydown", (event) => {
      const index = optionButtons.indexOf(option);
      let target = -1;
      if (["Enter", " "].includes(event.key)) {
        event.preventDefault();
        selectChoice(assetInput.value === choice.id ? noTitleGifChoice : choice);
        closePicker(true);
        return;
      }
      if (["ArrowRight", "ArrowDown"].includes(event.key)) target = (index + 1) % optionButtons.length;
      if (["ArrowLeft", "ArrowUp"].includes(event.key)) target = (index - 1 + optionButtons.length) % optionButtons.length;
      if (event.key === "Home") target = 0;
      if (event.key === "End") target = optionButtons.length - 1;
      if (event.key === "Escape") {
        event.preventDefault();
        closePicker(true);
        return;
      }
      if (target >= 0) {
        event.preventDefault();
        optionButtons[target].focus();
      }
    });
    optionButtons.push(option);
    grid.append(option);
  }
  picker.append(grid);
  trigger.addEventListener("click", () => picker.hidden ? openPicker() : closePicker());
  trigger.addEventListener("keydown", (event) => {
    if (["Delete", "Backspace"].includes(event.key) && assetInput.value !== "none") {
      event.preventDefault();
      selectChoice(noTitleGifChoice);
      closePicker();
      return;
    }
    if (["Enter", " "].includes(event.key)) {
      event.preventDefault();
      picker.hidden ? openPicker() : closePicker(true);
      return;
    }
    if (["ArrowDown", "ArrowUp"].includes(event.key)) {
      event.preventDefault();
      openPicker();
    }
  });
  shell.append(trigger, picker, assetInput);
  selectChoice(titleGifChoices.find((choice) => choice.id === selectedID) || noTitleGifChoice);
}

function updateSecretToggle(field, input, button) {
  const hasValue = input.value !== "";
  const visible = hasValue && input.type === "text";
  button.classList.toggle("visible", visible);
  button.setAttribute("aria-pressed", String(visible));
  if (visible) button.setAttribute("aria-label", `Hide ${field.label}`);
  else if (hasValue) button.setAttribute("aria-label", `Show ${field.label}`);
  else button.setAttribute("aria-label", `Reveal saved ${field.label}`);
}

function toggleSecretVisibility(field, input, button) {
  if (input.value) {
    input.type = input.type === "password" ? "text" : "password";
    updateSecretToggle(field, input, button);
    return;
  }
  if (field.secret?.configured) openSecretReveal(field, input, button);
}

function openSecretReveal(field, input, button) {
  pendingSecretReveal = { field, input, button };
  const passwordRequired = Boolean(state.authAccess?.authenticationRequired);
  byId("secret-reveal-title").textContent = `Reveal ${field.label}`;
  byId("secret-reveal-eyebrow").textContent = passwordRequired ? "Administrator confirmation" : "Explicit local reveal";
  byId("secret-reveal-copy").textContent = passwordRequired
    ? "Re-enter your Manager administrator password. Only this value will be returned, and it will clear automatically after 30 seconds."
    : "Confirm this one local reveal. Only the selected value will be returned, and it will clear automatically after 30 seconds.";
  byId("secret-reveal-message").textContent = "";
  const passwordInput = byId("secret-reveal-password");
  passwordInput.value = "";
  concealMaskedInputs(byId("secret-reveal-form"));
  passwordInput.hidden = !passwordRequired;
  passwordInput.closest(".masked-input-shell").hidden = !passwordRequired;
  passwordInput.required = passwordRequired;
  byId("secret-reveal-password-label").hidden = !passwordRequired;
  byId("secret-reveal-dialog").showModal();
  (passwordRequired ? passwordInput : byId("secret-reveal-submit")).focus();
}

async function submitSecretReveal(event) {
  event.preventDefault();
  const target = pendingSecretReveal;
  if (!target) return;
  const submit = byId("secret-reveal-submit");
  const passwordInput = byId("secret-reveal-password");
  submit.disabled = true;
  const passwordRequired = Boolean(state.authAccess?.authenticationRequired);
  setSwappingButtonText("secret-reveal-submit", passwordRequired ? "Verifying..." : "Revealing...");
  byId("secret-reveal-message").textContent = "";
  try {
    const result = await request(`/api/v1/config/secrets/${encodeURIComponent(target.field.name)}/reveal`, {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision, password: passwordInput.value }),
    });
    passwordInput.value = "";
    clearAllRevealedSecrets();
    target.input.value = result.value;
    target.input.type = "text";
    const timer = setTimeout(() => forgetSecretReveal(target.field.name, true), 30000);
    activeSecretReveals.set(target.field.name, { value: result.value, input: target.input, button: target.button, timer });
    const stateText = byId(`config-secret-state-${target.field.name}`);
    if (stateText) stateText.textContent = "Revealed temporarily - clears in 30 seconds";
    updateSecretToggle(target.field, target.input, target.button);
    byId("secret-reveal-dialog").close();
    target.input.focus();
    setGlobalStatus(`${target.field.label} revealed temporarily.`, true);
  } catch (error) {
    passwordInput.value = "";
    byId("secret-reveal-message").textContent = error.message;
    (passwordRequired ? passwordInput : submit).focus();
  } finally {
    submit.disabled = false;
    setSwappingButtonText("secret-reveal-submit", "Reveal for 30 seconds");
  }
}

function forgetSecretReveal(name, clearValue) {
  const active = activeSecretReveals.get(name);
  if (!active) return;
  clearTimeout(active.timer);
  activeSecretReveals.delete(name);
  if (clearValue && active.input.value === active.value) active.input.value = "";
  active.input.type = "password";
  const field = state.editor?.fields.find((candidate) => candidate.name === name);
  const stateText = byId(`config-secret-state-${name}`);
  if (stateText) stateText.textContent = "Configured - hidden by default";
  if (field) updateSecretToggle(field, active.input, active.button);
}

function clearAllRevealedSecrets() {
  for (const name of [...activeSecretReveals.keys()]) forgetSecretReveal(name, true);
}

function closeSecretRevealDialog() {
  byId("secret-reveal-password").value = "";
  concealMaskedInputs(byId("secret-reveal-form"));
  byId("secret-reveal-message").textContent = "";
  pendingSecretReveal = null;
  if (byId("secret-reveal-dialog").open) byId("secret-reveal-dialog").close();
}

function configInputType(type) {
  if (["url", "email", "time", "password", "color"].includes(type)) return type;
  if (type === "integer") return "number";
  if (type === "secret") return "password";
  return "text";
}

function collectConfigSaveRequest() {
  const values = {};
  const secrets = {};
  for (const field of state.editor.fields) {
    const input = byId(`config-${field.name}`);
    if (field.type === "secret") {
      const clear = byId(`config-clear-${field.name}`);
      if (clear?.checked) secrets[field.name] = { action: "clear" };
      else if (activeSecretReveals.get(field.name)?.value === input.value) secrets[field.name] = { action: "preserve" };
      else if (input.value !== "") secrets[field.name] = { action: "replace", value: input.value };
      else secrets[field.name] = { action: "preserve" };
    } else if (field.type === "boolean") {
      values[field.name] = input.checked;
    } else if (field.type === "integer" || field.type === "range") {
      values[field.name] = input.value === "" ? null : Number(input.value);
    } else if (field.type === "string-list" || field.type === "email-list") {
      values[field.name] = input.value.split(/[\n,]/).map((value) => value.trim()).filter(Boolean);
    } else if (field.type === "user-bcc-map") {
      values[field.name] = currentHouseholdCopies();
    } else if (field.type === "user-email-map") {
      values[field.name] = currentUserEmailOverrides();
    } else {
      values[field.name] = input.value;
    }
  }
  return { expectedRevision: state.editor.revision, values, secrets };
}

const setupWorkflowSteps = ["choices", "lan", "smtp", "previews", "cache"];

function beginSetupWorkflow(plan) {
  state.setupWorkflowRunning = Boolean(plan?.runDiscovery || plan?.runIntegration || plan?.runSmtp || plan?.generatePreviews || plan?.warmCache || plan?.verifyCache);
  renderSetupWorkflow();
}

function updateSetupWorkflowStep(name, stepState, summary) {
  if (!state.setupWorkflow?.steps?.[name]) return;
  state.setupWorkflow.steps[name] = { state: stepState, summary };
  renderSetupWorkflow();
}

function renderSetupWorkflow() {
  const panel = byId("setup-workflow");
  if (!panel) return;
  if (!state.setupWorkflow) {
    panel.hidden = true;
    return;
  }
  panel.hidden = false;
  const presentation = setupWorkflowPresentation();
  setChip("setup-workflow-chip", presentation.label, presentation.tone);
  setText("setup-workflow-summary", presentation.summary);
  for (const name of setupWorkflowSteps) {
    const step = state.setupWorkflow.steps[name] || { state: "not-run", summary: "This check has not been recorded for the saved configuration." };
    setSwappingText(`setup-${name}-summary`, step.summary);
    const tone = step.state === "passed" ? "good" : step.state === "failed" ? "bad"
      : step.state === "waiting" ? "waiting" : step.state === "running" ? "pending"
        : step.state === "warning" ? "warning" : "neutral";
    const label = name === "cache" && state.cache?.enabled === false ? "Disabled" : titleCase(step.state);
    setChip(`setup-${name}-chip`, label, tone);
    const row = byId(`setup-${name}-step`);
    row.classList.toggle("active", step.state === "running");
  }
  renderDashboardConfigStatus();
}

async function refreshConfigurationStatus() {
  const configurationStatus = await request("/api/v1/config/status");
  state.setupWorkflow = configurationStatus?.available ? configurationStatus : null;
  state.cache = configurationStatus?.cache || null;
  renderSetupWorkflow();
}

async function retainSkippedPreviewStatus(revision, reason) {
  try {
    const configurationStatus = await request("/api/v1/config/status/previews/skipped", {
      method: "POST",
      body: JSON.stringify({ expectedRevision: revision, reason }),
    });
    state.setupWorkflow = configurationStatus?.available ? configurationStatus : state.setupWorkflow;
    state.cache = configurationStatus?.cache || state.cache;
  } catch (_) {
    // The local result remains visible; a later refresh will load the durable server record.
  }
  renderSetupWorkflow();
}

async function startCacheWarmOperation(revision) {
  if (!revision || state.editor?.state !== "ready" || operationIsActive(state.operation) || scheduleOperationIsActive(state.scheduleOperation)) return false;
  state.operationStarting = true;
  state.operationStartingType = "cache-warm";
  updateSetupWorkflowStep("cache", "running", "Refreshing cache coverage for every included user's selected-library newsletter items...");
  renderOperations();
  renderVerification();
  try {
    state.operation = await request("/api/v1/operations", {
      method: "POST",
      body: JSON.stringify({ type: "cache-warm", expectedRevision: revision }),
    });
    manageOperationPolling();
    return true;
  } catch (error) {
    updateSetupWorkflowStep("cache", "failed", error.message);
    return false;
  } finally {
    state.operationStarting = false;
    state.operationStartingType = "";
    renderOperations();
    renderVerification();
  }
}

async function recoverPendingCacheWarm(expectedAuthenticationEpoch = authenticationEpoch) {
  if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
  const cacheState = state.setupWorkflow?.steps?.cache?.state || "";
  if (!["waiting", "running"].includes(cacheState) || state.cache?.enabled === false || state.editor?.state !== "ready"
      || operationIsActive(state.operation) || scheduleOperationIsActive(state.scheduleOperation)) return;
  await startCacheWarmOperation(state.editor.revision);
}

async function runPostSaveSetup(revision, plan) {
  let previewStarted = false;
  let cacheStarted = false;
  let discovered = state.discovery?.configRevision === revision ? state.discovery : null;
  let discoveryFailed = false;
  if (plan.runDiscovery) {
    state.discoveryError = "";
    state.discoveryRunning = true;
    updateSetupWorkflowStep("choices", "running", "Loading active libraries, users, and any explicit owner or administrator role...");
    renderDiscovery();
    renderVerification();
    try {
      discovered = await request("/api/v1/discovery/tautulli", {
        method: "POST",
        body: JSON.stringify({ expectedRevision: revision, confirmRealNetwork: true }),
      });
      state.discovery = discovered;
      state.discoveryError = "";
      if (state.status) renderDashboardGreeting(state.status.observedAtUtc);
      const activeLibraryCount = (discovered.libraries || []).filter((library) => !library.availability || library.availability === "active").length;
      updateSetupWorkflowStep("choices", "passed", `${activeLibraryCount} active libraries and ${discovered.users?.length || 0} users loaded and retained locally.`);
    } catch (error) {
      discoveryFailed = true;
      state.discoveryError = discoveryFailureMessage(error.message);
      updateSetupWorkflowStep("choices", "failed", state.discoveryError);
    } finally {
      state.discoveryRunning = false;
      renderDiscovery();
      renderVerification();
    }
  }

  if (plan.runIntegration) {
    state.verificationRunning = true;
    updateSetupWorkflowStep("lan", "running", "Testing the saved Tautulli and direct Plex endpoints...");
    renderDiscovery();
    renderVerification();
    try {
      const result = await request("/api/v1/checks/integrations", {
        method: "POST",
        body: JSON.stringify({ expectedRevision: revision, confirmRealNetwork: true }),
      });
      state.verification = { ...state.verification, last: result };
      updateSetupWorkflowStep("lan", result.overall, result.overall === "passed"
        ? "Tautulli and direct Plex verification passed. Detailed evidence is available under Verify."
        : "The connection checks completed with a result that needs review under Verify.");
    } catch (error) {
      updateSetupWorkflowStep("lan", "failed", error.message);
    } finally {
      state.verificationRunning = false;
      renderDiscovery();
      renderVerification();
    }
  }

  if (plan.runSmtp) {
    state.smtpVerificationRunning = true;
    updateSetupWorkflowStep("smtp", "running", "Checking SMTP reachability and STARTTLS without authenticating or sending...");
    renderDiscovery();
    renderVerification();
    try {
      const result = await request("/api/v1/checks/smtp-network", {
        method: "POST",
        body: JSON.stringify({ expectedRevision: revision, confirmRealNetwork: true }),
      });
      state.verification = { ...state.verification, smtp: result };
      updateSetupWorkflowStep("smtp", result.overall, result.summary);
    } catch (error) {
      updateSetupWorkflowStep("smtp", "failed", error.message);
    } finally {
      state.smtpVerificationRunning = false;
      renderDiscovery();
      renderVerification();
    }
  }

  if (plan.warmCache) {
    if (discoveryFailed) {
      updateSetupWorkflowStep("cache", "failed", "Deleted-item cache refresh could not start because the included user and library choices were unavailable.");
    } else if (operationIsActive(state.operation) || scheduleOperationIsActive(state.scheduleOperation)) {
      updateSetupWorkflowStep("cache", "failed", "Deleted-item cache refresh could not start while another local operation was active.");
    } else {
      cacheStarted = await startCacheWarmOperation(revision);
    }
  } else if (plan.verifyCache) {
    await runCacheVerification({ automatic: true, expectedRevision: revision });
  }

  const suggestedUserID = suggestedSelectablePreviewUserID();
  if (plan.generatePreviews && !cacheStarted && discoveryFailed) {
    updateSetupWorkflowStep("previews", "skipped", "Preview generation was skipped because Tautulli choices could not be refreshed. Resolve the discovery result, then use Refresh Tautulli choices to continue without another save.");
    await retainSkippedPreviewStatus(revision, "discovery-failed");
  } else if (plan.generatePreviews && !cacheStarted && !discovered) {
    updateSetupWorkflowStep("previews", "skipped", "Preview generation was skipped because no retained Tautulli choices are available. Refresh Tautulli choices to continue without another save.");
    await retainSkippedPreviewStatus(revision, "choices-unavailable");
  } else if (plan.generatePreviews && !cacheStarted && !validOperationUserID(suggestedUserID)) {
    updateSetupWorkflowStep("previews", "skipped", "Tautulli did not expose one unambiguous included owner or administrator ID. Include and save a user if needed, then choose one under Previews to generate the six local states manually.");
    await retainSkippedPreviewStatus(revision, "owner-not-found");
  } else if (plan.generatePreviews && !cacheStarted && (operationIsActive(state.operation) || scheduleOperationIsActive(state.scheduleOperation))) {
    updateSetupWorkflowStep("previews", "skipped", "Another Manager or schedule operation is active. Generate previews manually after it finishes.");
    await retainSkippedPreviewStatus(revision, "operation-active");
  } else if (plan.generatePreviews && !cacheStarted) {
    state.operationStarting = true;
    state.operationStartingType = "preview-all";
    updateSetupWorkflowStep("previews", "running", "Starting six local newsletter previews for the verified owner or administrator...");
    renderOperations();
    try {
      state.operation = await request("/api/v1/operations", {
        method: "POST",
        body: JSON.stringify({ type: "preview-all", expectedRevision: revision, userId: suggestedUserID, confirmNoSend: true }),
      });
      previewStarted = true;
      updateSetupWorkflowStep("previews", "running", "Six-state local preview generation started. No email will be sent; progress is available under Previews.");
      manageOperationPolling();
    } catch (error) {
      updateSetupWorkflowStep("previews", error.code === "operation-busy" || error.code === "schedule-busy" ? "skipped" : "failed", error.message);
    } finally {
      state.operationStarting = false;
      state.operationStartingType = "";
      renderOperations();
    }
  }

  if (state.setupWorkflow) state.setupWorkflow.running = false;
  state.setupWorkflowRunning = false;
  try {
    await refreshConfigurationStatus();
  } catch (_) {
    renderSetupWorkflow();
  }
  try {
    const [status, verification] = await Promise.all([
      request("/api/v1/status"),
      request("/api/v1/checks/integrations"),
    ]);
    state.status = status;
    state.verification = verification || { last: null, smtp: null };
    renderStatus();
    renderVerification();
  } catch (_) {
    renderDashboardConfigStatus();
    renderIntegrationStatus();
  }
  try {
    const diagnostics = await request("/api/v1/diagnostics");
    const diagnosticMaximum = Number(diagnostics.maximumEntries) || 20;
    state.diagnostics = { ...diagnostics, maximumEntries: diagnosticMaximum, events: (diagnostics.events || []).slice(0, diagnosticMaximum) };
    renderAbout();
  } catch (_) {
    // Diagnostics are supplementary; the individual setup results remain visible.
  }
  return { cachePending: cacheStarted, previewPending: previewStarted };
}

async function recoverPendingPreviewsFromChoices(expectedAuthenticationEpoch = authenticationEpoch) {
  if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
  const revision = state.editor?.revision || "";
  const previewState = state.setupWorkflow?.steps?.previews?.state || "not-run";
  const suggestedUserID = state.discovery?.configRevision === revision ? suggestedSelectablePreviewUserID() : "";
  if (!["not-run", "waiting", "failed", "skipped"].includes(previewState)
      || !validOperationUserID(suggestedUserID)
      || operationIsActive(state.operation)
      || scheduleOperationIsActive(state.scheduleOperation)) return;

  state.operationStarting = true;
  state.operationStartingType = "preview-all";
  updateSetupWorkflowStep("previews", "running", "Starting six local newsletter previews from the refreshed choices...");
  renderOperations();
  try {
    const operation = await request("/api/v1/operations", {
      method: "POST",
      body: JSON.stringify({ type: "preview-all", expectedRevision: revision, userId: suggestedUserID, confirmNoSend: true }),
    });
    if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    state.operation = operation;
    updateSetupWorkflowStep("previews", "running", "Six-state local preview generation started. No email will be sent; progress is available under Previews.");
    manageOperationPolling();
    setGlobalStatus("Preview generation resumed without another configuration save.", true);
  } catch (error) {
    if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    updateSetupWorkflowStep("previews", error.code === "operation-busy" || error.code === "schedule-busy" ? "skipped" : "failed", error.message);
  } finally {
    if (expectedAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) {
      state.operationStarting = false;
      state.operationStartingType = "";
      renderOperations();
    }
  }
}

function customTextCardBodyMissing() {
  return Boolean(byId("config-CustomTextCardEnabled")?.checked && !byId("config-CustomTextCardBody")?.value.trim());
}

function updateConfigSaveAvailability() {
  const button = byId("config-save-button");
  if (!button) return;
  const missing = customTextCardBodyMissing();
  const enabled = Boolean(byId("config-CustomTextCardEnabled")?.checked);
  const input = byId("config-CustomTextCardBody");
  const control = document.querySelector('[data-config-field="CustomTextCardBody"]');
  const error = byId("config-error-CustomTextCardBody");
  button.disabled = button.dataset.busy === "true" || missing;
  if (input) {
    input.required = enabled;
    input.setAttribute("aria-required", String(enabled));
  }
  if (missing && error) {
    error.textContent = "Card body text is required when the custom text card is enabled.";
    error.dataset.liveValidation = "true";
    input?.setAttribute("aria-invalid", "true");
    if (input) input.dataset.liveValidation = "true";
    control?.classList.add("invalid");
  } else if (error?.dataset.liveValidation === "true") {
    error.textContent = "";
    delete error.dataset.liveValidation;
    if (input?.dataset.liveValidation === "true") {
      input.removeAttribute("aria-invalid");
      delete input.dataset.liveValidation;
      control?.classList.remove("invalid");
    }
  }
}

function savedWithoutVerificationMessage(plan) {
  switch (plan?.confirmationCode) {
  case "cache-enabled": return "Cache enabled.";
  case "cache-disabled": return "Cache disabled.";
  case "cache-updated": return "Cache settings saved.";
  default: {
    const categories = plan?.changedCategories || [];
    if (categories.length === 1 && categories[0] === "email") return "Email settings saved.";
    if (categories.length === 1 && categories[0] === "schedule") return "Schedule settings saved.";
    if (categories.length === 1 && categories[0] === "newsletter") return "Newsletter delivery settings saved.";
    return "Configuration saved. Existing checks and previews remain valid.";
  }
  }
}

async function submitConfig(event) {
  event.preventDefault();
  if (customTextCardBodyMissing()) {
    updateConfigSaveAvailability();
    return;
  }
  clearConfigErrors();
  const saveButton = byId("config-save-button");
  saveButton.dataset.busy = "true";
  updateConfigSaveAvailability();
  byId("config-reset-button").disabled = true;
  setSwappingButtonText("config-save-button", "Saving...");
  setGlobalStatus("Validating local configuration...");
  try {
    const result = await request("/api/v1/config", { method: "PUT", body: JSON.stringify(collectConfigSaveRequest()) });
    state.editor = result.editor;
    if (!result.saved) {
      if (!result.postSave?.verifyCache) {
        setGlobalStatus("No material configuration changes were found. No checks or preview work ran.", true);
        return;
      }
      beginSetupWorkflow(result.postSave);
      setGlobalStatus("Configuration is unchanged. Running the full local cache verification...");
      await runCacheVerification({ automatic: true, expectedRevision: result.editor.revision });
      state.setupWorkflowRunning = false;
      setGlobalStatus("Configuration is unchanged and the full local cache verification finished.", true);
      return;
    }
    await loadAll();
    selectView("configuration");
    beginSetupWorkflow(result.postSave);
    if (!result.postSave?.materialChange) {
      setGlobalStatus(result.backup ? "Configuration normalized and backed up. No checks or preview work were needed." : "Configuration normalized. No checks or preview work were needed.", true);
      return;
    }
    const hasPostSaveWork = Boolean(result.postSave.runDiscovery || result.postSave.runIntegration || result.postSave.runSmtp || result.postSave.generatePreviews || result.postSave.warmCache || result.postSave.verifyCache);
    if (!hasPostSaveWork) {
      setGlobalStatus(savedWithoutVerificationMessage(result.postSave), true);
      return;
    }
    setGlobalStatus(result.backup ? "Configuration saved and backed up. Running only affected checks..." : "Configuration saved. Running only affected checks...");
    const setup = await runPostSaveSetup(result.editor.revision, result.postSave);
    setGlobalStatus(setup.cachePending
      ? "Deleted-item cache refresh is running. Full local cache verification will follow automatically."
      : setup.previewPending
        ? "Preview generation is running. Review it under Previews when complete."
        : "Affected save verification finished. Review the results above.", true);
  } catch (error) {
    showConfigErrors(error.message, error.fields);
    setGlobalStatus(error.message, true);
  } finally {
    delete saveButton.dataset.busy;
    updateConfigSaveAvailability();
    byId("config-reset-button").disabled = false;
    setSwappingButtonText("config-save-button", "Validate, save, and verify");
  }
}

function showConfigErrors(message, fields = {}, scroll = true) {
  const alert = byId("config-errors");
  const list = byId("config-error-list");
  list.replaceChildren();
  const names = Object.keys(fields).sort();
  if (!names.length) {
    const item = document.createElement("li");
    item.textContent = message;
    list.append(item);
  }
  for (const name of names) {
    const item = document.createElement("li");
    const field = state.editor.fields.find((candidate) => candidate.name === name);
    item.textContent = `${field?.label || name}: ${fields[name]}`;
    list.append(item);
    const controlName = name === "CustomTextCardTitleGif" ? "CustomTextCardTitle" : name;
    const control = document.querySelector(`[data-config-field="${CSS.escape(controlName)}"]`);
    control?.classList.add("invalid");
    const input = byId(`config-${name}`);
    input?.setAttribute("aria-invalid", "true");
    const error = byId(`config-error-${controlName}`);
    if (error) error.textContent = fields[name];
  }
  alert.hidden = false;
  if (scroll) alert.scrollIntoView({ block: "start" });
}

function clearConfigErrors() {
  byId("config-errors").hidden = true;
  byId("config-error-list").replaceChildren();
  document.querySelectorAll("[data-config-field]").forEach((control) => control.classList.remove("invalid"));
  document.querySelectorAll("[data-config-field] input, [data-config-field] select, [data-config-field] textarea").forEach((input) => input.removeAttribute("aria-invalid"));
  document.querySelectorAll(".config-field-error").forEach((error) => { error.textContent = ""; });
}

function renderBackups() {
  const list = byId("backup-list");
  list.replaceChildren();
  setText("backup-count", state.backups.length ? `${state.backups.length} / ${state.backupMaximum} · newest first` : `0 / ${state.backupMaximum}`);
  if (!state.backups.length) {
    const empty = document.createElement("div");
    empty.className = "config-empty";
    empty.textContent = "No backup exists yet. The first update to an existing config.json creates one automatically.";
    list.append(empty);
    return;
  }
  for (const backup of state.backups) {
    const row = document.createElement("article");
    row.className = "backup-row";
    const copy = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = formatDate(backup.createdAtUtc);
    const detail = document.createElement("small");
    detail.textContent = `${formatBytes(backup.sizeBytes)} · revision ${String(backup.revision || "").slice(0, 10)}`;
    copy.append(title, detail);
    const restoreButton = document.createElement("button");
    restoreButton.type = "button";
    restoreButton.className = "button button-secondary";
    restoreButton.textContent = "Restore";
    restoreButton.setAttribute("aria-label", `Restore configuration backup from ${formatDate(backup.createdAtUtc)}`);
    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "button button-danger";
    deleteButton.textContent = "Delete";
    deleteButton.setAttribute("aria-label", `Delete configuration backup from ${formatDate(backup.createdAtUtc)}`);
    const cancel = document.createElement("button");
    cancel.type = "button";
    cancel.className = "button button-secondary";
    cancel.textContent = "Cancel";
    cancel.hidden = true;
    const actions = document.createElement("div");
    actions.className = "backup-actions";
    const resetConfirmation = () => {
      delete row.dataset.backupAction;
      row.classList.remove("armed");
      restoreButton.hidden = false;
      restoreButton.className = "button button-secondary";
      setSwappingButtonElementText(restoreButton, "Restore");
      restoreButton.setAttribute("aria-label", `Restore configuration backup from ${formatDate(backup.createdAtUtc)}`);
      deleteButton.hidden = false;
      deleteButton.className = "button button-danger";
      setSwappingButtonElementText(deleteButton, "Delete");
      deleteButton.setAttribute("aria-label", `Delete configuration backup from ${formatDate(backup.createdAtUtc)}`);
      cancel.hidden = true;
    };
    restoreButton.addEventListener("click", () => {
      if (row.dataset.backupAction === "restore") {
        restoreBackup(backup, restoreButton, cancel);
        return;
      }
      row.dataset.backupAction = "restore";
      row.classList.add("armed");
      deleteButton.hidden = true;
      restoreButton.className = "button button-danger";
      setSwappingButtonElementText(restoreButton, "Confirm restore");
      restoreButton.setAttribute("aria-label", `Confirm restore of configuration backup from ${formatDate(backup.createdAtUtc)}`);
      cancel.hidden = false;
    });
    deleteButton.addEventListener("click", () => {
      if (row.dataset.backupAction === "delete") {
        deleteBackup(backup, deleteButton, cancel);
        return;
      }
      row.dataset.backupAction = "delete";
      row.classList.add("armed");
      restoreButton.hidden = true;
      setSwappingButtonElementText(deleteButton, "Confirm delete");
      deleteButton.setAttribute("aria-label", `Permanently delete configuration backup from ${formatDate(backup.createdAtUtc)}`);
      cancel.hidden = false;
    });
    cancel.addEventListener("click", resetConfirmation);
    actions.append(cancel, restoreButton, deleteButton);
    row.append(copy, actions);
    list.append(row);
  }
}

async function deleteBackup(backup, button, cancel) {
  button.disabled = true;
  cancel.disabled = true;
  setSwappingButtonElementText(button, "Deleting...");
  setGlobalStatus("Deleting the selected local configuration backup...");
  try {
    await request(`/api/v1/config/backups/${encodeURIComponent(backup.id)}`, { method: "DELETE" });
    const result = await request("/api/v1/config/backups");
    state.backupMaximum = Number(result.maximumEntries) || 10;
    state.backups = (result.backups || []).slice(0, state.backupMaximum);
    renderBackups();
    setGlobalStatus("Configuration backup deleted permanently.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
    button.disabled = false;
    cancel.disabled = false;
    setSwappingButtonElementText(button, "Confirm delete");
  }
}

async function restoreBackup(backup, button, cancel) {
  button.disabled = true;
  cancel.disabled = true;
  setSwappingButtonElementText(button, "Restoring...");
  setGlobalStatus("Validating and restoring the selected backup...");
  try {
    const result = await request(`/api/v1/config/backups/${encodeURIComponent(backup.id)}/restore`, {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision }),
    });
    await loadAll();
    selectView("configuration");
    setGlobalStatus(result.safetyBackup ? "Backup restored. The replaced configuration was saved as a new safety backup." : "Backup restored.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    button.disabled = false;
    cancel.disabled = false;
    setSwappingButtonElementText(button, "Restore");
  }
}

function verificationResultTone(checkState) {
  if (checkState === "passed") return "good";
  if (checkState === "failed") return "bad";
  if (checkState === "waiting") return "waiting";
  if (checkState === "running") return "pending";
  if (checkState === "warning") return "warning";
  return "neutral";
}

function prepareVerificationResults(container) {
  Array.from(container.children).forEach((child) => { child.dataset.verificationCurrent = "false"; });
}

function finishVerificationResults(container) {
  Array.from(container.children).forEach((child) => {
    if (child.dataset.verificationCurrent !== "true") child.remove();
  });
}

function appendVerificationResult(container, heading, checkState, summaryText) {
  const key = `result:${heading}`;
  let card = Array.from(container.children).find((child) => child.dataset.verificationKey === key);
  if (!card) {
    card = document.createElement("article");
    card.dataset.verificationKey = key;
    const top = document.createElement("div");
    top.className = "card-topline";
    const title = document.createElement("h2");
    const chip = document.createElement("span");
    const label = document.createElement("span");
    label.className = "state-chip-label";
    chip.append(label);
    top.append(title, chip);
    const summary = document.createElement("p");
    card.append(top, summary);
    container.append(card);
  }
  card.dataset.verificationCurrent = "true";
  const tone = verificationResultTone(checkState);
  card.className = `verification-result ${checkState} state-card-${tone}`;
  const title = card.querySelector("h2");
  const chip = card.querySelector("span");
  const label = chip.querySelector(".state-chip-label");
  const summary = card.querySelector("p");
  setSwappingElementText(title, heading);
  setSwappingElementText(label, titleCase(checkState));
  chip.className = `state-chip ${tone}`;
  setSwappingElementText(summary, summaryText);
}

function appendVerificationEmpty(container, text) {
  const key = "empty";
  let empty = Array.from(container.children).find((child) => child.dataset.verificationKey === key);
  if (!empty) {
    empty = document.createElement("div");
    empty.className = "config-empty";
    empty.dataset.verificationKey = key;
    container.append(empty);
  }
  empty.dataset.verificationCurrent = "true";
  setSwappingElementText(empty, text);
}

function renderVerification() {
  const last = state.verification?.last || null;
  const smtp = state.verification?.smtp || null;
  const cache = state.cache;
  const ready = state.editor?.state === "ready";
  const networkBusy = state.verificationRunning || state.smtpVerificationRunning || state.discoveryRunning || state.cacheVerificationRunning;
  const operationBusy = state.operationStarting || operationIsActive(state.operation) || state.scheduleStarting || scheduleOperationIsActive(state.scheduleOperation);
  const cacheDisabled = cache?.enabled === false;
  const cacheWorkflowState = state.setupWorkflow?.steps?.cache?.state || "";
  const results = byId("verification-results");
  const smtpResults = byId("smtp-verification-results");
  const cacheResults = byId("cache-verification-results");
  const confirm = byId("verification-confirm");
  const smtpConfirm = byId("smtp-verification-confirm");
  const runButton = byId("verification-run-button");
  const smtpRunButton = byId("smtp-verification-run-button");
  const cacheRunButton = byId("cache-verification-run-button");
  prepareVerificationResults(results);
  prepareVerificationResults(smtpResults);
  prepareVerificationResults(cacheResults);
  runButton.disabled = networkBusy || !confirm.checked || !ready;
  smtpRunButton.disabled = networkBusy || !smtpConfirm.checked || !ready;
  cacheRunButton.disabled = cacheDisabled ? !ready : networkBusy || operationBusy || !ready;
  setSwappingButtonText("verification-run-button", state.verificationRunning ? "Testing saved services..." : "Test connections");
  setSwappingButtonText("smtp-verification-run-button", state.smtpVerificationRunning ? "Checking SMTP..." : "Check SMTP connection");
  setSwappingButtonText("cache-verification-run-button", cacheDisabled
    ? "Enable Cache Storage"
    : state.cacheVerificationRunning ? "Checking cache..." : "Check deleted-item cache");

  if (!ready) {
    byId("verification-message").textContent = "Complete and save configuration before running a connection test.";
    byId("smtp-verification-message").textContent = "Save your configuration before checking SMTP.";
    byId("cache-verification-message").textContent = "Complete and save configuration before checking local cache storage.";
  } else {
    byId("verification-message").textContent = state.verificationRunning
      ? "Contacting the saved Tautulli and direct Plex services. This may take up to 45 seconds."
      : "No service request occurs until the confirmation is checked and the button is pressed.";
    byId("smtp-verification-message").textContent = state.smtpVerificationRunning
      ? "Checking the SMTP connection without signing in or sending mail. This may take up to 45 seconds."
      : "Confirm above to check the saved SMTP connection.";
    byId("cache-verification-message").textContent = cacheDisabled
      ? "Open Config to review the deleted-item cache settings. This action does not toggle or save anything."
      : state.cacheVerificationRunning
        ? "Checking the bounded manifest, local write access, and cached artwork without contacting any service."
        : operationBusy
          ? "Wait for the current preview, test, manual send, cache refresh, or schedule change. A cache refresh checks its result automatically."
          : cache?.verification === "full"
            ? "The latest full result is retained. Use this optional recheck after later filesystem or configuration changes."
            : "A successful save runs this full local check automatically; use the button for an optional recheck.";
  }

  const retainedLANState = retainedSetupCheckState("lan");
  const retainedSMTPState = retainedSetupCheckState("smtp");
  if (last) {
    setText("verification-observed", `Checked ${formatDate(last.completedAtUtc)}.${state.discoveryError ? " The failed Tautulli choices refresh did not rerun this check." : ""}`);
    for (const step of last.steps || []) {
      appendVerificationResult(results, step.service === "plex" ? "Direct Plex" : titleCase(step.service), step.state, step.summary);
    }
  } else if (retainedLANState) {
    const checked = state.setupWorkflow.steps.lan.updatedAtUtc;
    setText("verification-observed", checked ? `Checked ${formatDate(checked)} during setup.` : "From the saved setup checks.");
    appendVerificationResult(results, "Tautulli and Plex", retainedLANState, state.setupWorkflow.steps.lan.summary);
  } else {
    setText("verification-observed", "No connection check recorded for this configuration.");
    appendVerificationEmpty(results, "Save your configuration or run the connection test above.");
  }

  if (smtp) {
    setText("smtp-verification-observed", `Completed ${formatDate(smtp.completedAtUtc)} · ${titleCase(smtp.security)}.`);
    appendVerificationResult(smtpResults, "SMTP connection", smtp.state, smtp.summary);
  } else if (retainedSMTPState) {
    const checked = state.setupWorkflow.steps.smtp.updatedAtUtc;
    setText("smtp-verification-observed", checked ? `Checked ${formatDate(checked)} during setup.` : "From the saved setup checks.");
    appendVerificationResult(smtpResults, "SMTP connection", retainedSMTPState, state.setupWorkflow.steps.smtp.summary);
  } else {
    setText("smtp-verification-observed", "No SMTP connection check recorded for this configuration.");
    appendVerificationEmpty(smtpResults, "Save your configuration or check the SMTP connection above.");
  }

  if (["waiting", "running"].includes(cacheWorkflowState) && !cacheDisabled) {
    const workflowSummary = state.setupWorkflow?.steps?.cache?.summary
      || (cacheWorkflowState === "waiting"
        ? "Waiting for the local cache refresh to start."
        : "Checking deleted-item cache storage and artwork locally.");
    setText("cache-verification-observed", cacheWorkflowState === "waiting" ? "Waiting for the local cache refresh to start." : "Cache refresh and verification are running locally.");
    appendVerificationResult(cacheResults, "Deleted-item cache", cacheWorkflowState, workflowSummary);
    appendVerificationResult(cacheResults, "Storage and bounds", cacheWorkflowState,
      cacheWorkflowState === "waiting" ? "Waiting for cache initialization before checking storage and bounds." : "Checking writable storage, retention, and configured bounds.");
    appendVerificationResult(cacheResults, "Manifest and artwork", cacheWorkflowState,
      cacheWorkflowState === "waiting" ? "Waiting for cache initialization before checking the manifest and artwork." : "Checking the manifest, backup, and cached artwork integrity.");
  } else if (cache) {
    if (cache.enabled === false) {
      setText("cache-verification-observed", `Saved setting checked ${formatDate(cache.checkedAtUtc)} · cache storage was not inspected.`);
      appendVerificationResult(cacheResults, "Deleted-item cache", "disabled", cache.summary);
    } else {
      const mode = cache.verification === "full" ? "full local verification" : "read-only status";
      setText("cache-verification-observed", `Checked ${formatDate(cache.checkedAtUtc)} · ${mode}.`);
      appendVerificationResult(cacheResults, "Deleted-item cache", cache.state, cache.summary);
      const cleanupPending = cache.expiredEntryCount > 0 || cache.orphanArtworkCount > 0
        || cache.entryCount > cache.maxItems || cache.artworkBytes > cache.maxBytesMb * 1024 * 1024;
      const storageState = cache.writability === "failed" ? "failed"
        : ["passed", "previously-evidenced"].includes(cache.writability) && !cleanupPending ? "passed" : cache.state === "skipped" ? "skipped" : "warning";
      appendVerificationResult(cacheResults, "Storage and bounds", storageState,
        `${titleCase(cache.writability)} · ${cache.entryCount} of ${cache.maxItems} entries · ${formatBytes(cache.artworkBytes)} of ${cache.maxBytesMb} MB cache ceiling · ${cache.retentionDays}-day retention.`);
      const integrityState = cache.integrityState === "failed" ? "failed"
        : ["verified", "structural"].includes(cache.integrityState) ? "passed" : cache.integrityState === "skipped" ? "skipped" : "warning";
      appendVerificationResult(cacheResults, "Manifest and artwork", integrityState,
        `${titleCase(cache.manifestState)} · backup ${titleCase(cache.backupState)} · ${cache.artworkCount} artwork files · ${cache.missingArtworkCount} missing · ${cache.orphanArtworkCount} orphaned · ${cache.hashMismatchCount} hash mismatches · ${cache.expiredEntryCount} expired.`);
    }
  } else {
    setText("cache-verification-observed", "No deleted-item cache status is available for this saved configuration.");
    appendVerificationEmpty(cacheResults, "Validate and save to run the full local cache verification automatically.");
  }
  finishVerificationResults(results);
  finishVerificationResults(smtpResults);
  finishVerificationResults(cacheResults);

  const integration = renderIntegrationStatus();
  let overallLabel = integration.overallLabel;
  let overallTone = integration.overallTone;
  if (cacheWorkflowState === "waiting") {
    overallLabel = "Waiting";
    overallTone = "waiting";
  } else if (state.cacheVerificationRunning || cacheWorkflowState === "running") {
    overallLabel = "Running";
    overallTone = "pending";
  } else if (cache?.state === "failed") {
    overallLabel = "Needs review";
    overallTone = "bad";
  } else if (cache?.state === "warning" && overallTone !== "bad") {
    overallLabel = "Completed with notes";
    overallTone = "warning";
  } else if (["passed", "skipped"].includes(cache?.state) && integration.overallLabel === "Passed") {
    overallLabel = "Passed";
    overallTone = "good";
  }
  setChip("verification-chip", overallLabel, overallTone);
}

async function runCacheVerification(options = {}) {
  if (state.verificationRunning || state.smtpVerificationRunning || state.discoveryRunning || state.cacheVerificationRunning || state.editor?.state !== "ready" || state.cache?.enabled === false) return null;
  const automatic = Boolean(options.automatic);
  const expectedRevision = options.expectedRevision || state.editor.revision;
  state.cacheVerificationRunning = true;
  updateSetupWorkflowStep("cache", "running", "Checking deleted-item cache storage, bounds, manifest, backup, writability, and artwork integrity...");
  renderVerification();
  setGlobalStatus(automatic ? "Running the automatic full local cache verification..." : "Rechecking deleted-item cache storage and artwork locally...");
  try {
    const result = await request("/api/v1/checks/deleted-item-cache", {
      method: "POST",
      body: JSON.stringify({ expectedRevision }),
    });
    state.cache = result;
    if (state.setupWorkflow?.steps) {
      state.setupWorkflow.steps.cache = { state: result.state, summary: result.summary, updatedAtUtc: result.checkedAtUtc };
    }
    renderSetupWorkflow();
    const completedMessage = automatic ? "Automatic deleted-item cache verification completed" : "Deleted-item cache recheck completed";
    setGlobalStatus(result.state === "failed" ? `${completedMessage} with a problem.` : `${completedMessage}.`, true);
    return result;
  } catch (error) {
    updateSetupWorkflowStep("cache", "failed", "Full deleted-item cache verification could not complete. Review the local Manager diagnostics and retry.");
    setGlobalStatus(error.message, true);
    return null;
  } finally {
    state.cacheVerificationRunning = false;
    renderVerification();
  }
}

function handleCacheVerificationAction() {
  if (state.cache?.enabled === false) {
    selectView("configuration", { section: "cache" });
    return;
  }
  void runCacheVerification();
}

async function runVerification() {
  if (state.verificationRunning || state.smtpVerificationRunning || state.discoveryRunning || !byId("verification-confirm").checked || state.editor?.state !== "ready") return;

  let completed = false;
  state.verificationRunning = true;
  const button = byId("verification-run-button");
  setSwappingButtonText("verification-run-button", "Testing saved services...");
  renderVerification();
  renderDiscovery();
  setGlobalStatus("Running Tautulli and direct Plex connection checks...");
  try {
    const result = await request("/api/v1/checks/integrations", {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision, confirmRealNetwork: true }),
    });
    completed = true;
    state.verification = { ...state.verification, last: result };
    byId("verification-confirm").checked = false;
    setGlobalStatus(result.overall === "failed" ? "Connection test completed with failures." : "Connection test completed.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.verificationRunning = false;
    setSwappingButtonText("verification-run-button", "Test connections");
    try {
      await refreshConfigurationStatus();
    } catch (_) {
      // The detailed result is already visible; a later refresh will load its durable server record.
    }
    renderVerification();
    renderDiscovery();
    if (completed) await recoverPendingPreviewsFromChoices();
  }
}

async function runSMTPVerification() {
  if (state.verificationRunning || state.smtpVerificationRunning || state.discoveryRunning || !byId("smtp-verification-confirm").checked || state.editor?.state !== "ready") return;
  state.smtpVerificationRunning = true;
  renderVerification();
  renderDiscovery();
  setGlobalStatus("Checking the SMTP connection...");
  try {
    const result = await request("/api/v1/checks/smtp-network", {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision, confirmRealNetwork: true }),
    });
    state.verification = { ...state.verification, smtp: result };
    byId("smtp-verification-confirm").checked = false;
    const message = result.overall === "failed"
      ? "The SMTP connection check failed. The check did not sign in or send mail."
      : result.overall === "warning"
        ? "SMTP is reachable, but the saved configuration has STARTTLS disabled."
        : "The SMTP connection check passed. Use a test send to check sign-in and message acceptance.";
    setGlobalStatus(message, true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.smtpVerificationRunning = false;
    try {
      await refreshConfigurationStatus();
    } catch (_) {
      // The detailed result is already visible; a later refresh will load its durable server record.
    }
    renderVerification();
    renderDiscovery();
  }
}

function previewScenarioIndex(preview) {
  const match = String(preview?.name || "").match(/^preview-all-(\d{2})-/i);
  return match ? Number(match[1]) : Number.MAX_SAFE_INTEGER;
}

function previewDisplayName(preview) {
  const name = String(preview?.name || "");
  const scenarios = [
    [/-00-index(?:\.html)?$/i, "Index"],
    [/-01-manual-welcome(?:\.html)?$/i, "Manual Welcome"],
    [/-02-new-user-no-history(?:\.html)?$/i, "New User - No History"],
    [/-03-new-user-with-history(?:\.html)?$/i, "New User - With History"],
    [/-04-normal-newsletter(?:\.html)?$/i, "Normal Newsletter"],
    [/-05-established-quiet(?:\.html)?$/i, "Established Quiet"],
    [/-06-established-warmup(?:\.html)?$/i, "Established Warnings"],
  ];
  return scenarios.find(([pattern]) => pattern.test(name))?.[1] || name;
}

function orderedPreviews() {
  return [...state.previews].sort((left, right) => {
    const scenarioDifference = previewScenarioIndex(left) - previewScenarioIndex(right);
    if (scenarioDifference) return scenarioDifference;
    return String(right.modifiedUtc || "").localeCompare(String(left.modifiedUtc || ""));
  });
}

function preferredPreviewForInventory(previews, selectedID, preferredScenario, generatedPreviewIDs) {
  const generated = new Set(generatedPreviewIDs || []);
  const selected = previews.find((preview) => preview.id === selectedID);
  const scenarioAvailable = Number.isInteger(preferredScenario) && preferredScenario >= 0 && preferredScenario < Number.MAX_SAFE_INTEGER;
  const sameScenario = scenarioAvailable
    ? previews.find((preview) => previewScenarioIndex(preview) === preferredScenario)
    : null;
  return (selected && generated.has(selected.id) ? selected : null)
    || (sameScenario && generated.has(sameScenario.id) ? sameScenario : null)
    || selected
    || sameScenario
    || previews.find((preview) => generated.has(preview.id) && /-00-index(?:\.html)?$/i.test(preview.name))
    || previews.find((preview) => generated.has(preview.id))
    || previews[0]
    || null;
}

function renderPreviews(options = {}) {
  const list = byId("preview-list");
  list.replaceChildren();
  const previews = orderedPreviews();
  setChip("preview-chip", state.previews.length ? `${state.previews.length} available` : "None generated", state.previews.length ? "good" : "neutral");
  if (!state.previews.length) {
    state.selectedPreviewID = "";
    byId("preview-placeholder").hidden = false;
    const frame = byId("preview-frame");
    frame.hidden = true;
    frame.removeAttribute("data-preview-id");
    frame.removeAttribute("data-preview-reload-key");
    frame.src = "about:blank";
    const empty = document.createElement("div");
    empty.className = "config-empty";
    empty.textContent = "No generated HTML previews were found in the package output folder.";
    list.append(empty);
    return;
  }
  for (const preview of previews) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "preview-button";
    button.dataset.previewId = preview.id;
    const name = document.createElement("strong");
    name.textContent = previewDisplayName(preview);
    const meta = document.createElement("small");
    meta.textContent = `${formatDate(preview.modifiedUtc)} · ${formatBytes(preview.sizeBytes)}`;
    button.append(name, meta);
    button.addEventListener("click", () => openPreview(preview.id, button));
    list.append(button);
  }
  const latestRun = state.history.find((operation) => operation.type === "preview-all" && operation.state === "succeeded" && operation.generatedPreviewIds?.length);
  const preferred = preferredPreviewForInventory(
    previews,
    state.selectedPreviewID,
    options.preferredScenario,
    options.generatedPreviewIDs || latestRun?.generatedPreviewIds,
  );
  if (!preferred) return;
  const button = list.querySelector(`[data-preview-id="${CSS.escape(preferred.id)}"]`);
  if (button) openPreview(preferred.id, button, { reloadKey: options.reloadKey });
}

function renderOperations() {
  const operation = state.operation;
  const active = operationIsActive(operation);
  const scheduleActive = state.scheduleStarting || scheduleOperationIsActive(state.scheduleOperation);
  const manualSendType = byId("manual-send-mode").value === "send-welcome" ? "send-welcome" : "send-all";
  const manualWelcome = manualSendType === "send-welcome";
  const manualSendUserID = byId("manual-send-user-id").value.trim();
  const manualSendUserValid = !manualWelcome || validOperationUserID(manualSendUserID);
  renderManualSendChoice(manualSendType);
  const userID = byId("preview-user-id").value.trim();
  const userIDValid = validOperationUserID(userID);
  const confirmed = byId("preview-confirm").checked;
  const testUserID = byId("test-send-user-id").value.trim();
  const testUserIDValid = validOperationUserID(testUserID);
  const testConfirmed = byId("test-send-confirm").checked;
  const manualSendConfirmed = byId("manual-send-confirm").checked;
  const ready = state.editor?.state === "ready";
  const startButton = byId("preview-run-button");
  startButton.disabled = state.operationStarting || state.operationCancelling || active || scheduleActive || !ready || !userIDValid || !confirmed;
  setSwappingButtonText("preview-run-button", state.operationStarting && state.operationStartingType === "preview-all" ? "Starting preview generation..." : active || scheduleActive ? "Another operation is active" : "Generate all previews");

  let message = "Enter a numeric Tautulli user ID, then confirm this preview-only run.";
  if (!ready) message = "Complete and save configuration before generating previews.";
  else if (active) message = operation.type === "preview-all" ? (operation.state === "cancelling" ? "Stopping preview generation..." : "Generating previews. You can leave this page while they run.") : operation.type === "cache-warm" ? "Wait for the deleted-item cache refresh before generating previews." : "Wait for the current send before generating previews.";
  else if (scheduleActive) message = "Wait for the active schedule change before generating previews.";
  else if (state.operationStarting) message = "A Manager operation is starting...";
  else if (!userIDValid && userID) message = validPreviewUserID(userID) ? "Choose an included user from the saved Tautulli choices. Save exclusion changes before using an excluded user." : "Enter a numeric Tautulli user ID using no more than 20 digits.";
  else if (userIDValid && confirmed) message = "Ready to generate six local previews without sending email.";
  setText("preview-operation-message", message);

  const testButton = byId("test-send-run-button");
  testButton.disabled = state.operationStarting || active || scheduleActive || !ready || !testUserIDValid || !testConfirmed;
  setSwappingButtonText("test-send-run-button", state.operationStarting && state.operationStartingType === "send-test-all" ? "Starting test delivery..." : active || scheduleActive ? "Another operation is active" : "Send six test messages");
  let testMessage = "Enter a numeric Tautulli user ID, then confirm the six-message test delivery.";
  if (!ready) testMessage = "Complete and save configuration before sending a test delivery.";
  else if (active) testMessage = operation.type === "send-test-all" ? "Sending to TestEmail. A send cannot be cancelled after it starts." : "Wait for the current preview, send, or cache refresh before starting a test delivery.";
  else if (scheduleActive) testMessage = "Wait for the active schedule change before starting a test delivery.";
  else if (state.operationStarting) testMessage = "A Manager operation is starting...";
  else if (!testUserIDValid && testUserID) testMessage = validPreviewUserID(testUserID) ? "Choose an included user from the saved Tautulli choices. Save exclusion changes before using an excluded user." : "Enter a numeric Tautulli user ID using no more than 20 digits.";
  else if (testUserIDValid && testConfirmed) testMessage = "Ready to send six real messages only to the configured TestEmail.";
  setText("test-send-operation-message", testMessage);

  const manualSendButton = byId("manual-send-run-button");
  manualSendButton.disabled = state.operationStarting || active || scheduleActive || !ready || !manualSendConfirmed || !manualSendUserValid;
  const manualSendButtonLabel = manualWelcome ? "Send Manual Welcome" : "Send newsletter to all";
  setSwappingButtonText("manual-send-run-button", state.operationStarting && state.operationStartingType === manualSendType ? "Starting manual delivery..." : active || scheduleActive ? "Another operation is active" : manualSendButtonLabel);
  let manualSendMessage = manualWelcome ? "Choose a Tautulli user, then confirm the welcome send." : "Confirm the recipient scope before sending.";
  if (!ready) manualSendMessage = "Complete and save configuration before sending a production newsletter.";
  else if (active) manualSendMessage = ["send-welcome", "send-all"].includes(operation.type) ? "A newsletter send is running. A send cannot be cancelled after it starts." : "Wait for the current preview, test send, or cache refresh before sending a newsletter.";
  else if (scheduleActive) manualSendMessage = "Wait for the active schedule change before sending a production newsletter.";
  else if (state.operationStarting) manualSendMessage = "A Manager operation is starting...";
  else if (manualWelcome && manualSendUserID && !manualSendUserValid) manualSendMessage = validPreviewUserID(manualSendUserID) ? "Choose an included user from the saved Tautulli choices. Save exclusion changes before sending a Manual Welcome." : "Enter a numeric Tautulli user ID using no more than 20 digits.";
  else if (manualSendConfirmed && manualSendUserValid) manualSendMessage = "Ready to send.";
  setText("manual-send-operation-message", manualSendMessage);

  renderCurrentOperation(operation);
  renderManualSendStatus(operation);
  renderOperationHistory();
  renderDashboardOperation(operation);
  if (!byId("view-verification").hidden) renderVerification();
  if (state.status && state.editor) renderSchedule();
}

function renderManualSendChoice(type) {
  const manualWelcome = type === "send-welcome";
  byId("manual-send-user-field").hidden = !manualWelcome;
  setSwappingText("manual-send-runner-heading", manualWelcome ? "Send a welcome newsletter" : "Send this week's newsletter now");
  setText("manual-send-runner-copy", manualWelcome
    ? "When SMTP accepts the welcome newsletter, TautWeekly updates the selected user's welcome state."
    : "Uses the scheduled delivery rules and saved exclusions. TautWeekly checks the live Tautulli roster before sending.");
  setText("manual-send-confirm-heading", manualWelcome ? "Confirm welcome send" : "Confirm weekly newsletter send");
  setText("manual-send-confirm-copy", manualWelcome
    ? "Send real email to the selected user's primary address and any eligible household copy addresses. Once started, this send can't be cancelled."
    : "Send real email to each eligible user's primary address and any eligible household copy addresses. Once started, this send can't be cancelled.");
}

function renderManualSendStatus(operation) {
  const manualTypes = new Set(["send-welcome", "send-all"]);
  const manualSend = manualTypes.has(operation?.type)
    ? operation
    : state.history.find((candidate) => manualTypes.has(candidate.type));
  const card = byId("manual-send-status");
  card.hidden = !manualSend;
  if (!manualSend) return;
  const summary = operationSummary(manualSend);
  setText("manual-send-status-heading", summary.heading);
  setText("manual-send-status-copy", summary.copy);
  const duration = manualSend.durationMs ? ` · ${formatDuration(manualSend.durationMs)}` : "";
  setText("manual-send-status-time", manualSend.finishedAtUtc ? `Finished ${formatDate(manualSend.finishedAtUtc)}${duration}` : `Started ${formatDate(manualSend.startedAtUtc)}`);
  setChip("manual-send-status-chip", titleCase(manualSend.outcome || manualSend.state), operationTone(manualSend));
}

function renderCurrentOperation(operation) {
  const card = byId("current-operation");
  const cancel = byId("preview-cancel-button");
  const manualSend = ["send-welcome", "send-all"].includes(operation?.type);
  card.hidden = manualSend;
  if (manualSend) {
    cancel.hidden = true;
    return;
  }
  cancel.hidden = !operation?.cancellable || !operationIsActive(operation);
  cancel.disabled = state.operationCancelling;
  setSwappingButtonText("preview-cancel-button", state.operationCancelling ? "Cancelling..." : operation?.type === "cache-warm" ? "Cancel cache refresh" : "Cancel preview generation");
  if (!operation) {
    setText("current-operation-heading", "No Manager operation recorded");
    setText("current-operation-copy", "The latest preview, test send, or cache refresh will appear here.");
    setText("current-operation-time", "Not recorded");
    setChip("current-operation-chip", "Idle", "neutral");
    return;
  }
  const summary = operationSummary(operation);
  setText("current-operation-heading", summary.heading);
  setText("current-operation-copy", summary.copy);
  const duration = operation.durationMs ? ` · ${formatDuration(operation.durationMs)}` : "";
  setText("current-operation-time", operation.finishedAtUtc ? `Finished ${formatDate(operation.finishedAtUtc)}${duration}` : `Started ${formatDate(operation.startedAtUtc)}`);
  setChip("current-operation-chip", titleCase(operation.state), operationTone(operation));
}

function renderDashboardOperation(operation) {
  if (!operation) {
    setText("dashboard-operation-heading", "No Manager operation recorded");
    setText("dashboard-operation-copy", "Open Previews to generate previews, send a test, or send a newsletter.");
    setChip("dashboard-operation-chip", "Idle", "neutral");
    return;
  }
  const summary = operationSummary(operation);
  setText("dashboard-operation-heading", summary.heading);
  const time = operation.finishedAtUtc ? `Finished ${formatDate(operation.finishedAtUtc)}` : `Started ${formatDate(operation.startedAtUtc)}`;
  setText("dashboard-operation-copy", `${summary.copy} ${time}.`);
  setChip("dashboard-operation-chip", titleCase(operation.state), operationTone(operation));
}

function renderOperationHistory() {
  const container = byId("operation-history");
  container.replaceChildren();
  setText("operation-history-count", `${state.history.length} of ${state.historyMaximum} runs shown`);
  if (!state.history.length) {
    const empty = document.createElement("div");
    empty.className = "config-empty";
    empty.textContent = "No completed Manager operation has been recorded yet.";
    container.append(empty);
    return;
  }
  for (const operation of state.history) {
    const row = document.createElement("article");
    row.className = "operation-history-row";
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = operationSummary(operation).heading;
    const detail = document.createElement("p");
    const version = operation.packageVersion ? `Package ${operation.packageVersion}` : "Package version unavailable";
    const time = operation.finishedAtUtc ? `Finished ${formatDate(operation.finishedAtUtc)}` : `Started ${formatDate(operation.startedAtUtc)}`;
    detail.textContent = `${time} · ${version}${operation.durationMs ? ` · ${formatDuration(operation.durationMs)}` : ""}${operation.supportCode ? ` · Support ${operation.supportCode}` : ""}`;
    copy.append(heading, detail);
    if (operation.generatedPreviewIds?.length) {
      const links = document.createElement("div");
      links.className = "operation-history-links";
      for (const id of operation.generatedPreviewIds) {
        const preview = state.previews.find((candidate) => candidate.id === id);
        if (!preview) continue;
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = previewDisplayName(preview);
        button.addEventListener("click", () => {
          const previewButton = document.querySelector(`[data-preview-id="${CSS.escape(id)}"]`);
          if (previewButton) openPreview(id, previewButton);
        });
        links.append(button);
      }
      if (links.childElementCount) copy.append(links);
    }
    const meta = document.createElement("div");
    meta.className = "operation-history-meta";
    const chip = document.createElement("span");
    chip.className = `state-chip ${operationTone(operation)}`;
    chip.textContent = titleCase(operation.outcome || operation.state);
    const count = document.createElement("small");
    count.textContent = operation.type === "send-test-all" || operation.type === "send-welcome"
      ? `${operation.smtpAcceptedCount || 0}${operation.type === "send-welcome" ? " primary" : ""} accepted by SMTP${householdCopyReport(operation)}`
      : operation.type === "send-all"
        ? `${operation.smtpAcceptedCount || 0} primary accepted by SMTP · ${operation.skippedCount || 0} skipped · ${operation.failedCount || 0} failed${householdCopyReport(operation)}`
        : operation.type === "cache-warm"
          ? "All included users and selected libraries"
        : `${operation.generatedPreviewIds?.length || 0} preview${operation.generatedPreviewIds?.length === 1 ? "" : "s"}`;
    meta.append(chip, count);
    row.append(copy, meta);
    container.append(row);
  }
}

function operationSummary(operation) {
  const count = operation.generatedPreviewIds?.length || 0;
  if (operation.type === "cache-warm") {
    switch (operation.state) {
    case "queued": return { heading: "Deleted-item cache refresh queued", copy: "The cache refresh is waiting to start." };
    case "running": return { heading: "Refreshing deleted-item cache", copy: "TautWeekly is checking newsletter items for included users and selected libraries. No email is sent." };
    case "cancelling": return { heading: "Cancelling cache refresh", copy: "The Manager is stopping the refresh." };
    case "succeeded": return { heading: "Deleted-item cache refreshed", copy: "The cache refresh and local storage checks finished." };
    case "cancelled": return { heading: "Deleted-item cache refresh cancelled", copy: "The refresh stopped before the checks finished." };
    case "failed": return { heading: "Deleted-item cache refresh failed", copy: rendererFailureCopy(operation.errorCategory, operation.supportCode) };
    default: return { heading: "Deleted-item cache refresh recorded", copy: "See Verify for cache status." };
    }
  }
  if (operation.type === "send-welcome") {
    switch (operation.state) {
    case "queued": return { heading: "Manual Welcome queued", copy: "The welcome send is waiting to start." };
    case "running": return { heading: "Sending Manual Welcome", copy: "Sending to the selected user and any eligible household copies. This send can't be cancelled." };
    case "succeeded": return { heading: "Manual Welcome accepted by SMTP", copy: `SMTP accepted the primary message and TautWeekly updated the user's welcome state.${householdCopyReport(operation)} Check the mailbox for delivery.` };
    case "partial": return { heading: "Welcome accepted with household copy warnings", copy: `SMTP accepted the primary message and TautWeekly updated the user's welcome state.${householdCopyReport(operation)}` };
    case "failed": return { heading: "Manual Welcome delivery failed", copy: `${rendererFailureCopy(operation.errorCategory, operation.supportCode)}${smtpFailureEvidenceCopy(operation.smtpFailure)}` };
    default: return { heading: "Manual Welcome delivery recorded", copy: "See the operation history for SMTP totals." };
    }
  }
  if (operation.type === "send-all") {
    const accepted = operation.smtpAcceptedCount || 0;
    const skipped = operation.skippedCount || 0;
    const failed = operation.failedCount || 0;
    const reasonCopy = skipReasonCopy(operation.skipReasonCounts);
    switch (operation.state) {
    case "queued": return { heading: "Manual newsletter delivery queued", copy: "The weekly newsletter send is waiting to start." };
    case "running": return { heading: "Sending the weekly newsletter", copy: "Sending to eligible users and their eligible household copies. This send can't be cancelled." };
    case "succeeded": return { heading: "Manual newsletter accepted by SMTP", copy: `SMTP accepted ${accepted} primary message${accepted === 1 ? "" : "s"}. TautWeekly skipped ${skipped} user${skipped === 1 ? "" : "s"}.${reasonCopy}${householdCopyReport(operation)}` };
    case "partial": return { heading: "Manual newsletter accepted with delivery warnings", copy: `${accepted} primary accepted by SMTP, ${skipped} skipped, and ${failed} failed.${reasonCopy} ${operation.errorCategory ? rendererFailureCopy(operation.errorCategory, operation.supportCode) : operation.bccRejectedCount ? "Some household copies were rejected." : "One or more recipient attempts failed."}${smtpFailureEvidenceCopy(operation.smtpFailure)}${householdCopyReport(operation)}` };
    case "failed": return operation.errorCategory === "no-eligible-recipients"
      ? { heading: "No eligible production recipients", copy: `No message was accepted by SMTP.${reasonCopy} Checked exclusion boxes mean excluded.${operation.supportCode ? ` Support code: ${operation.supportCode}.` : ""}` }
      : { heading: "Manual newsletter delivery failed", copy: `SMTP accepted ${accepted} primary message${accepted === 1 ? "" : "s"} before the failure. ${rendererFailureCopy(operation.errorCategory, operation.supportCode)}${smtpFailureEvidenceCopy(operation.smtpFailure)}` };
    default: return { heading: "Manual newsletter delivery recorded", copy: `${accepted} primary accepted by SMTP, ${skipped} skipped, and ${failed} failed.${reasonCopy}${householdCopyReport(operation)}` };
    }
  }
  if (operation.type === "send-test-all") {
    switch (operation.state) {
    case "queued": return { heading: "Test send queued", copy: "The six-message test is waiting to start." };
    case "running": return { heading: "Sending six test messages", copy: "All messages go to TestEmail. This send can't be cancelled." };
    case "succeeded": return { heading: "Test messages accepted by SMTP", copy: `SMTP accepted ${operation.smtpAcceptedCount || 0} test messages. Check TestEmail to confirm inbox delivery.` };
    case "failed": return { heading: "Test send failed", copy: `SMTP accepted ${operation.smtpAcceptedCount || 0} test message${operation.smtpAcceptedCount === 1 ? "" : "s"} before the failure. ${rendererFailureCopy(operation.errorCategory, operation.supportCode)}${smtpFailureEvidenceCopy(operation.smtpFailure)}` };
    default: return { heading: "Test send recorded", copy: "See the operation history for SMTP totals." };
    }
  }
  switch (operation.state) {
  case "queued": return { heading: "Preview generation queued", copy: "Preview generation is waiting to start." };
  case "running": return { heading: "Generating newsletter previews", copy: "TautWeekly is saving local HTML previews. No email is sent." };
  case "cancelling": return { heading: "Cancelling preview generation", copy: "The Manager is stopping preview generation." };
  case "succeeded": return { heading: "Preview generation completed", copy: `${count} preview file${count === 1 ? " is" : "s are"} available in Previews.` };
  case "cancelled": return { heading: "Preview generation cancelled", copy: "Preview generation stopped. No email was sent." };
  case "failed": return { heading: "Preview generation failed", copy: rendererFailureCopy(operation.errorCategory, operation.supportCode) };
  default: return { heading: "Preview run recorded", copy: "See the preview list for saved files." };
  }
}

function skipReasonCopy(counts) {
  if (!counts) return "";
  const reasons = [
    [counts.inactiveOrDeleted, "inactive or deleted"],
    [counts.missingEmail, "missing email"],
    [counts.excludedUserId, "excluded by user selection"],
    [counts.excludedEmail, "excluded by legacy email rule"],
  ].filter(([count]) => Number.isInteger(count) && count > 0);
  if (!reasons.length) return "";
  return ` Skip reasons: ${reasons.map(([count, label]) => `${count} ${label}`).join("; ")}.`;
}

function operationTone(operation) {
  if (operation?.state === "succeeded") return "good";
  if (operation?.state === "failed") return "bad";
  if (operation?.state === "partial") return "neutral";
  if (operationIsActive(operation)) return "pending";
  return "neutral";
}

function operationIsActive(operation) {
  return ["queued", "running", "cancelling"].includes(operation?.state);
}

function validPreviewUserID(value) {
  if (!/^[0-9]{1,20}$/.test(value)) return false;
  const parsed = BigInt(value);
  return parsed > 0n && parsed <= 18446744073709551615n;
}

async function startPreviewOperation() {
  const userID = byId("preview-user-id").value.trim();
  if (state.editor?.state !== "ready" || !byId("preview-confirm").checked || !validOperationUserID(userID)) return;
  state.operationStarting = true;
  state.operationStartingType = "preview-all";
  renderOperations();
  setGlobalStatus("Starting the fixed local preview operation...");
  try {
    state.operation = await request("/api/v1/operations", {
      method: "POST",
      body: JSON.stringify({ type: "preview-all", expectedRevision: state.editor.revision, userId: userID, confirmNoSend: true }),
    });
    byId("preview-user-id").value = "";
    byId("preview-confirm").checked = false;
    setGlobalStatus("Preview generation started. No email will be sent.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.operationStarting = false;
    state.operationStartingType = "";
    try {
      await refreshConfigurationStatus();
    } catch (_) {
      // Operation polling will refresh the retained setup result at completion.
    }
    renderOperations();
    manageOperationPolling();
  }
}

async function startTestSendOperation() {
  const userID = byId("test-send-user-id").value.trim();
  if (state.editor?.state !== "ready" || !byId("test-send-confirm").checked || !validOperationUserID(userID)) return;
  state.operationStarting = true;
  state.operationStartingType = "send-test-all";
  renderOperations();
  setGlobalStatus("Starting the six-message test send...");
  try {
    state.operation = await request("/api/v1/operations", {
      method: "POST",
      body: JSON.stringify({ type: "send-test-all", expectedRevision: state.editor.revision, userId: userID, confirmTestSend: true }),
    });
    byId("test-send-user-id").value = "";
    byId("test-send-confirm").checked = false;
    setGlobalStatus("Test delivery started. Messages go only to the configured TestEmail.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.operationStarting = false;
    state.operationStartingType = "";
    renderOperations();
    manageOperationPolling();
  }
}

async function startManualSendOperation() {
  const type = byId("manual-send-mode").value === "send-welcome" ? "send-welcome" : "send-all";
  const userID = byId("manual-send-user-id").value.trim();
  if (state.editor?.state !== "ready" || !byId("manual-send-confirm").checked || (type === "send-welcome" && !validOperationUserID(userID))) return;
  state.operationStarting = true;
  state.operationStartingType = type;
  renderOperations();
  setGlobalStatus(type === "send-welcome" ? "Starting the confirmed Manual Welcome delivery..." : "Starting the confirmed all-recipient newsletter delivery...");
  try {
    state.operation = await request("/api/v1/operations", {
      method: "POST",
      body: JSON.stringify({ type, expectedRevision: state.editor.revision, userId: type === "send-welcome" ? userID : "", confirmProductionSend: true }),
    });
    if (type === "send-welcome") byId("manual-send-user-id").value = "";
    byId("manual-send-confirm").checked = false;
    setGlobalStatus(type === "send-welcome" ? "Manual Welcome delivery started. The selected user is not retained in Manager history." : "All-recipient production delivery started. Aggregate SMTP evidence will be retained locally.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.operationStarting = false;
    state.operationStartingType = "";
    renderOperations();
    renderStatus();
    manageOperationPolling();
  }
}

async function cancelPreviewOperation() {
  if (!operationIsActive(state.operation) || !state.operation?.cancellable) return;
  state.operationCancelling = true;
  renderOperations();
  setGlobalStatus("Cancelling local preview generation...");
  try {
    state.operation = await request(`/api/v1/operations/${encodeURIComponent(state.operation.id)}/cancel`, { method: "POST" });
    setGlobalStatus("Cancellation requested.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.operationCancelling = false;
    renderOperations();
    manageOperationPolling();
  }
}

let operationPollTimer;
let operationPollSequence = 0;
let operationCompletionProcessedID = "";

function manageDeliveryStatusPolling(delay = productionDeliveryIsRunning() ? 1500 : 5000) {
  clearTimeout(deliveryStatusPollTimer);
  if (deliveryStatusPollInFlight || document.hidden || byId("app-shell").hidden || !state.status) return;
  deliveryStatusPollTimer = setTimeout(pollDeliveryStatus, delay);
}

async function pollDeliveryStatus() {
  clearTimeout(deliveryStatusPollTimer);
  if (deliveryStatusPollInFlight || document.hidden || byId("app-shell").hidden || !state.status) return;
  const pollAuthenticationEpoch = authenticationEpoch;
  let retryDelay;
  deliveryStatusPollInFlight = true;
  try {
    const status = await request("/api/v1/status");
    if (pollAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    state.status = status;
    renderStatus();
    if (state.editor) renderSchedule();
  } catch (error) {
    if (pollAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    if (error.status === 401) showAuthentication();
    else retryDelay = 5000;
  } finally {
    deliveryStatusPollInFlight = false;
    manageDeliveryStatusPolling(retryDelay);
  }
}

function manageOperationPolling() {
  clearTimeout(operationPollTimer);
  operationPollSequence += 1;
  if (document.hidden || byId("app-shell").hidden || !operationIsActive(state.operation)) return;
  const expectedOperationID = state.operation?.id || "";
  const expectedSequence = operationPollSequence;
  operationPollTimer = setTimeout(() => pollOperation(expectedOperationID, expectedSequence), 1000);
}

function operationPollIsCurrent(expectedOperationID, expectedSequence) {
  return !document.hidden && !byId("app-shell").hidden && expectedSequence === operationPollSequence && state.operation?.id === expectedOperationID;
}

function successfulPreviewGeneration(operation) {
  return operation?.type === "preview-all" && operation.state === "succeeded";
}

async function pollOperation(expectedOperationID = state.operation?.id || "", expectedSequence = operationPollSequence) {
  if (document.hidden || byId("app-shell").hidden) return;
  if (!operationPollIsCurrent(expectedOperationID, expectedSequence)) return;
  if (!operationIsActive(state.operation) && operationCompletionProcessedID === expectedOperationID) return;
  const priorState = state.operation?.state;
  try {
    const response = await request("/api/v1/operations/current");
    if (!operationPollIsCurrent(expectedOperationID, expectedSequence)) return;
    if (!response.current || response.current.id !== expectedOperationID) return;
    state.operation = response.current;
    if (operationIsActive(state.operation)) {
      renderOperations();
      renderStatus();
      manageOperationPolling();
      return;
    }
    if (operationCompletionProcessedID === state.operation.id) return;
    const completedOperation = state.operation;
    const refreshPreviews = successfulPreviewGeneration(completedOperation);
    const selectedPreview = refreshPreviews
      ? state.previews.find((preview) => preview.id === state.selectedPreviewID)
      : null;
    const requests = [
      request("/api/v1/history"),
      request("/api/v1/status"),
      request("/api/v1/config/status"),
    ];
    if (refreshPreviews) requests.push(request("/api/v1/previews"));
    const [history, status, configurationStatus, previews] = await Promise.all(requests);
    if (!operationPollIsCurrent(expectedOperationID, expectedSequence)) return;
    if (refreshPreviews) state.previews = previews?.previews || [];
    state.historyMaximum = Number(history.maximumEntries) || 20;
    state.history = (history.operations || []).slice(0, state.historyMaximum);
    state.status = status;
    state.setupWorkflow = configurationStatus?.available ? configurationStatus : null;
    state.cache = configurationStatus?.cache || null;
    operationCompletionProcessedID = completedOperation.id;
    if (refreshPreviews) {
      renderPreviews({
        preferredScenario: previewScenarioIndex(selectedPreview),
        generatedPreviewIDs: completedOperation.generatedPreviewIds,
        reloadKey: completedOperation.id,
      });
    }
    renderOperations();
    renderStatus();
    renderSetupWorkflow();
    if (["queued", "running", "cancelling"].includes(priorState)) {
      const summary = state.operation ? operationSummary(state.operation) : { heading: "Manager operation ended" };
      setGlobalStatus(summary.heading + ".", true);
    }
    if (completedOperation.type === "cache-warm") await recoverPendingPreviewsFromChoices();
  } catch (error) {
    if (!operationPollIsCurrent(expectedOperationID, expectedSequence)) return;
    if (error.status === 401) showAuthentication();
    else {
      setGlobalStatus(error.message, true);
      operationPollTimer = setTimeout(() => pollOperation(expectedOperationID, expectedSequence), 2500);
    }
  }
}

function chooseScheduleAction(action) {
  if (!validScheduleAction(action)) return;
  const button = document.querySelector(`[data-schedule-action="${action}"]`);
  if (!button || button.disabled) return;
  state.schedulePendingAction = action;
  byId("schedule-confirm").checked = false;
  renderSchedule();
  byId("schedule-confirmation").scrollIntoView({ behavior: "smooth", block: "center" });
  byId("schedule-confirm").focus({ preventScroll: true });
}

function cancelScheduleConfirmation() {
  state.schedulePendingAction = "";
  byId("schedule-confirm").checked = false;
  renderSchedule();
}

async function startScheduleOperation() {
  const action = state.schedulePendingAction;
  if (!validScheduleAction(action) || !byId("schedule-confirm").checked || state.editor?.state !== "ready") return;
  state.scheduleStarting = true;
  renderSchedule();
  setGlobalStatus(isServiceRuntime() ? "Applying the embedded schedule change..." : "Starting the fixed Windows schedule helper...");
  try {
    state.scheduleOperation = await request(`/api/v1/schedule/${encodeURIComponent(action)}`, {
      method: "POST",
      body: JSON.stringify({ expectedRevision: state.editor.revision, confirm: true }),
    });
    state.schedulePendingAction = "";
    byId("schedule-confirm").checked = false;
    setGlobalStatus(isServiceRuntime() ? "Schedule operation started." : "Schedule operation started. Review the Windows UAC prompt.", true);
  } catch (error) {
    setGlobalStatus(error.message, true);
  } finally {
    state.scheduleStarting = false;
    renderSchedule();
    renderOperations();
    manageSchedulePolling();
  }
}

function validScheduleAction(action) {
  return (state.capabilities?.scheduleActions || ["install", "enable", "disable", "remove"]).includes(action);
}

let schedulePollTimer;
let schedulePollSequence = 0;
function manageSchedulePolling() {
  clearTimeout(schedulePollTimer);
  schedulePollSequence += 1;
  if (document.hidden || byId("app-shell").hidden || !scheduleOperationIsActive(state.scheduleOperation)) return;
  const expectedSequence = schedulePollSequence;
  schedulePollTimer = setTimeout(() => pollScheduleOperation(expectedSequence), 1000);
}

async function pollScheduleOperation(expectedSequence = schedulePollSequence) {
  if (expectedSequence !== schedulePollSequence || document.hidden || byId("app-shell").hidden) return;
  const pollAuthenticationEpoch = authenticationEpoch;
  const priorState = state.scheduleOperation?.state;
  try {
    const response = await request("/api/v1/schedule/operation");
    if (expectedSequence !== schedulePollSequence || pollAuthenticationEpoch !== authenticationEpoch || document.hidden || byId("app-shell").hidden) return;
    state.scheduleOperation = response.current || null;
    if (scheduleOperationIsActive(state.scheduleOperation)) {
      renderSchedule();
      renderOperations();
      manageSchedulePolling();
      return;
    }
    const status = await request("/api/v1/status");
    if (expectedSequence !== schedulePollSequence || pollAuthenticationEpoch !== authenticationEpoch || document.hidden || byId("app-shell").hidden) return;
    state.status = status;
    renderStatus();
    renderSchedule();
    renderOperations();
    if (["queued", "running"].includes(priorState)) {
      const action = titleCase(state.scheduleOperation?.action || "Schedule");
      const outcome = state.scheduleOperation?.state === "succeeded" ? "completed" : "was not completed";
      setGlobalStatus(`${action} schedule ${outcome}.`, true);
    }
  } catch (error) {
    if (expectedSequence !== schedulePollSequence || pollAuthenticationEpoch !== authenticationEpoch || document.hidden || byId("app-shell").hidden) return;
    if (error.status === 401) showAuthentication();
    else {
      setGlobalStatus(error.message, true);
      schedulePollTimer = setTimeout(() => pollScheduleOperation(expectedSequence), 2500);
    }
  }
}

function renderStartupSettings() {
  const startup = state.startup || { supported: false, state: "unsupported" };
  const panel = byId("startup-settings-panel");
  panel.hidden = !startup.supported || !state.capabilities?.supportsStartup;
  if (panel.hidden) return;
  const managerToggle = byId("startup-manager");
  const dashboardToggle = byId("startup-dashboard");
  const unavailable = ["conflict", "unavailable"].includes(startup.state);
  const selection = state.startupDraft || startup;
  managerToggle.checked = Boolean(selection.startManager);
  dashboardToggle.checked = Boolean(selection.openDashboard && selection.startManager);
  if (!managerToggle.checked) dashboardToggle.checked = false;
  managerToggle.disabled = state.startupSaving || unavailable;
  dashboardToggle.disabled = state.startupSaving || unavailable || !managerToggle.checked;
  panel.setAttribute("aria-busy", String(state.startupSaving));
  managerToggle.closest(".config-toggle").querySelector("em").textContent = managerToggle.checked ? "On" : "Off";
  dashboardToggle.closest(".config-toggle").querySelector("em").textContent = dashboardToggle.checked ? "On" : "Off";
  const dependent = dashboardToggle.closest(".startup-setting");
  dependent.classList.toggle("disabled", unavailable || !managerToggle.checked);
  const savedManagerEnabled = Boolean(startup.startManager);
  const label = startup.state === "conflict" ? "Needs review" : startup.state === "unavailable" ? "Unavailable" : savedManagerEnabled ? "Enabled" : "Disabled";
  const tone = startup.state === "conflict" || startup.state === "unavailable" ? "bad" : savedManagerEnabled ? "good" : "neutral";
  setChip("startup-settings-chip", label, tone);
  const message = byId("startup-settings-message");
  if (state.startupError) message.textContent = state.startupError;
  else if (startup.state === "conflict") message.textContent = "A same-named Windows sign-in entry does not match this installation. It was left unchanged.";
  else if (startup.state === "unavailable") message.textContent = "Windows sign-in startup status could not be read safely.";
  else if (startup.startManager && startup.openDashboard) message.textContent = "The Manager starts silently at sign-in, then opens the Dashboard once it is ready.";
  else if (startup.startManager) message.textContent = "The Manager starts silently in the notification area at sign-in.";
  else message.textContent = "The Manager starts only when you open it.";
}

async function startupSettingsChanged() {
  if (state.startupSaving) return;
  const managerToggle = byId("startup-manager");
  const dashboardToggle = byId("startup-dashboard");
  if (!managerToggle.checked) dashboardToggle.checked = false;
  const requested = {
    startManager: managerToggle.checked,
    openDashboard: dashboardToggle.checked,
  };
  state.startupDraft = requested;
  state.startupSaving = true;
  state.startupError = "";
  renderStartupSettings();
  try {
    state.startup = await request("/api/v1/startup", {
      method: "PUT",
      body: JSON.stringify(requested),
    });
    setGlobalStatus("Windows sign-in settings saved.", true);
  } catch (error) {
    state.startupError = error.message;
  } finally {
    state.startupDraft = null;
    state.startupSaving = false;
    renderStartupSettings();
  }
}

function renderAccessSettings() {
  const access = state.authAccess || {};
  const locked = Boolean(access.authenticationRequired);
  const localLock = Boolean(access.passwordLockEnabled);
  const runtimeRequired = Boolean(access.runtimeRequired);
  const passwordLockActive = localLock || runtimeRequired;
  setChip("access-settings-chip", locked ? "Locked" : "Unlocked", locked ? "good" : "neutral", locked ? "lock" : "lock-open");
  const accessChip = byId("access-settings-chip");
  accessChip.classList.add("access-lock-chip", locked ? "locked" : "unlocked");
  const accessButton = byId("access-status-button");
  const accessLabel = `${accessSurfaceLabel()} ${locked ? "locked" : "unlocked"}`;
  accessButton.className = `access-status-button ${locked ? "locked" : "unlocked"}`;
  accessButton.dataset.tooltip = accessLabel;
  accessButton.setAttribute("aria-label", `${accessLabel}. Open password settings.`);
  accessButton.replaceChildren(createMaterialIcon(locked ? "lock" : "lock-open"));
  setText("access-settings-copy", runtimeRequired
    ? "This Manager mode requires authentication. A password can be changed here, but the lock cannot be disabled while this mode is active."
    : localLock
      ? "The optional password lock is enabled. Existing sessions remain active; a password is required after sign-out or restart."
      : `${accessSurfaceLabel()} is currently trusted without a password. Enable the optional lock when other people can reach this Manager.`);
  setText("access-password-label", passwordLockActive ? "New password" : "Create password");
  setSwappingButtonText("access-password-submit", passwordLockActive ? "Change password" : "Enable password lock");
  byId("access-disable-button").hidden = !localLock || !access.canDisable;
  byId("logout-button").hidden = !locked;
  const policy = byId("config-secret-policy");
  if (policy) policy.textContent = locked
    ? "Secrets stay hidden by default. Saving preserves stored credentials unless you replace or clear them. Revealing one value requires your Manager password, returns only that field, and clears it from the page after 30 seconds. Existing configurations receive a private timestamped backup."
    : "Secrets stay hidden by default. Saving preserves stored credentials unless you replace or clear them. An explicit reveal returns only the selected field and clears it from the page after 30 seconds. Existing configurations receive a private timestamped backup.";
  renderTailscaleSettings();
}

const tailscaleAuthorizationCommands = new Set([
  "sudo tautweekly remote-access-authorize",
  "./tautweekly.sh remote-access-login",
  "/opt/tautweekly/bin/tautweekly-funnel login",
  "docker compose exec tautweekly /opt/tautweekly/bin/tautweekly-funnel login",
]);

function tailscaleStatePresentation(remote) {
  const windows = state.runtimeMode === "windows";
  const nativeLinux = state.runtimeMode === "linux";
  switch (remote.state) {
    case "active": return { label: "Active", tone: "good", status: "The last verification confirmed the public HTTPS address." };
    case "inactive": return { label: "Off", tone: "neutral", status: "Public Funnel is off." };
    case "starting": return { label: "Publication pending", tone: "publication-pending", status: "Funnel is configured. Wait for public DNS and HTTPS, then verify again. Publication can take up to 10 minutes." };
    case "stopping": return { label: "Stopping", tone: "pending", status: "The host adapter is stopping and verifying the exact TautWeekly Funnel." };
    case "manager-password-required": return { label: "Password required", tone: "pending", status: "Create and enable a unique Manager password before Funnel can be turned on." };
    case "approval-required": return remote.enabled
      ? { label: "Approval required", tone: "pending", status: "Funnel is saved. Approve Verify with Windows to confirm the current public route." }
      : { label: "Approval required", tone: "pending", status: "Windows approval is required only for an explicit Enable, Disable, or Verify action." };
    case "ready": return { label: "Ready", tone: "neutral", status: "The fixed host adapter is ready. Enable creates only the loopback Funnel after the Manager password lock is active." };
    case "authorization-required": return { label: "Host setup required", tone: "pending", status: "Complete the Funnel setup for this installation, then verify again." };
    case "tailscale-required": return { label: "Tailscale required", tone: "neutral", status: windows ? "Install the official Tailscale Windows client, start it, and sign in before enabling Funnel." : nativeLinux ? "Install the official Tailscale Linux package, start it, and sign in before enabling Funnel." : "Enable the package's isolated Tailscale Funnel adapter, then sign in interactively with its fixed console command." };
    case "sign-in-required": return { label: "Sign in required", tone: "pending", status: windows ? "Sign in through the official Tailscale Windows app, then verify again." : nativeLinux ? "Sign in through the official Tailscale Linux CLI outside Manager, then verify again." : "Use the fixed package console command to sign in to the isolated official Tailscale runtime, then verify again." };
    case "not-running": return { label: "Tailscale stopped", tone: "bad", status: windows || nativeLinux ? `Start the official Tailscale ${windows ? "Windows" : "Linux"} service, then verify again.` : "Start the package's optional Funnel adapter, then verify again." };
    case "funnel-unsupported": return { label: "Update required", tone: "bad", status: windows || nativeLinux ? `Update the official Tailscale ${windows ? "Windows client" : "Linux package"} to a Funnel-capable release.` : "Update the TautWeekly package to a release with the current pinned official Tailscale runtime." };
    case "migration-required": return { label: "Migration required", tone: "pending", status: "The older private Serve route is blocked. With the password lock active, Enable converts only that exact route to Funnel; Disable removes it." };
    case "needs-attention": return { label: "Needs attention", tone: "bad", status: "The saved Funnel could not be matched to the exact TautWeekly route. The password boundary remains active." };
    case "unavailable": return { label: "Unavailable", tone: "bad", status: "Funnel state could not be verified safely." };
    default: return { label: "Unavailable", tone: "neutral", status: "Public Funnel is unavailable in this package." };
  }
}

function validTailscaleURL(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" && parsed.username === "" && parsed.password === "" && parsed.port === "" &&
      parsed.pathname === "/" && parsed.search === "" && parsed.hash === "" && parsed.hostname.endsWith(".ts.net");
  } catch (_) {
    return false;
  }
}

function validTailscaleSetupURL(value) {
  try {
    const parsed = new URL(value);
    return parsed.protocol === "https:" && parsed.username === "" && parsed.password === "" && parsed.port === "" && parsed.hostname === "login.tailscale.com" && parsed.hash === "";
  } catch (_) {
    return false;
  }
}

function verifiedTailscaleAddress(remote) {
  return remote?.supported && remote.enabled && remote.active && remote.state === "active" && validTailscaleURL(remote.url)
    ? remote.url : "";
}

function renderTailscaleSettings() {
  const panel = byId("tailscale-settings-panel");
  if (!panel) return;
  const remote = state.tailscale || {};
  renderTailscaleStatusButton(state.tailscale);
  panel.hidden = !remote.supported;
  if (!remote.supported) return;
  const windows = state.runtimeMode === "windows";
  const publicFunnel = true;
  panel.classList.toggle("enabled-glow", Boolean(remote.enabled && remote.active));
  panel.classList.toggle("publication-pending-glow", Boolean(publicFunnel && remote.enabled && remote.state === "starting"));
  const displayRemote = publicFunnel && state.tailscaleSaving
    ? { ...remote, state: state.tailscaleRequestedOperation === "enable" ? "starting" : "stopping" }
    : remote;
  renderTailscaleStatusButton(displayRemote);
  const presentation = tailscaleStatePresentation(displayRemote);
  const passwordLocked = Boolean(state.authAccess?.passwordLockEnabled);
  setText("tailscale-settings-eyebrow", "Optional public remote access");
  setText("tailscale-settings-heading", "Tailscale Funnel");
  setText("tailscale-settings-copy", "Open Manager remotely through a public HTTPS address.");
  setText("tailscale-toggle-label", "Enable public Funnel");
  setText("tailscale-status-label", "Funnel status");
  setText("tailscale-address-label", "Public HTTPS address");
  panel.setAttribute("aria-busy", String(state.tailscaleSaving));
  const transitionLabel = state.tailscaleVerifying ? "Checking" : state.tailscaleRequestedOperation === "enable" ? "Starting" : "Stopping";
  setChip("tailscale-settings-chip", state.tailscaleSaving ? transitionLabel : presentation.label, state.tailscaleSaving ? "pending" : presentation.tone);
  setText("tailscale-funnel-status", presentation.status);

  const toggle = byId("tailscale-enabled");
  toggle.checked = Boolean(remote.enabled);
  const blockedState = ["conflict", "unavailable", "sign-in-required", "authorization-required", "tailscale-required", "not-running", "funnel-unsupported", "needs-attention"].includes(remote.state);
  toggle.disabled = state.tailscaleSaving || (!remote.enabled && (!remote.installed || blockedState || (publicFunnel && !passwordLocked)));
  toggle.closest(".tailscale-setting").classList.toggle("disabled", toggle.disabled);
  toggle.closest(".config-toggle").querySelector("em").textContent = remote.enabled ? "On" : "Off";
  setText("tailscale-toggle-help", windows
    ? "Tailscale must already be installed, running, and signed in. Windows asks for administrator approval only for an explicit Enable, Disable, or Verify operation."
    : state.runtimeMode === "linux"
      ? "Install Tailscale, sign in on the Linux host, and authorize the adapter once."
      : "Enable the container's Funnel adapter in its deployment settings, restart the container, then sign in to Tailscale.");

  const authorizationCommand = tailscaleAuthorizationCommands.has(remote.hostAuthorizationCommand)
    ? remote.hostAuthorizationCommand : "";
  byId("tailscale-host-authorization").hidden = !remote.hostAuthorizationRequired || authorizationCommand === "";
  setText("tailscale-host-authorization-command", authorizationCommand);
  byId("tailscale-copy-authorization").disabled = state.tailscaleSaving || authorizationCommand === "";

  const verifiedAddress = verifiedTailscaleAddress(remote);
  const hasURL = Boolean(verifiedAddress);
  const link = byId("tailscale-url");
  link.hidden = !hasURL;
  byId("tailscale-url-empty").hidden = hasURL;
  byId("tailscale-copy-button").hidden = !hasURL;
  if (hasURL) {
    link.href = verifiedAddress;
    link.textContent = verifiedAddress;
  } else {
    link.removeAttribute("href");
    link.textContent = "";
  }

  setText("tailscale-password-status", passwordLocked ? "Required lock enabled" : "Required before enable");
  const passwordSetup = byId("tailscale-password-setup-button");
  passwordSetup.hidden = !publicFunnel || passwordLocked;
  passwordSetup.disabled = state.tailscaleSaving;
  const boundary = byId("tailscale-security-boundary");
  boundary.innerHTML = "<strong>Funnel makes the Manager login page publicly reachable over HTTPS.</strong> Remote viewers do not need Tailscale or a VPN, so the Manager password lock is mandatory. Use a unique password; Internet login attempts remain a brute-force risk.";

  byId("tailscale-refresh-button").hidden = false;
  byId("tailscale-refresh-button").textContent = windows ? "Verify with Windows" : "Verify publication";
  byId("tailscale-refresh-button").disabled = state.tailscaleSaving || !remote.installed || remote.hostAuthorizationRequired;
  byId("tailscale-copy-button").disabled = state.tailscaleSaving;
  const setupLink = byId("tailscale-setup-link");
  const hasSetupURL = validTailscaleSetupURL(state.tailscaleSetupURL);
  setupLink.hidden = !hasSetupURL;
  setupLink.textContent = "Approve Funnel in Tailscale";
  byId("tailscale-provider-warning").hidden = !hasSetupURL;
  if (hasSetupURL) setupLink.href = state.tailscaleSetupURL;
  else setupLink.removeAttribute("href");
  const message = byId("tailscale-settings-message");
  if (state.tailscaleError) message.textContent = state.tailscaleError;
  else if (state.tailscaleSaving) message.textContent = state.tailscaleVerifying
    ? `${windows ? "Waiting for Windows approval, then v" : "V"}erifying the exact Tailscale Funnel route...`
    : state.tailscaleRequestedOperation === "disable"
      ? "Stopping and verifying the exact TautWeekly Funnel..."
      : "Starting and verifying the exact TautWeekly Funnel...";
  else message.textContent = remote.enabled && remote.active
    ? "The public address opens the password-protected Manager; remote viewers do not need Tailscale."
    : presentation.status;
  setText("tailscale-recovery-copy", "Use the recovery instructions under Browser access or Administrator password. Recovery requires verified Funnel shutdown before resetting the password.");
}

async function updateTailscaleAccess() {
  const requested = byId("tailscale-enabled").checked;
  state.tailscaleSaving = true;
  state.tailscaleRequestedOperation = requested ? "enable" : "disable";
  state.tailscaleError = "";
  state.tailscaleSetupURL = "";
  renderTailscaleSettings();
  try {
    state.tailscale = await request("/api/v1/remote-access/tailscale", {
      method: "PUT",
      body: JSON.stringify({ operation: state.tailscaleRequestedOperation }),
    });
    setGlobalStatus(requested ? (state.tailscale.active ? "Public Tailscale Funnel verified active." : "Funnel configured locally; public publication is pending.") : "Public Tailscale Funnel disabled.", true);
  } catch (error) {
    state.tailscaleError = error.message;
    if (error.code === "tailscale-provider-approval-required" && validTailscaleSetupURL(error.fields?.setupUrl || "")) state.tailscaleSetupURL = error.fields.setupUrl;
    setGlobalStatus(error.message, true);
    try { state.tailscale = await request("/api/v1/remote-access/tailscale"); }
    catch (_) { /* Preserve the actionable update error. */ }
  } finally {
    state.tailscaleSaving = false;
    state.tailscaleRequestedOperation = "";
    renderTailscaleSettings();
    renderIntegrationStatus();
  }
}

async function copyTailscaleAuthorizationCommand() {
  const command = state.tailscale?.hostAuthorizationCommand;
  if (!tailscaleAuthorizationCommands.has(command)) return;
  try {
    await navigator.clipboard.writeText(command);
    setGlobalStatus("Package authorization command copied.", true);
  } catch (_) {
    state.tailscaleError = "The browser could not copy the command. Select it manually instead.";
    renderTailscaleSettings();
  }
}

async function refreshTailscaleAccess() {
  state.tailscaleSaving = true;
  state.tailscaleVerifying = true;
  state.tailscaleRequestedOperation = "verify";
  state.tailscaleError = "";
  state.tailscaleSetupURL = "";
  renderTailscaleSettings();
  try {
    state.tailscale = await request("/api/v1/remote-access/tailscale/verify", { method: "POST" });
    setGlobalStatus(state.tailscale.active
      ? "Public Tailscale Funnel verified active."
      : "Funnel remains configured locally; public publication is pending.", true);
  } catch (error) {
    state.tailscaleError = error.message;
    if (error.code === "tailscale-provider-approval-required" && validTailscaleSetupURL(error.fields?.setupUrl || "")) state.tailscaleSetupURL = error.fields.setupUrl;
    setGlobalStatus(error.message, true);
  } finally {
    state.tailscaleSaving = false;
    state.tailscaleVerifying = false;
    state.tailscaleRequestedOperation = "";
    renderTailscaleSettings();
    renderIntegrationStatus();
  }
}

async function loadTailscaleAccess() {
  try {
    state.tailscale = await request("/api/v1/remote-access/tailscale");
  } catch (error) {
    state.tailscaleError = error.message;
  }
  renderTailscaleSettings();
  renderIntegrationStatus();
  const route = window.TautWeeklyUpdateUI.routeFromHash(window.location.hash);
  if (route.view === "about" && route.section === "tailscale") {
    selectView(route.view, { section: route.section, updateHistory: false });
  }
}

async function copyTailscaleURL() {
  const address = verifiedTailscaleAddress(state.tailscale);
  if (!address) return;
  try {
    await navigator.clipboard.writeText(address);
    setGlobalStatus("Public Funnel address copied.", true);
  } catch (_) {
    state.tailscaleError = "The browser could not copy the public address. Select it manually instead.";
    renderTailscaleSettings();
  }
}

function accessSurfaceLabel() {
  return state.capabilities?.accessLabel || "Manager access";
}

function openAccessSettings() {
  selectView("about");
  requestAnimationFrame(() => {
    byId("access-settings-panel").scrollIntoView({ block: "center", behavior: "smooth" });
    byId("access-password").focus({ preventScroll: true });
  });
}

function openTailscaleSettings() {
  if (state.tailscale?.supported !== true) return;
  selectView("about", { section: "tailscale" });
}

async function submitAccessPassword(event) {
  event.preventDefault();
  const password = byId("access-password").value;
  const confirmation = byId("access-password-confirm").value;
  const message = byId("access-settings-message");
  if (password !== confirmation) {
    message.textContent = "The password confirmation does not match.";
    byId("access-password-confirm").focus();
    return;
  }
  const button = byId("access-password-submit");
  button.disabled = true;
  setSwappingButtonText("access-password-submit", state.authAccess?.passwordLockEnabled ? "Changing password..." : "Enabling lock...");
  message.textContent = state.authAccess?.passwordLockEnabled ? "Changing the local Manager password..." : "Enabling the local Manager password lock...";
  try {
    state.authAccess = await request("/api/v1/auth/access/password", { method: "POST", body: JSON.stringify({ password }) });
    byId("access-password").value = "";
    byId("access-password-confirm").value = "";
    concealMaskedInputs(byId("access-password-form"));
    renderAccessSettings();
    message.textContent = "Manager access settings saved. This browser remains signed in.";
    setGlobalStatus("Manager password lock updated.", true);
    await loadTailscaleAccess();
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
    renderAccessSettings();
  }
}

async function disableAccessPassword() {
  const button = byId("access-disable-button");
  const message = byId("access-settings-message");
  button.disabled = true;
  setSwappingButtonText("access-disable-button", "Disabling lock...");
  const publicFunnelConfigured = state.tailscale?.networkKind === "public-funnel" && Boolean(state.tailscale?.cleanupRequired || state.tailscale?.enabled);
  message.textContent = publicFunnelConfigured
    ? "Turning off and verifying the public Funnel before disabling the password lock. Host approval may be required..."
    : "Disabling the optional Manager password lock...";
  try {
    state.authAccess = await request("/api/v1/auth/access/disable", { method: "POST", body: "{}" });
    renderAccessSettings();
    message.textContent = "Password lock disabled. The Manager remains limited to this computer.";
    setGlobalStatus("Manager returned to trusted-local access.", true);
    await loadTailscaleAccess();
  } catch (error) {
    message.textContent = error.message;
  } finally {
    button.disabled = false;
    setSwappingButtonText("access-disable-button", "Disable password lock");
  }
}

function clearUpdateCheckAvailabilityTimer() {
  clearTimeout(updateCheckAvailabilityTimer);
  updateCheckAvailabilityTimer = undefined;
}

function scheduleUpdateCheckAvailabilityRefresh(cooldown) {
  clearUpdateCheckAvailabilityTimer();
  if (!cooldown.active || byId("app-shell").hidden) return;
  const delayMilliseconds = Math.min(cooldown.delayMilliseconds + 1000, 60 * 60 * 1000);
  updateCheckAvailabilityTimer = setTimeout(() => {
    updateCheckAvailabilityTimer = undefined;
    if (byId("app-shell").hidden) return;
    renderUpdates();
  }, delayMilliseconds);
}

function updateStatePresentation(update = state.updates) {
  if (!update) return { label: "Loading", tone: "pending", summary: "Loading update status." };
  if (update.lastFailure?.action === "check") {
    return {
      label: "Check failed",
      tone: "bad",
      summary: update.lastSuccessfulCheckUtc ? "Showing the last successful check." : "No successful update check is available.",
    };
  }
  switch (update.state) {
  case "current": return { label: "Current", tone: "good", summary: "The installed versions match the latest stable release." };
  case "update-available": return { label: "Update available", tone: "update-available", summary: "A newer stable release is available. Follow the steps for this installation." };
  case "legacy": return { label: "Older host adapter", tone: "bad", summary: "Update the host package or saved deployment template." };
  case "mismatched": return { label: "Version mismatch", tone: "bad", summary: "The running application and host package report different versions. Follow the update guide for this installation." };
  case "newer": return { label: "Newer than stable", tone: "neutral", summary: "This installation is ahead of the latest stable release." };
  default: return { label: "Not checked", tone: "neutral", summary: "A comparison with the latest stable release is unavailable." };
  }
}

function displayUpdateVersion(value, unavailable = "Not reported") {
  return value ? `v${value}` : unavailable;
}

function readableList(values) {
  if (values.length < 2) return values[0] || "";
  if (values.length === 2) return `${values[0]} and ${values[1]}`;
  return `${values.slice(0, -1).join(", ")}, and ${values.at(-1)}`;
}

function releaseAlignmentSummary(update) {
  const managerVersion = update.managerVersion || state.about?.version || "";
  const layers = [
    ["Application", update.applicationVersion],
    ...(update.imageVersion ? [["Container image", update.imageVersion]] : []),
    ...(update.packageVersion ? [[packageName(), update.packageVersion]] : []),
  ];
  const matching = layers.filter(([, version]) => managerVersion && version === managerVersion).map(([label]) => label);
  const different = layers.filter(([, version]) => version && version !== managerVersion).map(([label, version]) => `${label} ${displayUpdateVersion(version)}`);
  const missing = layers.filter(([, version]) => !version).map(([label]) => `${label} not reported`);
  const parts = [];
  if (matching.length) parts.push(`${readableList(matching)} ${matching.length === 1 ? "matches" : "match"} Manager build`);
  parts.push(...different, ...missing);
  return parts.join(" · ") || "Release alignment unavailable";
}

function renderUpdates() {
  const update = state.updates || {};
  renderUpdateStatusButton(update);
  const badge = window.TautWeeklyUpdateUI.managerBadge(update, state.about?.version);
  setText("manager-badge-version", badge.version);
  setText("manager-badge-status", badge.status);
  byId("manager-version-badge").setAttribute("aria-label", `${packageName()} updates. ${badge.version} — ${badge.status}${update.lastSuccessfulCheckUtc ? `. Last successful check ${formatDate(update.lastSuccessfulCheckUtc)}` : ""}`);
  byId("update-settings-panel").classList.toggle("update-attention-glow", update.state !== "current");
  const presentation = updateStatePresentation();
  const checking = state.updateChecking || update.checkInProgress;
  setChip("update-settings-chip", checking ? "Checking" : presentation.label, checking ? "pending" : presentation.tone);
  setText("update-settings-summary", checking ? "Checking GitHub for a stable release." : presentation.summary);
  setText("update-manager-version", displayUpdateVersion(update.managerVersion || state.about?.version));
  setText("update-latest-version", displayUpdateVersion(update.latestStableVersion, "Not checked"));
  setText("update-edition", packageName());
  const hasImage = Boolean(update.imageRepository);
  byId("update-runtime-profile-row").hidden = !hasImage && !update.imageVersion;
  byId("update-image-repository-row").hidden = !hasImage;
  byId("update-image-reference-row").hidden = !update.recommendedImageReference;
  byId("update-migration-state-row").hidden = update.migrationState !== "legacy-mac-image";
  setText("update-runtime-profile", titleCase(update.runtimeProfile));
  setText("update-image-repository", update.imageRepository);
  setText("update-image-reference", update.recommendedImageReference);
  setText("update-migration-state", "Retired Mac registry image");
  byId("update-image-pinning-policy").hidden = !update.imagePinningPolicy;
  setText("update-image-pinning-policy", update.imagePinningPolicy);
  setText("update-release-alignment", releaseAlignmentSummary(update));
  const hostAdapterApplicable = Boolean(update.hostAdapterState) && update.hostAdapterState !== "not-applicable";
  const hostAdapterRow = byId("update-host-adapter-row");
  hostAdapterRow.hidden = !hostAdapterApplicable;
  hostAdapterRow.parentElement.classList.toggle("host-adapter-hidden", !hostAdapterApplicable);
  if (hostAdapterApplicable) {
    setText("update-host-adapter", `${update.hostAdapterVersion ? `API ${update.hostAdapterVersion}` : "Not reported"} · ${titleCase(update.hostAdapterState)}`);
  }
  setText("update-channel", titleCase(update.updateChannel || "stable"));
  setText("update-last-success", formatDate(update.lastSuccessfulCheckUtc));

  const failure = byId("update-failure");
  failure.hidden = !update.lastFailure;
  if (update.lastFailure) {
    setText("update-failure-heading", update.lastFailure.action === "install" ? "Install failed" : "Last check failed");
    setText("update-failure-message", update.lastFailure.message);
    setText("update-failure-time", formatDate(update.lastFailure.occurredAtUtc));
  }

  const guidance = update.guidance || {};
  setText("update-owner", guidance.owner || "Installation guide");
  const missingWindowsUpdater = ["windows-installer", "windows-portable"].includes(update.packageKind) && !update.windowsUpdaterAvailable;
  setText("update-guidance-summary", missingWindowsUpdater
    ? "The verified updater is unavailable in this folder. Follow the Windows update guide."
    : guidance.summary || "Choose your installation method for the update steps.");
  const steps = byId("update-guidance-steps");
  steps.replaceChildren();
  for (const value of missingWindowsUpdater ? [] : guidance.steps || []) {
    const item = document.createElement("li");
    item.textContent = value;
    steps.append(item);
  }
  const commandPanel = byId("update-command-panel");
  commandPanel.hidden = !guidance.command;
  setText("update-command", guidance.command);
  const docsLink = byId("update-docs-link");
  docsLink.href = guidance.docsUrl || "https://sparkmoxie.github.io/TautWeekly/";

  const notes = byId("update-release-notes");
  notes.hidden = !update.releaseNotesUrl;
  if (update.releaseNotesUrl) notes.href = update.releaseNotesUrl;

  const cooldown = window.TautWeeklyUpdateUI.updateCheckCooldown(update);
  scheduleUpdateCheckAvailabilityRefresh(cooldown);
  const backoffActive = cooldown.active;
  const checkButton = byId("update-check-button");
  checkButton.disabled = !state.updates || checking || backoffActive;
  setSwappingButtonText("update-check-button", checking ? "Checking…" : backoffActive ? "Try again shortly" : "Check now");

  const installAvailable = Boolean(update.installSupported);
  const installRow = byId("update-install-confirm-row");
  const installButton = byId("update-install-button");
  if (!installAvailable) byId("update-install-confirm").checked = false;
  installRow.hidden = !installAvailable;
  installButton.hidden = !installAvailable;
  installButton.disabled = !installAvailable || !byId("update-install-confirm").checked || state.updateInstalling || ["starting", "running"].includes(update.installState);
  setSwappingButtonText("update-install-button", state.updateInstalling ? "Starting…" : ["starting", "running"].includes(update.installState) ? "Installing…" : "Install update");

  const message = byId("update-settings-message");
  if (state.updateInstalling) message.textContent = "Approve the Windows administrator prompt to continue.";
  else if (["starting", "running"].includes(update.installState)) message.textContent = "Manager will reconnect when the updater finishes and the app restarts.";
  else if (update.installState === "failed") message.textContent = "Review the error above, then check for an update before retrying.";
  else if (update.installState === "completed") message.textContent = "Update complete. Refreshing local status.";
  else if (backoffActive) message.textContent = `Check again after ${formatDate(update.nextCheckAllowedAtUtc)}.`;
  else message.textContent = "Check now contacts GitHub. Header Refresh also checks for updates when eligible.";
}

function renderUpdateStatusButton(update) {
  const indicator = window.TautWeeklyUpdateUI.updateIndicator(update);
  const button = byId("update-status-button");
  button.hidden = !indicator.visible;
  if (!indicator.visible) return;
  button.setAttribute("aria-label", indicator.label);
  button.dataset.tooltip = indicator.label;
}

async function waitForActiveUpdateCheck(expectedAuthenticationEpoch = authenticationEpoch) {
  for (let attempt = 0; attempt < 36; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 250));
    if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    const updates = await request("/api/v1/updates");
    if (expectedAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    state.updates = updates;
    renderUpdates();
    if (!state.updates.checkInProgress) return;
  }
}

async function runUpdateCheck(background = false) {
  if (state.updateChecking) return;
  const updateAuthenticationEpoch = authenticationEpoch;
  state.updateChecking = true;
  renderUpdates();
  try {
    const updates = await request("/api/v1/updates/check", { method: "POST", body: "{}" });
    if (updateAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    state.updates = updates;
    if (!background) {
      const message = updates.lastFailure?.action === "check"
        ? updates.lastFailure.message
        : updates.state === "update-available" ? "Stable update found." : "Update check complete.";
      setGlobalStatus(message, true);
    }
  } catch (error) {
    if (updateAuthenticationEpoch !== authenticationEpoch || byId("app-shell").hidden) return;
    if (background && error.code === "check-in-progress") {
      try { await waitForActiveUpdateCheck(updateAuthenticationEpoch); } catch (_) { /* A later authenticated refresh can recover local status. */ }
    } else if (background && error.code === "check-backoff") {
      try {
        const updates = await request("/api/v1/updates");
        if (updateAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) state.updates = updates;
      } catch (_) {
        // Keep the already rendered cached state.
      }
    } else {
      byId("update-settings-message").textContent = error.message;
      if (!background) setGlobalStatus(error.message, true);
    }
  } finally {
    if (updateAuthenticationEpoch === authenticationEpoch && !byId("app-shell").hidden) {
      state.updateChecking = false;
      renderUpdates();
    }
  }
}

function checkForUpdates() {
  return runUpdateCheck(false);
}

function checkForUpdatesInBackground() {
  if (state.updateChecking || !state.updates?.backgroundCheckRecommended) return;
  void runUpdateCheck(true);
}

async function installUpdate() {
  if (state.updateInstalling || !byId("update-install-confirm").checked) return;
  state.updateInstalling = true;
  renderUpdates();
  try {
    state.updates = await request("/api/v1/updates/install", { method: "POST", body: "{}" });
    setGlobalStatus("Verified Windows updater started.", true);
    beginUpdateInstallPolling(state.updates.latestStableVersion);
  } catch (error) {
    byId("update-settings-message").textContent = error.message;
    setGlobalStatus(error.message, true);
  } finally {
    state.updateInstalling = false;
    renderUpdates();
  }
}

function stopUpdateInstallPolling() {
  clearTimeout(updateInstallPollTimer);
  updateInstallPollTimer = undefined;
  updateInstallExpectedVersion = "";
  updateInstallSawDisconnect = false;
  updateInstallPollDeadline = 0;
}

function beginUpdateInstallPolling(expectedVersion) {
  stopUpdateInstallPolling();
  updateInstallExpectedVersion = expectedVersion || "";
  updateInstallPollDeadline = Date.now() + 15 * 60 * 1000;
  updateInstallPollTimer = setTimeout(pollUpdateInstall, 1000);
}

async function pollUpdateInstall() {
  if (!updateInstallExpectedVersion) return;
  try {
    const update = await request("/api/v1/updates");
    state.updates = update;
    const active = ["starting", "running"].includes(update.installState);
    if (update.managerVersion === updateInstallExpectedVersion || (updateInstallSawDisconnect && !active)) {
      stopUpdateInstallPolling();
      setGlobalStatus("Manager update finished. Loading the updated application...");
      window.location.reload();
      return;
    }
    renderUpdates();
    if (!active) {
      stopUpdateInstallPolling();
      setGlobalStatus(update.installState === "failed" ? "Verified updater did not complete." : "Verified updater finished without a Manager restart.", true);
      return;
    }
  } catch (error) {
    if (error.status === 401) {
      stopUpdateInstallPolling();
      window.location.reload();
      return;
    }
    updateInstallSawDisconnect = true;
    byId("update-settings-message").textContent = "The Manager is restarting for the verified update. Reconnecting automatically...";
    setGlobalStatus("Reconnecting to the updated Manager...");
  }
  if (Date.now() >= updateInstallPollDeadline) {
    stopUpdateInstallPolling();
    byId("update-settings-message").textContent = "Automatic reconnection timed out. The updater may still be awaiting Windows approval; review the prompt, then use Refresh if needed.";
    return;
  }
  updateInstallPollTimer = setTimeout(pollUpdateInstall, 1500);
}

async function copyUpdateCommand() {
  const command = state.updates?.guidance?.command || "";
  if (!command) return;
  try {
    if (!navigator.clipboard?.writeText) throw new Error("Clipboard API unavailable");
    await navigator.clipboard.writeText(command);
  } catch (_) {
    const fallback = document.createElement("textarea");
    fallback.value = command;
    fallback.setAttribute("readonly", "");
    fallback.style.position = "fixed";
    fallback.style.opacity = "0";
    document.body.append(fallback);
    fallback.select();
    const copied = document.execCommand("copy");
    fallback.remove();
    if (!copied) {
      byId("update-settings-message").textContent = "The browser could not copy the command. Select the displayed command manually.";
      return;
    }
  }
  setSwappingButtonText("update-copy-command", "Copied");
  setTimeout(() => setSwappingButtonText("update-copy-command", "Copy command"), 1600);
}

function renderAbout() {
  const events = state.diagnostics?.events || [];
  setText("diagnostics-count", events.length ? `${events.length} retained` : "No events");
  setText("diagnostics-retention", `Manager keeps the latest ${state.diagnostics?.maximumEntries || 20} events.`);
  const container = byId("diagnostics-list");
  container.replaceChildren();
  if (!events.length) {
    const empty = document.createElement("p");
    empty.className = "diagnostics-empty";
    empty.textContent = "No setup or verification events have been recorded.";
    container.append(empty);
    return;
  }
  for (const event of events) {
    const row = document.createElement("article");
    row.className = "diagnostic-row";
    const copy = document.createElement("div");
    const heading = document.createElement("h3");
    heading.textContent = event.summary;
    const metadata = document.createElement("p");
    metadata.textContent = `${diagnosticAreaLabel(event.area)} · Support code ${event.code}`;
    copy.append(heading, metadata);
    const evidence = document.createElement("div");
    evidence.className = "diagnostic-evidence";
    const chip = document.createElement("span");
    chip.className = `state-chip ${event.outcome === "passed" ? "good" : event.outcome === "failed" ? "bad" : "neutral"}`;
    chip.textContent = titleCase(event.outcome);
    const timestamp = document.createElement("small");
    timestamp.textContent = formatDate(event.recordedAtUtc);
    evidence.append(chip, timestamp);
    row.append(copy, evidence);
    container.append(row);
  }
}

function diagnosticAreaLabel(area) {
  return area === "lan-verification" ? "Connection Verification" : titleCase(area);
}

function openPreview(id, button, options = {}) {
  state.selectedPreviewID = id;
  document.querySelectorAll(".preview-button").forEach((element) => element.classList.remove("active"));
  button.classList.add("active");
  byId("preview-placeholder").hidden = true;
  const frame = byId("preview-frame");
  const reloadKey = String(options.reloadKey || "");
  const reloadRequested = reloadKey && frame.dataset.previewReloadKey !== reloadKey;
  if (frame.dataset.previewId !== id || reloadRequested) {
    const query = reloadKey ? `?refresh=${encodeURIComponent(reloadKey)}` : "";
    frame.src = `/preview/${encodeURIComponent(id)}${query}`;
    frame.dataset.previewId = id;
    if (reloadKey) frame.dataset.previewReloadKey = reloadKey;
    else frame.removeAttribute("data-preview-reload-key");
  }
  frame.hidden = false;
}

function initializePreviewIndexNavigation() {
  const frame = byId("preview-frame");
  const documentRoot = frame.contentDocument;
  const selected = state.previews.find((preview) => preview.id === state.selectedPreviewID);
  if (!documentRoot || !/-00-index(?:\.html)?$/i.test(selected?.name || "")) return;
  documentRoot.querySelectorAll("a[href]").forEach((link) => {
    let fileName = "";
    try {
      const target = new URL(link.getAttribute("href"), documentRoot.baseURI);
      fileName = decodeURIComponent(target.pathname.split("/").pop() || "").toLowerCase();
    } catch (_) {
      return;
    }
    const preview = state.previews.find((candidate) => `${candidate.name}.html`.toLowerCase() === fileName);
    if (!preview) return;
    link.addEventListener("click", (event) => {
      event.preventDefault();
      const button = byId("preview-list").querySelector(`[data-preview-id="${CSS.escape(preview.id)}"]`);
      if (button) openPreview(preview.id, button);
    });
  });
}

function selectView(name, options = {}) {
  const section = options.section || "";
  if (options.updateHistory !== false) {
    const hash = window.TautWeeklyUpdateUI.hashForRoute(name, section);
    if (window.location.hash !== hash) {
      history.pushState({ managerView: name, managerSection: section }, "", `${window.location.pathname}${window.location.search}${hash}`);
      lastRoutedURL = window.location.href;
    }
  }
  if (name !== "configuration") { clearAllRevealedSecrets(); clearHouseholdPrimary(); }
  document.querySelectorAll("[data-user-combobox].open").forEach((container) => setUserComboboxOpen(container, false));
  document.querySelectorAll("[data-panel]").forEach((panel) => { panel.hidden = panel.dataset.panel !== name; });
  if (name === "verification") renderVerification();
  document.querySelectorAll("[data-view]").forEach((button) => {
    const active = button.dataset.view === name;
    button.classList.toggle("active", active);
    if (active) button.setAttribute("aria-current", "page");
    else button.removeAttribute("aria-current");
  });
  window.scrollTo({ top: 0, behavior: "auto" });
  if (section === "updates" && name === "about") {
    requestAnimationFrame(() => {
      byId("update-settings-panel").scrollIntoView({ block: "start", behavior: "smooth" });
      byId("update-settings-heading").focus({ preventScroll: true });
    });
  } else if (section === "tailscale" && name === "about" && !byId("tailscale-settings-panel").hidden) {
    requestAnimationFrame(() => {
      byId("tailscale-settings-panel").scrollIntoView({ block: "start", behavior: "smooth" });
      byId("tailscale-settings-heading").focus({ preventScroll: true });
    });
  } else if (section === "cache" && name === "configuration") {
    requestAnimationFrame(() => {
      const cacheToggle = byId("config-DeletedItemCacheEnabled");
      cacheToggle.scrollIntoView({ block: "center", behavior: "smooth" });
      cacheToggle.focus({ preventScroll: true });
    });
  } else {
    byId("main-content").focus({ preventScroll: true });
  }
}

function applyLocationRoute() {
  if (byId("app-shell").hidden || lastRoutedURL === window.location.href) return;
  lastRoutedURL = window.location.href;
  const route = window.TautWeeklyUpdateUI.routeFromHash(window.location.hash);
  selectView(route.view, { section: route.section, updateHistory: false });
}

function openUpdateSettings() {
  selectView("about", { section: "updates" });
}

async function submitPair(event) {
  event.preventDefault();
  const password = byId("pair-password").value;
  if (password !== byId("pair-password-confirm").value) {
    setAuthMessage("The password confirmation does not match.");
    return;
  }
  setAuthMessage("Pairing this browser…", false);
  try {
    const session = await request("/api/v1/auth/pair", { method: "POST", body: JSON.stringify({ token: byId("pair-token").value, password }) });
    state.csrfToken = session.csrfToken;
    concealMaskedInputs(byId("pair-form"));
    await enterApplication();
  } catch (error) {
    setAuthMessage(error.message);
  }
}

async function submitLogin(event) {
  event.preventDefault();
  setAuthMessage("Signing in…", false);
  try {
    const session = await request("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ password: byId("login-password").value }) });
    state.csrfToken = session.csrfToken;
    byId("login-password").value = "";
    concealMaskedInputs(byId("login-form"));
    await enterApplication();
  } catch (error) {
    setAuthMessage(error.message);
  }
}

async function logout() {
  clearAllRevealedSecrets();
  try { await request("/api/v1/auth/logout", { method: "POST" }); }
  finally { state.csrfToken = ""; showAuthentication(); }
}

function showAuthentication() {
  authenticationEpoch += 1;
  clearHouseholdPrimary();
  byId("household-copy-list").replaceChildren();
  applicationRefreshPromise = null;
  byId("refresh-button").disabled = false;
  stopUpdateInstallPolling();
  clearUpdateCheckAvailabilityTimer();
  clearAllRevealedSecrets();
  closeSecretRevealDialog();
  concealMaskedInputs(byId("auth-shell"));
  state.discovery = null;
  state.discoveryError = "";
  state.discoveryRunning = false;
  state.updateChecking = false;
  state.operationStarting = false;
  state.operationStartingType = "";
  byId("discovery-libraries").replaceChildren();
  byId("discovery-users").replaceChildren();
  byId("managed-user-delivery-list").replaceChildren();
  byId("managed-user-delivery-addresses").hidden = true;
  renderUserComboboxes();
  clearTimeout(operationPollTimer);
  clearTimeout(schedulePollTimer);
  clearTimeout(deliveryStatusPollTimer);
  byId("app-shell").hidden = true;
  byId("auth-shell").hidden = false;
  setText("auth-title", "Sign in to TautWeekly");
  byId("pair-form").hidden = true;
  byId("login-form").hidden = false;
  byId("login-password").focus();
}

function createMaterialIcon(name) {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.classList.add("ui-icon");
  svg.setAttribute("viewBox", "0 -960 960 960");
  svg.setAttribute("aria-hidden", "true");
  const use = document.createElementNS("http://www.w3.org/2000/svg", "use");
  use.setAttribute("href", `#icon-${name}`);
  svg.append(use);
  return materializeMaterialIcon(svg);
}

function setChip(id, text, tone, iconName = "") {
  const chip = byId(id);
  const resolvedTone = tone || "neutral";
  let label = chip.querySelector(".state-chip-label");
  if (!label) {
    label = document.createElement("span");
    label.className = "state-chip-label";
    label.textContent = chip.textContent;
    chip.replaceChildren(label);
  }
  const currentIcon = chip.querySelector(":scope > .ui-icon");
  if (iconName && (!currentIcon || chip.dataset.iconName !== iconName)) {
    const nextIcon = createMaterialIcon(iconName);
    if (currentIcon) currentIcon.replaceWith(nextIcon);
    else chip.insertBefore(nextIcon, label);
  } else if (!iconName && currentIcon) {
    currentIcon.remove();
  }
  if (chip.dataset.iconName !== iconName) chip.dataset.iconName = iconName;
  setSwappingElementText(label, text);
  const chipClass = `state-chip ${resolvedTone}`;
  if (chip.className !== chipClass) chip.className = chipClass;
  const card = chip.closest(".health-card,.operation-strip,.current-operation,.setup-workflow-steps article,.setup-workflow");
  if (card && !card.classList.contains(`state-card-${resolvedTone}`)) {
    card.classList.remove("state-card-good", "state-card-bad", "state-card-pending", "state-card-neutral", "state-card-waiting", "state-card-warning");
    card.classList.add(`state-card-${resolvedTone}`);
  }
}
function setText(id, value) {
  const element = byId(id);
  const text = String(value || "Not recorded");
  if (element.textContent !== text) element.textContent = text;
}
function setSwappingText(id, value) {
  setSwappingElementText(byId(id), value);
}
function setSwappingButtonText(id, value) {
  setSwappingButtonElementText(byId(id), value);
}
function setSwappingButtonElementText(button, value) {
  let label = button.querySelector(".button-state-label");
  if (!label) {
    label = document.createElement("span");
    label.className = "button-state-label";
    label.textContent = button.textContent;
    button.replaceChildren(label);
  }
  setSwappingElementText(label, value);
}
function setSwappingElementText(element, value) {
  const next = value || "Not recorded";
  if (element.textContent === next) return;
  element.classList.remove("schedule-state-swap");
  element.textContent = next;
  void element.offsetWidth;
  element.classList.add("schedule-state-swap");
}
function setAuthMessage(message, isError = true) { const element = byId("auth-message"); element.textContent = message; element.classList.toggle("error", isError); }

let statusTimer;
function setGlobalStatus(message, dismiss = false) {
  const element = byId("global-status");
  clearTimeout(statusTimer);
  element.textContent = message;
  element.classList.add("visible");
  if (dismiss) statusTimer = setTimeout(() => element.classList.remove("visible"), 2600);
}

function overallHeading(overall) {
  switch (overall) {
  case "healthy": return "Manager is online";
  case "unconfigured": return "Set up TautWeekly";
  case "blocked": return "Review configuration before delivery";
  default: return "Manager is online with issues";
  }
}
function overallCopy(overall) {
  switch (overall) {
  case "healthy": return "See configuration, scheduler, and connection status below.";
  case "unconfigured": return "Add your services and email settings before enabling weekly delivery.";
  case "blocked": return "The Manager could not read the saved configuration. Review it in Config.";
  default: return "One or more status checks need attention. See the cards below.";
  }
}
function formatScheduleTime(value) {
  // A configured wall-clock time has no date or timezone to convert.
  const match = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(String(value ?? ""));
  if (!match) return "Invalid time";
  const hour = Number(match[1]);
  return `${hour % 12 || 12}:${match[2]} ${hour < 12 ? "AM" : "PM"}`;
}
function formatDate(value, timeZone) {
  if (!value) return "Not recorded";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Not recorded";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short", timeZone }).format(date);
}
function formatBytes(value) {
  if (!Number.isFinite(value) || value < 1024) return `${value || 0} B`;
  if (value < 1024 * 1024) return `${Math.round(value / 1024)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}
function formatDuration(value) {
  if (!Number.isFinite(value) || value < 0) return "Duration unavailable";
  if (value < 1000) return `${Math.round(value)} ms`;
  if (value < 60000) return `${(value / 1000).toFixed(value < 10000 ? 1 : 0)} s`;
  return `${Math.floor(value / 60000)}m ${Math.round((value % 60000) / 1000)}s`;
}
function yesNo(value) { return value ? "Yes" : "No"; }
function displayValue(value) {
  if (value === null || value === undefined || value === "") return "Not set";
  if (Array.isArray(value)) return value.length ? value.join(", ") : "None selected";
  if (typeof value === "object") return JSON.stringify(value);
  if (typeof value === "boolean") return value ? "Enabled" : "Disabled";
  return String(value);
}

byId("pair-form").addEventListener("submit", submitPair);
byId("login-form").addEventListener("submit", submitLogin);
byId("access-password-form").addEventListener("submit", submitAccessPassword);
byId("access-disable-button").addEventListener("click", disableAccessPassword);
byId("secret-reveal-form").addEventListener("submit", submitSecretReveal);
byId("secret-reveal-cancel").addEventListener("click", closeSecretRevealDialog);
byId("secret-reveal-dialog").addEventListener("close", () => {
  byId("secret-reveal-password").value = "";
  concealMaskedInputs(byId("secret-reveal-form"));
  byId("secret-reveal-message").textContent = "";
  pendingSecretReveal = null;
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    clearAllRevealedSecrets();
    clearTimeout(deliveryStatusPollTimer);
    manageOperationPolling();
    manageSchedulePolling();
    return;
  }
  if (!byId("app-shell").hidden && state.status) {
    void pollDeliveryStatus();
    manageOperationPolling();
    manageSchedulePolling();
  }
});
materializeMaterialIcons();
initializeMaskedInputToggles();
document.querySelectorAll("[data-user-combobox]").forEach(initializeUserCombobox);
byId("preview-frame").addEventListener("load", initializePreviewIndexNavigation);
document.addEventListener("pointerdown", (event) => {
  document.querySelectorAll("[data-user-combobox].open").forEach((container) => {
    if (!container.contains(event.target)) setUserComboboxOpen(container, false);
  });
  document.querySelectorAll(".title-gif-field.open").forEach((container) => {
    if (!container.contains(event.target)) {
      container.classList.remove("open");
      const picker = container.querySelector("[data-title-gif-picker]");
      const trigger = container.querySelector(".title-gif-trigger");
      if (picker) picker.hidden = true;
      trigger?.setAttribute("aria-expanded", "false");
    }
  });
});
byId("config-form").addEventListener("submit", submitConfig);
byId("config-reset-button").addEventListener("click", renderConfigEditor);
byId("direct-plex-review-button").addEventListener("click", reviewDirectPlexFields);
byId("discovery-confirm").addEventListener("change", renderDiscovery);
byId("discovery-run-button").addEventListener("click", runTautulliDiscovery);
byId("verification-confirm").addEventListener("change", renderVerification);
byId("verification-run-button").addEventListener("click", runVerification);
byId("smtp-verification-confirm").addEventListener("change", renderVerification);
byId("smtp-verification-run-button").addEventListener("click", runSMTPVerification);
byId("cache-verification-run-button").addEventListener("click", handleCacheVerificationAction);
byId("preview-user-id").addEventListener("input", renderOperations);
byId("preview-confirm").addEventListener("change", renderOperations);
byId("preview-run-button").addEventListener("click", startPreviewOperation);
byId("preview-cancel-button").addEventListener("click", cancelPreviewOperation);
byId("test-send-user-id").addEventListener("input", renderOperations);
byId("test-send-confirm").addEventListener("change", renderOperations);
byId("test-send-run-button").addEventListener("click", startTestSendOperation);
byId("manual-send-mode").addEventListener("change", () => {
  byId("manual-send-confirm").checked = false;
  renderOperations();
});
byId("manual-send-user-id").addEventListener("input", renderOperations);
byId("manual-send-confirm").addEventListener("change", renderOperations);
byId("manual-send-run-button").addEventListener("click", startManualSendOperation);
byId("schedule-confirm").addEventListener("change", renderSchedule);
byId("schedule-confirm-cancel").addEventListener("click", cancelScheduleConfirmation);
byId("schedule-confirm-run").addEventListener("click", startScheduleOperation);
document.querySelectorAll("[data-schedule-action]").forEach((button) => button.addEventListener("click", () => chooseScheduleAction(button.dataset.scheduleAction)));
byId("startup-manager").addEventListener("change", startupSettingsChanged);
byId("startup-dashboard").addEventListener("change", startupSettingsChanged);
byId("tailscale-enabled").addEventListener("change", updateTailscaleAccess);
byId("tailscale-password-setup-button").addEventListener("click", openAccessSettings);
byId("tailscale-refresh-button").addEventListener("click", refreshTailscaleAccess);
byId("tailscale-copy-button").addEventListener("click", copyTailscaleURL);
byId("tailscale-copy-authorization").addEventListener("click", copyTailscaleAuthorizationCommand);
byId("funnel-settings-link").addEventListener("click", openTailscaleSettings);
byId("tailscale-status-button").addEventListener("click", openTailscaleSettings);
byId("update-check-button").addEventListener("click", checkForUpdates);
byId("update-install-confirm").addEventListener("change", renderUpdates);
byId("update-install-button").addEventListener("click", installUpdate);
byId("update-copy-command").addEventListener("click", copyUpdateCommand);
byId("logout-button").addEventListener("click", logout);
byId("refresh-button").addEventListener("click", refreshApplicationStatus);
byId("access-status-button").addEventListener("click", openAccessSettings);
byId("update-status-button").addEventListener("click", openUpdateSettings);
byId("manager-version-badge").addEventListener("click", openUpdateSettings);
document.querySelectorAll("[data-view]").forEach((button) => button.addEventListener("click", () => selectView(button.dataset.view)));
document.querySelectorAll("[data-open-view]").forEach((button) => button.addEventListener("click", () => selectView(button.dataset.openView)));
window.addEventListener("popstate", applyLocationRoute);
window.addEventListener("hashchange", applyLocationRoute);
initialize().catch((error) => setAuthMessage(`Manager initialization failed: ${error.message}`));
